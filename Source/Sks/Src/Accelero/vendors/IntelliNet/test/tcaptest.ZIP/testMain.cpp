#include <iostream>
#include <stdarg.h>
#include "tcapTest.h"
#include <its_timers.h>

using namespace its;
using namespace std;

#if defined(ISS7_VER_PR4)
#include <dmalloc.h>
#endif

#define CLIENT    1

// --- Globals ---
extern int mode;
extern int opc;
extern ITS_OCTET ossn;
extern int dpc;
extern ITS_OCTET dssn; 

ITS_HANDLE hdl;

ITS_UINT parseArguments(int, char**);

void sendTCAPPreArrangedEnd(ITS_HANDLE*, ITS_USHORT);

int main(int argc, char** argv)
{
    ITS_UINT mask;
    int choice = 0, bCount = 1;
     
    TCAP_Test* test;
 
    cout <<"\n******* TCAP Tester *******\n";

    cout <<"\n How many border Transports ? (1-2)\n";

    cin >> bCount; 

    mask = parseArguments(argc, argv);

    if(mask == 0)
    {
        return 0;
    }
 
    if(mode == CLIENT)
    { 
        dpc = 5; 
        opc = 2;
        ossn = 2;
        dssn = 5;
        test = new TCAP_Test(mask, "tcapsend", bCount);
    }
    else
    {
        dpc = 2; 
        opc = 5;
        ossn = 5;
        dssn = 2;
        test = new TCAP_Test(mask);
    }

    hdl = getITSHandle();
    
    while (true)
    {
        test->SendMsgs(hdl);
    }
 
    return 0;
}


ITS_UINT
parseArguments(int argc, char** argv)
{
    ITS_UINT mask = ITS_TCAP | ITS_TRANSPORT_SINGLE_USER;

    if(argc == 0)
    {
        cout << "USAGE: server | client" << endl;

        return 0;
    }

    for(int i = 1; i < argc;i++)
    {
        if(strcmp(argv[i], "server") == 0)
        {
            mask |= ITS_TRANSPORT_SSOCKET;
        }
        else if(strcmp(argv[i], "client") == 0)
        {
            mask |= ITS_TRANSPORT_CSOCKET;
         
            mode = CLIENT;
        }
        else
        {
            cout << "USAGE: server | client" << endl;

            return 0;
        }
    }

    return mask;
}          
