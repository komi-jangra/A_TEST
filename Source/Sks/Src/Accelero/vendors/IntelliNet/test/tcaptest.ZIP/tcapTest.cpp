#include "tcapTest.h"

#include <its_trace.h>
#include <math.h>
#include <its_rm.h>
#include <its_dsm.h>
#include <its_assertion.h>

#define BORDER_INST_NUM1 2
#define BORDER_INST_NUM2 3

#if defined(ITS_STD_NAMESPACE)
using namespace std;
using namespace its;
#endif


void *object = NULL;

extern ITS_HANDLE hdl;

// --- Globals ---
int mode  = 0;
int opc   = 5;
ITS_OCTET ossn = 5;
int dpc   = 2;
ITS_OCTET dssn = 2; 
ITS_HANDLE borderHandle1 = NULL;
ITS_HANDLE borderHandle2 = NULL;
ITS_BOOLEAN isLoopMode = ITS_FALSE;

#define SEND_LOOP      5
#define LOOP_COUNT     200
#define RECV_LOOP      6

static ITS_UINT borderMask = 0;

ITS_HANDLE tqHandle;

/*
 keep origination and destination
 * E164 number length same.
 */
int e164_len   = 10;

//update location arg  len=32.
#define LOC_ARG_LEN 30
//Subscriber arg.
#define SUB_ARG_LEN 144

//GSMMAP encoded bytes for Location ARG,
//Subscriber Arg messages.
ITS_OCTET LocationArg[] = { 0x30,0x1c,0x04,0x08,0x62,0x08,0x61,0x09,
                            0x00,0x00,0x20,0xf8,0x81,0x07,0x91,0x53,
                            0x91,0x11,0x53,0x29,0x00,0x04,0x07,0x91,
                            0x53,0x91,0x11,0x53,0x29,0x00 };

ITS_OCTET SubscribeArg[] =
                  { 0x30,0x80,0x81,0x07,0x91,0x51,0x41,0x99,0x56,0x45,0xf3,0x82,
                    0x01,0x02,0x83,0x01,0x01,0xa6,0x06,0x04,0x01,0x11,0x04,0x01,
                    0x21,0xa7,0x80,0xa0,0x80,0x04,0x01,0x21,0x30,0x80,0x30,0x06,
                    0x83,0x01,0x10,0x84,0x01,0x04,0x00,0x00,0x00,0x00,0xa0,0x80,
                    0x04,0x01,0x29,0x30,0x80,0x30,0x12,0x83,0x01,0x10,0x84,0x01,
                    0x07,0x85,0x07,0x91,0x51,0x41,0x99,0x12,0x21,0xf3,0x86,0x01,
                    0x04,0x00,0x00,0x00,0x00,0xa0,0x80,0x04,0x01,0x2a,0x30,0x80,
                    0x30,0x15,0x83,0x01,0x10,0x84,0x01,0x07,0x85,0x07,0x91,0x51,
                    0x41,0x99,0x12,0x21,0xf3,0x86,0x01,0x08,0x87,0x01,0x0f,0x00,
                    0x00,0x00,0x00,0xa0,0x80,0x04,0x01,0x2b,0x30,0x80,0x30,0x12,
                    0x83,0x01,0x10,0x84,0x01,0x07,0x85,0x07,0x91,0x51,0x41,0x99,
                    0x12,0x21,0xf3,0x86,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00 };

ITS_OCTET octs185[] =
        {0x30,0x81,0xB4,0x30,0x22,0x04,0x10,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,
         0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x04,0x04,0xFF,0xFE,0xFD,0xFC,0x04,0x08,0xFB,
         0xFA,0xF9,0xF8,0xF7,0xF6,0xF5,0xF4,0x30,0x22,0x04,0x10,0xFF,0xFF,0xFF,0xFF,0xFF,
         0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x04,0x04,0xFF,0xFE,0xFD,
         0xFC,0x04,0x08,0xFB,0xFA,0xF9,0xF8,0xF7,0xF6,0xF5,0xF4,0x30,0x22,0x04,0x10,0xFF,
         0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x04,
         0x04,0xFF,0xFE,0xFD,0xFC,0x04,0x08,0xFB,0xFA,0xF9,0xF8,0xF7,0xF6,0xF5,0xF4,0x30,
         0x22,0x04,0x10,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,
         0xFF,0xFF,0xFF,0x04,0x04,0xFF,0xFE,0xFD,0xFC,0x04,0x08,0xFB,0xFA,0xF9,0xF8,0xF7,
         0xF6,0xF5,0xF4,0x30,0x22,0x04,0x10,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,
         0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x04,0x04,0xFF,0xFE,0xFD,0xFC,0x04,0x08,0xFB,
         0xFA,0xF9,0xF8,0xF7,0xF6,0xF5,0xF4};


ITS_HANDLE 
getITSHandle() 
{ 
    return tqHandle;
}


void setOPC(ITS_UINT pc)
{
   opc = pc;
}

void setDPC(ITS_UINT pc)
{
   dpc = pc;
}

void setOSSN(ITS_USHORT ssn)
{
   ossn = ssn;
}

void setDSSN(ITS_USHORT ssn)
{
   dssn = ssn;
}

ITS_USHORT did = 0;

void  sendTCAPPreArrangedEnd(ITS_HANDLE*, ITS_USHORT);

/*
 * Initialize static members.
 */


TCAP_Test::TCAP_Test(ITS_UINT mask, char *appName, int borderCount)
{
    int opResult = ITS_SUCCESS, ret = ITS_SUCCESS;

    borderThr1 = new its::ITS_Thread(0, TCAP_Test::dispatchOnBorder1);

    if (borderCount == 2)
    {
        borderThr2 = new its::ITS_Thread(0, TCAP_Test::dispatchOnBorder2);
    }

    recvThread = new its::ITS_Thread(0, TCAP_Test::ReceiveMsgs);

    cout << "APP_Name = " << appName << endl;
 
    ITS_Application::SetName(appName);

    ITS_UINT stack_mask = ITS_TCAP | ITS_SCCP;

    if( (opResult = ITS_AddFeature(itsINTELLISS7_Class)) == ITS_SUCCESS)
    {
        cout << "Added IntelliSS7 Class Feature...." << endl;
    }

    if( (opResult = ITS_InitializeClass(itsTRACE_Class)) == ITS_SUCCESS)
    {
        cout << "Added IntelliSS7 Class Feature...." << endl;
    }


    TRACE_UpdateSettings();

    /* initialize the mem pool */
    ret = ITS_InitializeClass(itsMEMPOOL_Class);
    ITS_C_ASSERT(ret == ITS_SUCCESS);

    /* plug in the RM */
    ret = RM_Initialize(1, 1, 1, 1, 16777216, 1);
    ITS_C_ASSERT(ret == ITS_SUCCESS);

                 
    if(opResult != ITS_SUCCESS)
    {
        cout << "Adding IntelliNet Features failed...." << endl;
    }

    if(ITS_GlobalStart(stack_mask) != ITS_SUCCESS)
    {
        cout << "TCAP/SCCP Stack initialization failed." << endl;

        delete borderThr1;
        
        if (borderThr2)
        {
            delete borderThr2;
        }

        return;
    }

    ret = RM_SetInitialState();
    ITS_C_ASSERT(ret == ITS_SUCCESS);

    // Set destination address.
    cdp.SetPointCode(dpc);
    cdp.SetSSN(dssn);
    cdp.SetRouteByPCSSN(true);

    //Set origination address.
    cpa.SetPointCode(opc);
    cpa.SetSSN(ossn);
    cpa.SetRouteByPCSSN(true);

    createTQTransport(NULL);

    borderMask = mask;

    recvThread->Enter(new ITS_UINT(mask));

    borderThr1->Enter(new ITS_UINT(mask));

    if (borderCount == 2)
    {
        borderThr2->Enter(new ITS_UINT(mask));
    }

}


TCAP_Test::~TCAP_Test()
{
   if(borderHandle1 != NULL)
   {
      ITS_Terminate(borderHandle1);
   }

   if(borderHandle2 != NULL)
   {
      ITS_Terminate(borderHandle2);
   }

   if(tqHandle != NULL)
   {
      ITS_Terminate(tqHandle);
   }

   if(borderThr1 != NULL)
   {
      delete borderThr1;
   }

   if(borderThr2 != NULL)
   {
      delete borderThr2;
   }

   ITS_GlobalStop();
}


   
THREAD_RET_TYPE 
TCAP_Test::ReceiveMsgs(void *arg)
{
    ITS_EVENT event;
    ITS_OCTET invokeId;
    ITS_USHORT localDid;
    int len = 0;
    TCAP_Dialogue *dialogue = NULL;
    TCAP_Component *component = NULL;
    int ret = ITS_SUCCESS;

    ITS_EVENT_INIT(&event, 0, 0);

    TIMERS_Sleep(1);

    while (true)
    {
        if(ITS_GetNextEvent(tqHandle, &event) == ITS_SUCCESS)
        {
            ITS_Event evt(&event);

            len = evt.GetLength();

            if(evt.GetSource() == ITS_TCAP_SRC)
            {
                switch (TCAP_MSG_TYPE(&evt.GetEvent()))
                {
                case ITS_TCAP_CPT:

                    TCAP_Component::Receive(tqHandle, evt, dialogue,
                                            &component);

#if defined (CCITT)
                    invokeId = component->GetInvokeID();

                    printf(" **** InvokeID = %d. ****\n", invokeId);

                    if(component->GetComponentType() == 
                                                  TCPPT_TC_L_CANCEL)
                    {
                        TCAP_Cancel* lcancel = (TCAP_Cancel *) component;

                        cout << "\n **** TEST: Received CANCEL CPT **** \n";

                        sendTCAPPreArrangedEnd(&tqHandle, 
                                               lcancel->GetDialogueID());

                        delete lcancel;
                        component = NULL;
                    }
                    else if(component->GetComponentType() == TCPPT_TC_INVOKE)
                    {
                        cout << "\n **** TEST: Received INVOKE CPT **** \n";

                        if (isLoopMode)
                        {
                            TCAP_End       endDlg;
                            TCAP_Result    result;
                            TCAP_Dialogue* outbound;

                            endDlg.SetDialogueID(localDid);

                            outbound = &endDlg;

                            result.SetInvokeID(invokeId);

                            result.SetOperation(1);

                            result.SetParameter(LocationArg, 
                                               sizeof(LocationArg)/sizeof(ITS_OCTET));
  
                            ret = TCAP_Component::Send(hdl, outbound, &result);
 
                            if(ret == ITS_SUCCESS)
                            {
                                 cout << "\n **** TEST: TCAP_Comp RESULT send successful ****"
                                      << endl;
                            }
                            else
                            {
                                 cout << "\n **** TEST: TCAP_Comp RESULT failed to send. ****"
                                      << endl;
                            }
                        }
                    }               
                    else if(component->GetComponentType() == TCPPT_TC_RESULT_L)
                    {
                        cout << "\n **** TEST: Received RESULT LAST CPT **** \n";
                    }               
                    else if(component->GetComponentType() == TCPPT_TC_U_ERROR)
                    {
                        cout << "\n **** TEST: Received ERROR CPT **** \n";
                    }               
                    else if(component->GetComponentType() == TCPPT_TC_R_REJECT)
                    {
                        cout << "\n **** TEST: Received R REJECT CPT **** \n";
                    }               
                    else if(component->GetComponentType() == TCPPT_TC_RESULT_NL)
                    {
                        cout << "\n **** TEST: Received RESULT_NL CPT **** \n";
                    }               
                    else if(component->GetComponentType() == TCPPT_TC_RESULT_NL)
                    {
                        cout << "\n **** TEST: Received RESULT_NL CPT **** \n";
                    }               
                    else if(component->GetComponentType() == TCPPT_TC_U_REJECT)
                    {
                        cout << "\n **** TEST: Received U REJECT CPT **** \n";
                    }               
                    else if(component->GetComponentType() == TCPPT_TC_L_REJECT)
                    {
                        cout << "\n **** TEST: Received L REJECT CPT **** \n";
                    }               
#elif defined (ANSI)
                    if(component->GetComponentType() ==
                                                  TCPPT_TC_CANCEL)
                    {
                        TCAP_Cancel* lcancel = (TCAP_Cancel *) component;

                        cout << "\n **** TEST: Received CANCEL CPT **** \n";

                        delete lcancel;
                        component = NULL;
                    }
                    else if(component->GetComponentType() == TCPPT_TC_INVOKE)
                    {
                        cout << "\n **** TEST: Received INVOKE CPT **** \n";

                        if (isLoopMode)
                        {
                            TCAP_End       endDlg;
                            TCAP_Result    result;
                            TCAP_Dialogue* outbound;

                            endDlg.SetDialogueID(localDid);

                            outbound = &endDlg;

                            result.SetInvokeID(invokeId);

                            result.SetParameter(LocationArg, 
                                               sizeof(LocationArg)/sizeof(ITS_OCTET));
  
                            ret = TCAP_Component::Send(hdl, outbound, &result);
 
                            if(ret == ITS_SUCCESS)
                            {
                                 cout << "\n **** TEST: TCAP_Comp RESULT send successful ****"
                                      << endl;
                            }
                            else
                            {
                                 cout << "\n **** TEST: TCAP_Comp RESULT failed to send. ****"
                                      << endl;
                            }

                            cout << "**** Sending on DID " << did << endl;
 
                            ret = TCAP_Dialogue::Send(hdl, outbound);

                            if(ret != ITS_SUCCESS)
                            {
                                cout << "Failed to send Dialogue" << endl;
                            }
                            else
                            {
                                cout << "TCAP_TEST: Dialogue send succes PTYPE =" 
                                     << outbound->GetDialogueType() << endl;
                            }

                        }
                    }
                    else if(component->GetComponentType() == TCPPT_TC_RESULT_L)
                    {
                        cout << "\n **** TEST: Received RESULT LAST CPT **** \n";
                    }
                    else if(component->GetComponentType() == TCPPT_TC_ERROR)
                    {
                        cout << "\n **** TEST: Received ERROR CPT **** \n";
                    }
                    else if(component->GetComponentType() == TCPPT_TC_REJECT)
                    {
                        cout << "\n **** TEST: Received R REJECT CPT **** \n";
                    }
                    else if(component->GetComponentType() == TCPPT_TC_RESULT_NL)
                    {
                        cout << "\n **** TEST: Received RESULT_NL CPT **** \n";
                    }
                    else if(component->GetComponentType() == TCPPT_TC_RESULT_L)
                    {
                        cout << "\n **** TEST: Received RESULT_L CPT **** \n";
                    }
#endif
                    if (dialogue != NULL) 
                    {
                        delete dialogue;
                        dialogue = NULL;
                    }

                    if(component != NULL)
                    {
                        delete component;
                        component = NULL;
                    }

                    break;


                case ITS_TCAP_DLG:

                    TCAP_Dialogue::Receive(tqHandle, evt, &dialogue);

                    localDid = dialogue->GetDialogueID();

                    printf("******** Received on DID %d ********\n", localDid);
#if defined (CCITT)
                    if (dialogue->GetDialogueType() == TCPPT_TC_END)
                    {
                        cout << "\n **** TEST: Received END DLG ****\n";
                    }
                    else if (dialogue->GetDialogueType() == TCPPT_TC_BEGIN)
                    {
                        cout << "\n **** TEST: Received BEGIN DLG ****\n";
                    }
                    else if (dialogue->GetDialogueType() == TCPPT_TC_CONTINUE)
                    {
                        cout << "\n **** TEST: Received CONTINUE DLG ****\n";
                    }
                    else if (dialogue->GetDialogueType() == TCPPT_TC_U_ABORT)
                    {
                        cout << "\n **** TEST: Received U_ABORT DLG ****\n";
                    }
                    else if (dialogue->GetDialogueType() == TCPPT_TC_P_ABORT)
                    {
                        cout << "\n **** TEST: Received P_ABORT DLG ****\n";
                    }
#elif defined (ANSI)
                    if (dialogue->GetDialogueType() == TCPPT_TC_RESP)
                    {
                        cout << "\n **** TEST: Received END DLG ****\n";
                    }
                    else if (dialogue->GetDialogueType() == TCPPT_TC_QUERY_W_PERM)
                    {
                        cout << "\n **** TEST: Received BEGIN DLG ****\n";
                    }
                    else if (dialogue->GetDialogueType() == TCPPT_TC_CONV_W_PERM)
                    {
                        cout << "\n **** TEST: Received CONTINUE DLG ****\n";
                    }
                    else if (dialogue->GetDialogueType() == TCPPT_TC_ABORT)
                    {
                        cout << "\n **** TEST: Received U_ABORT DLG ****\n";
                    }
#endif
                    if (dialogue->IsComponentPresent())
                    {
                        cout << "\n **** TEST: DLG has COMPONENT ****\n";
                    }
                    else
                    {
                        cout << "\n **** TEST: DLG has NO COMPONENT ****\n";

                        delete dialogue;
                    }

                    break;
                }
            }
            else
            {
                cout << "\n **** TEST: Received unknown source ****" << endl;
            }
        }
        else
        {
            cout << "\n **** TEST: GetNextEvent Failed ****\n";
        }
    } 

    THREAD_NORMAL_EXIT;
}

void 
TCAP_Test::SendMsgs(ITS_HANDLE hdl)
{
    bool        hasInvoke = false;
    int         choice = 0;
    int         invokeCount =  1;

    TCAP_Dialogue* outbound;
    TCAP_Begin     beginDlg;    
    TCAP_End       endDlg;  
    TCAP_Continue  continueDlg;
    TCAP_Abort     abortDlg;

    int ret = ITS_SUCCESS;
    
    cout << endl;
    cout << "===> 1 - Initiate Transaction - TC_Begin.    <===\n";
    cout << "===> 2 - Close Transaction - TC_End.         <===\n";
    cout << "===> 3 - Continue Transaction - TC_Continue. <===\n";   
    cout << "===> 4 - Abort Transaction - TC_Abort.       <===\n";
    cout << "===> 5 - Sending Loop                        <===\n";
    cout << "===> 6 - Receive Loop                        <===\n";
    cin >> choice;

    if (SEND_VALID_CHOICE(choice))
    {
        switch (choice)
        {
        case SEND_ABORT:
        {
            ITS_USHORT localDid;

            cout << "\n======> Enter did : <======\n";
            cin >> localDid;
 
            printf("\n **** TEST: Sending ABORT, DID: %d ****\n", localDid);

            abortDlg.SetDialogueID(localDid);
           
            abortDlg.SetAbortReason(0x01);

            outbound = &abortDlg;

            break;
        }
        case RECV_LOOP:
        {
            isLoopMode = ITS_TRUE;

            break;
        }
        case SEND_LOOP:
        {
            TCAP_Invoke    invoke;
            int ret = ITS_SUCCESS;
            int i = 0;

            isLoopMode = ITS_TRUE; 

            for (i = 1; i <= LOOP_COUNT; i++)
            {
                hasInvoke = true;

                printf("\n ******** Allocated DID %d *******\n", did);

                ret = TCAP_AllocateDialogueId(&did);
                if (ret != ITS_SUCCESS)  
                {
                    printf("\n ******** Failed To Allocate DID ********\n");

                    break;
                }

                beginDlg.SetDialogueID(did);

                beginDlg.SetOrigAddr(cpa);
                beginDlg.SetDestAddr(cdp);

                outbound = &beginDlg;

                invoke.SetInvokeID(1);
 
#if defined(CCITT)
                invoke.SetOperation(2);
                invoke.SetClass(1);
#elif defined(ANSI)
                invoke.SetOperation(ITS_TRUE, 0x01, 0x02);
#endif    
                invoke.SetParameter(LocationArg, LOC_ARG_LEN);

                invoke.SetTimeOut(350);

                ret = TCAP_Component::Send(hdl, &beginDlg, &invoke);
                if(ret == ITS_SUCCESS)
                {
                    cout << "\n **** TEST: TCAP Send component successful *****" << endl;
                }
                else
                {
                   cout << "\n **** TEST: Component send failed ****" << endl;
                }

                cout << "**** Sending on DID " << did << endl;
 
                ret = TCAP_Dialogue::Send(hdl, outbound);

                if(ret != ITS_SUCCESS)
                {
                    cout << "Failed to send Dialogue" << endl;
                }
                else
                {
                    cout << "TCAP_TEST: Dialogue send succes PTYPE =" 
                         << outbound->GetDialogueType() << endl;
                }
            }
        }
        case SEND_BEGIN:
        {
            hasInvoke = true;
 
            TCAP_AllocateDialogueId(&did);
         
            printf("\n ******** Allocated DID %d *******\n", did);
 
            beginDlg.SetDialogueID(did);
 
            beginDlg.SetOrigAddr(cpa);
            beginDlg.SetDestAddr(cdp);

            outbound = &beginDlg;
            
            cout << "======> \n";
            cout << "======> How many invokes? <======\n";
            cin >> invokeCount;

            for (int i = 1; i <= invokeCount; i++)
            {
                TCAP_Invoke    invoke;
                int invokeId;
                int opClass;

                cout << "========> \n";
                cout << "========> Enter Invoke Id: <======== \n";
                cin >> invokeId;

                invoke.SetInvokeID(invokeId);
 
#if defined(CCITT)
                cout << "==========> \n";
                cout << "==========> Enter Operation Class (1, 2, 3 or 4): <======== \n";
                cin >> opClass;

                invoke.SetOperation(2);
                invoke.SetClass(opClass);
#elif defined(ANSI)
                invoke.SetOperation(ITS_TRUE, 0x01, 0x02);
#endif    
                invoke.SetParameter(LocationArg, LOC_ARG_LEN);

                invoke.SetTimeOut(350);


                ret = TCAP_Component::Send(hdl, &beginDlg, &invoke);
                if(ret == ITS_SUCCESS)
                {
                    cout << "\n **** TEST: TCAP Send component successful *****" << endl;
                }
                else
                {
                   cout << "\n **** TEST: Component send failed ****" << endl;
                }
            }

            break;
        }
        case SEND_END:
        {
            int numResult = 0, outcome = 0;
            int invokeId;
            ITS_USHORT localDid;

            cout << "======> \n";
            cout << "======> Enter did : <======\n";
            cin >> localDid;

            cout << "======> \n";
            cout << "======> OutCome of transaction (1-success, 0-failure) <======\n";
            cin >> outcome; 

            endDlg.SetDialogueID(localDid);

            outbound = &endDlg;

            if (outcome)
            {
                cout << "========> \n";
                cout << "========>How many Return Results? <========\n";
                cin >> numResult;

                for (int i = 1; i <= numResult; i++)
                {
                    TCAP_Result    result;

                    cout << "==========> \n";
                    cout << "==========> Enter Invoke Id: <==========\n";
                    cin >> invokeId;

                    result.SetInvokeID(invokeId);

#if defined(CCITT)
                    result.SetOperation(1);
#elif defined(ANSI)
#endif
                    result.SetParameter(LocationArg, sizeof(LocationArg)/sizeof(ITS_OCTET));
 
                    ret = TCAP_Component::Send(hdl, outbound, &result);

                    if(ret == ITS_SUCCESS)
                    {
                        cout << "\n **** TEST: TCAP_Comp RESULT send successful ****" << endl;
                    }
                    else
                    {
                        cout << "\n **** TEST: TCAP_Comp RESULT failed to send. ****" << endl;
                    }
                }
            }
            else
            {
                int failure = 0;

                cout << "==========> \n";
                cout << "==========> Choose RetError (0), or Reject (1). <==========\n";
                cin >> failure;
 
                if (failure)
                {
                    TCAP_Reject reject(false, false);

                    cout << "==========> \n";
                    cout << "==========> Enter Invoke Id: <==========\n";
                    cin >> invokeId;

                    reject.SetInvokeID(invokeId);

#if defined(CCITT)
                    reject.SetProblem(TCAP_PROB_GENERAL_CCITT,
                                      TCAP_PROB_SPEC_GEN_BADLY_STRUCT_COMP_CCITT);
#elif defined(ANSI)
                    reject.SetProblem(0x01, 0x02);
#endif
                    ret = TCAP_Component::Send(hdl, outbound, &reject);

                    if(ret == ITS_SUCCESS)
                    {
                        cout << "\n **** TEST: TCAP_Comp REJECT send successful ****" << endl;
                    }
                    else
                    {
                        cout << "\n **** TEST: TCAP_Comp REJECT failed to send ****" << endl;
                    }
                }
                else
                {
                    TCAP_Error error;

                    cout << "==========> \n";
                    cout << "==========> Enter Invoke Id: <==========\n";
                    cin >> invokeId;

                    error.SetInvokeID(invokeId);
#if defined(CCITT)
                    error.SetError(0x01);
#elif defined(ANSI)
                    error.SetError(ITS_TRUE, 0x01);
#endif
                    ret = TCAP_Component::Send(hdl, outbound, &error);

                    if(ret == ITS_SUCCESS)
                    {
                        cout << "\n **** TEST: TCAP_Comp ERROR send successful ****" << endl;
                    }
                    else
                    {
                        cout << "\n **** TEST: TCAP_Comp ERROR failed to send ****"  << endl;
                    }
                }
            }
            break;
        }
        case SEND_CONTINUE:
        {
            int numResult = 0;
            int numInvoke = 0;
            int invokeId;
            int i = 0;

            ITS_USHORT localDid;

            cout << "======> \n";
            cout << "======> Enter did : <======\n";
            cin >> localDid;

            cout << "======> \n";
            cout << "======>How many Return Results? \n";
            cin >> numResult;

            continueDlg.SetDialogueID(localDid);

            continueDlg.SetOPC(opc);
            outbound = &continueDlg;

            for (i = 1; i < numResult; i++)
            {
                TCAP_Result    result;

                cout << "Enter Invoke Id: \n";
                cin >> invokeId;
                
                result.SetInvokeID(invokeId);
#if defined(CCITT)
                result.SetOperation(1);
#elif defined(ANSI)
#endif
                result.SetParameter(LocationArg, sizeof(LocationArg)/sizeof(ITS_OCTET));
 
                ret = TCAP_Component::Send(hdl, outbound, &result);

                if(ret == ITS_SUCCESS)
                {
                    cout << "TCAP_Comp RESULT send success:" << endl;
                }
                else
                {
                    cout << "TCAP_Comp RESULT failed to send.:" << endl;
                }
            }

            TCAP_Result    result;

            cout << "Enter Invoke Id: \n";
            cin >> invokeId;

            result.SetInvokeID(invokeId);
#if defined(CCITT)
            result.SetOperation(1);
#elif defined(ANSI)
#endif 
            result.SetParameter(LocationArg, sizeof(LocationArg)/sizeof(ITS_OCTET));
 
            ret = TCAP_Component::Send(hdl, outbound, &result);

            if(ret == ITS_SUCCESS)
            {
                cout << "TCAP_Comp RESULT send success:" << endl;
            }
            else
            {
                cout << "TCAP_Comp RESULT failed to send.:" << endl;
            }
  
            cout << "How many Invokes? \n";
            cin >> numInvoke ;

            for (i = 1; i <= numInvoke; i++)
            {
                TCAP_Invoke    invoke;

                cout << "Enter Invoke Id: \n";
                cin >> invokeId;

                invoke.SetInvokeID(invokeId);
#if defined(CCITT)
                invoke.SetOperation(2); //Duplicate operation.
                invoke.SetClass(1);   //Class 2 operation.
#elif defined(ANSI)
                invoke.SetOperation(ITS_TRUE, 0x01, 0x02);
#endif 
                invoke.SetParameter(LocationArg, LOC_ARG_LEN);

                invoke.SetTimeOut(600);


                ret = TCAP_Component::Send(hdl, outbound, &invoke);
                if(ret == ITS_SUCCESS)
                {
                    cout << "TCAP Send component success" << endl;
                }
                else
                {
                   cout << "Component send failed :" << endl;
                }
            }
            break;

        }
        default:

            break;
        }
    }

    if (choice != RECV_LOOP)
    {
        cout << "**** Sending on DID " << did << endl;
 
        ret = TCAP_Dialogue::Send(hdl, outbound);

        if(ret != ITS_SUCCESS)
        {
            cout << "Failed to send Dialogue" << endl;
        }
        else
        {
            cout << "TCAP_TEST: Dialogue send succes PTYPE =" 
                 << outbound->GetDialogueType() << endl;
        }
    }

    return;
}

int 
TCAP_Test::getNextInvokeID()
{
   static int oct = 0;

   oct = (oct + 1) % 239;

   if(oct == 239) oct = 1;

   return oct;
}
 

void 
TCAP_Test::handleTimeouts()
{

}

its::ITS_Transport* 
TCAP_Test::getTQTransport()
{
   return new its::ITS_Transport((TRANSPORT_Control *)tqHandle);
}



THREAD_RET_TYPE 
TCAP_Test::dispatchOnBorder2(void *args)
{
   its::ITS_Event evt;

   createBorderTransport2(args, BORDER_INST_NUM2);

   if(borderHandle2 == NULL)
   {
      THREAD_NORMAL_EXIT;
   }

   its::ITS_Transport* tr = 
       new its::ITS_Transport((TRANSPORT_Control *)borderHandle2);

   while(tr->GetNextEvent(evt) == ITS_SUCCESS)
   {
       if(evt.GetSource() == ITS_SCCP_SRC)
       {
           evt.SetSource(ITS_MTP3_SRC);

           its::ITS_Transport::PutEvent(ITS_SCCP_SRC, evt);
       }
       else if(evt.GetSource() == ITS_TCAP_SRC)
       {
           cout << "Received TCAP source:" << endl;
       }
       else if(evt.GetSource() == ITS_MTP3_SRC)
       {
           its::ITS_Transport::PutEvent(ITS_SCCP_SRC, evt);

           cout << "Received MTP3 source:" << endl;
       }
       else
       {
           cout << "Received unknown source..." << endl;
           cout << "unknown source = " << evt.GetSource() << endl;
       }
   }

   cout << "GetNextEvent Failed" << endl;

   THREAD_NORMAL_EXIT;
}


THREAD_RET_TYPE 
TCAP_Test::dispatchOnBorder1(void *args)
{
   its::ITS_Event evt;

   createBorderTransport1(args, BORDER_INST_NUM1);

   if(borderHandle1 == NULL)
   {
      THREAD_NORMAL_EXIT;
   }

   its::ITS_Transport* tr = 
       new its::ITS_Transport((TRANSPORT_Control *)borderHandle1);

   while(tr->GetNextEvent(evt) == ITS_SUCCESS)
   {
       if(evt.GetSource() == ITS_SCCP_SRC)
       {
           evt.SetSource(ITS_MTP3_SRC);

           its::ITS_Transport::PutEvent(ITS_SCCP_SRC, evt);
       }
       else if(evt.GetSource() == ITS_TCAP_SRC)
       {
           cout << "Received TCAP source:" << endl;
       }
       else if(evt.GetSource() == ITS_MTP3_SRC)
       {
           its::ITS_Transport::PutEvent(ITS_SCCP_SRC, evt);

           cout << "Received MTP3 source:" << endl;
       }
       else
       {
           cout << "Received unknown source..." << endl;
           cout << "unknown source = " << evt.GetSource() << endl;
       }
   }

   cout << "GetNextEvent Failed" << endl;

   THREAD_NORMAL_EXIT;
}
   
void 
TCAP_Test::createBorderTransport1(void* args, ITS_INT inst)
{
   cout << "Border transport MASK = " << hex << borderMask << endl;

   borderHandle1 = ITS_Initialize(borderMask, inst);
}

void 
TCAP_Test::createBorderTransport2(void* args, ITS_INT inst)
{
   cout << "Border transport MASK = " << hex << borderMask << endl;

   borderHandle2 = ITS_Initialize(borderMask, inst);
}


void 
TCAP_Test::createTQTransport(void* args)
{
   ITS_UINT mask = ITS_TCAP | ITS_TRANSPORT_TQUEUE | ITS_TRANSPORT_SINGLE_USER;

   tqHandle = ITS_Initialize(mask, 1);
}

void sendTCAPPreArrangedEnd(ITS_HANDLE *tr, ITS_USHORT dlgid)
{
   TCAP_End end;

   end.SetDialogueID(dlgid);

   end.SetPreArrangedEnd(true);

   if(TCAP_Dialogue::Send((*tr), &end) == ITS_SUCCESS)
   {
      cout << "PreArragned END dialogue send success DlgID = " << dlgid << endl;
   }
   else
   {
      cout << "PREARRANGED END send failed for the DlgID = " << dlgid << endl;
   }
}
