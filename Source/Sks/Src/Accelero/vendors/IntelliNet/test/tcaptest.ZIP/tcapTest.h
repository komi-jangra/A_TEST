#ifndef TCAP_TEST_H
#define TCAP_TEST_H

#include <its++.h>

#include <iostream>
#include <stdlib.h>

#include <tcap++.h>
#include <sccp++.h>

#include <its_app.h>
#include <its_thread.h>
#include <its_mutex.h>

#include <its_ip_trans.h>
#include <its_sctp_trans.h>
#include <its_ss7_trans.h>
#include <its_imal_trans.h>
#include <its_timers.h>
#include <its_thread.h>


using namespace its;

#define SEND_BEGIN         1
#define SEND_END           2
#define SEND_CONTINUE      3
#define SEND_ABORT         4


#define SENDING_MODE       1
#define RECEIVING_MODE     2

#define SEND_VALID_CHOICE(x)     ((x >= 1) && (x <= 6))
#define MAIN_VALID_CHOICE(x)     ((x >= 1) && (x <= 2))

ITS_HANDLE  getITSHandle();

class TCAP_Test
{
  public:

     /*
      * mask for border transport and appName = application name.
      */
     TCAP_Test(ITS_UINT mask, char* appName = "tcaptest", int borderCount = 1);

     ~TCAP_Test();

     /*
      * Send TCAP messages.
      */
     void SendMsgs(ITS_HANDLE hdl);

     /*
      * handle Local cancel components.
      */     
     void handleTimeouts();

     its::ITS_Transport* getTQTransport();

  private:

     /*
      * Create a border transport(ss7 or sock).
      */
     static void createBorderTransport1(void*, ITS_INT);
     static void createBorderTransport2(void*, ITS_INT);
     /*
      * Create a TQUEUE transport with single user.
      */
     void createTQTransport(void* args);

     static THREAD_RET_TYPE dispatchOnBorder1(void* args);
     static THREAD_RET_TYPE dispatchOnBorder2(void* args);
     static THREAD_RET_TYPE  ReceiveMsgs(void *arg);

     int getNextInvokeID();

     its::ITS_Thread* borderThr1;
     its::ITS_Thread* borderThr2;

     its::ITS_Thread* recvThread;

     its::SCCP_CalledPartyAddr  cdp;

     its::SCCP_CallingPartyAddr cpa;
};


#endif
