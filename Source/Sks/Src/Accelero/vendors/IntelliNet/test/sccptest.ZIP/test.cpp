#include <stdlib.h>
#include <iostream>
#include <time.h>
#include <sys/timeb.h>
#include <string>
#include <map>

#include <its.h>
#include <its++.h>
#include <engine.h>
#include <its_thread_pool.h>
#include <its_work_item.h>
#include <its_mutex.h>


extern "C"
{
int
main(int argc, const char **argv)
{
const char *fn;
//        APPL_SetConfigDir("/opt/pkelly/cvsroot/xmlrecv/xml/");
	APPL_SetName("engine");
        APPL_SetConfigFileExtension("xml");
	fn = APPL_GetConfigFileName();
	printf("Using Configuration File: %s \n", fn);
	ENGINE_Initialize(argc, argv, NULL, 0);
	ENGINE_Run(argc, argv);
	
	return (0);
} /* main */

}	/* extern "C" */


