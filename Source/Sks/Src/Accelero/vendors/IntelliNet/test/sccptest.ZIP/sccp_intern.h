/*********************************-*-C-*-************************************
 *                                                                          *
 *             Copyright 1997,1998 IntelliNet Technologies, Inc.            *
 *                            All Rights Reserved.                          *
 *             Manufactured in the United States of America.                *
 *       1990 W. New Haven Ste. 312, Melbourne, Florida, 32904 U.S.A.       *
 *                                                                          *
 *   This product and related documentation is protected by copyright and   *
 *   distributed under licenses restricting its use, copying, distribution  *
 *   and decompilation.  No part of this product or related documentation   *
 *   may be reproduced in any form by any means without prior written       *
 *   authorization of IntelliNet Technologies and its licensors, if any.    *
 *                                                                          *
 *   RESTRICTED RIGHTS LEGEND:  Use, duplication, or disclosure by the      *
 *   government is subject to restrictions as set forth in subparagraph     *
 *   (c)(1)(ii) of the Rights in Technical Data and Computer Software       *
 *   clause at DFARS 252.227-7013 and FAR 52.227-19.                        *
 *                                                                          *
 ****************************************************************************
 *                                                                          *
 * CONTRACT: INTERNAL                                                       *
 *                                                                          *
 ****************************************************************************
 *
 *  ID: $Id: sccp_intern.h,v 4.3 2001/06/11 21:42:39 mmiers Exp $
 *
 * LOG: $Log: sccp_intern.h,v $
 * LOG: Revision 4.3  2001/06/11 21:42:39  mmiers
 * LOG: Pass the label to the callbacks.
 * LOG:
 * LOG: Revision 4.2  2001/05/10 16:53:58  mmiers
 * LOG: Add user intervention callbacks.
 * LOG:
 * LOG: Revision 4.1  2001/05/04 16:22:06  mmiers
 * LOG: Start PR5.
 * LOG:
 * LOG: Revision 3.5  2001/04/02 21:20:24  mmiers
 * LOG: Align the string names.
 * LOG:
 * LOG: Revision 3.4  2001/03/28 21:11:26  mmiers
 * LOG: Change the names to match config.
 * LOG:
 * LOG: Revision 3.3  2001/02/06 18:04:31  mmiers
 * LOG: Add locks for CO SCCP and TCAP contexts.  Next, to use them.
 * LOG:
 * LOG: Revision 3.2  2000/11/14 00:18:19  mmiers
 * LOG: Try to recover
 * LOG:
 * LOG: Revision 3.2  2000/10/20 22:23:15  omayor
 * LOG: Add SOR, SOG SCMG procedure for duplicate SSN. Also LUDT, LUDTS
 * LOG: procedures for ITU SCCP
 * LOG:
 * LOG: Revision 3.1  2000/08/16 00:09:42  mmiers
 * LOG:
 * LOG: Begin round 4.
 * LOG:
 * LOG: Revision 2.1  1999/12/06 21:30:11  mmiers
 * LOG:
 * LOG:
 * LOG: Debug with HP's GDI.
 * LOG:
 * LOG: Revision 1.39.2.1  1999/12/06 21:27:32  mmiers
 * LOG:
 * LOG:
 * LOG: Debug with HP's GDI.
 * LOG:
 * LOG: Revision 1.39  1999/08/27 00:51:22  mmiers
 * LOG:
 * LOG:
 * LOG: Commit more work, mostly just formatting, but include ies in
 * LOG: GTT callback.  User can really get himself in trouble now.
 * LOG:
 * LOG: Revision 1.38  1999/08/26 23:45:03  labuser
 * LOG:
 * LOG:
 * LOG: Alter GTT to include original PC (if any) and SSN (if any).
 * LOG:
 * LOG: Revision 1.37  1999/08/26 19:58:49  rsonak
 * LOG:
 * LOG:
 * LOG: Some protocol fixes.
 * LOG:
 * LOG: Revision 1.36  1999/06/29 15:24:23  mmiers
 * LOG:
 * LOG:
 * LOG: Modify global title behavior a bit (allow setting of DPC only).
 * LOG:
 * LOG: Revision 1.35  1999/03/24 22:46:35  mmiers
 * LOG:
 * LOG:
 * LOG: Clean up the SST queue when terminating.
 * LOG:
 * LOG: Revision 1.34  1999/03/17 20:55:08  mmiers
 * LOG:
 * LOG:
 * LOG: More dual protocol stuff.
 * LOG:
 * LOG: Revision 1.33  1999/03/17 18:39:54  mmiers
 * LOG:
 * LOG:
 * LOG: Dual protocol commit.  Still have to finish TCAP.
 * LOG:
 * LOG: Revision 1.32  1998/11/13 17:05:42  mmiers
 * LOG: Fix bad timer message.
 * LOG:
 * LOG: Revision 1.31  1998/11/13 02:49:42  mmiers
 * LOG: Do SST.
 * LOG:
 * LOG: Revision 1.30  1998/11/11 03:47:27  mmiers
 * LOG: Clean up some SCCP stuff.
 * LOG:
 * LOG: Revision 1.29  1998/11/11 00:45:30  mmiers
 * LOG: Work on CPC/CSSN information.
 * LOG:
 * LOG: Revision 1.28  1998/11/10 03:26:39  mmiers
 * LOG: Update/include the string defines.
 * LOG:
 * LOG: Revision 1.27  1998/11/10 02:23:02  mmiers
 * LOG: Fix IT timers, rework stack-sent messages, add guard timer, add
 * LOG: behavior control.
 * LOG:
 * LOG: Revision 1.26  1998/11/09 23:30:23  mmiers
 * LOG: Put in intermediate node code.
 * LOG:
 * LOG: Revision 1.25  1998/10/28 23:51:47  mmiers
 * LOG: Halfway through SCMG.
 * LOG:
 * LOG: Revision 1.24  1998/10/20 02:29:40  mmiers
 * LOG: Add prototype for SCMG function.
 * LOG:
 * LOG: Revision 1.23  1998/10/19 00:40:37  mmiers
 * LOG: Strengthen for PCLASS_3
 * LOG:
 * LOG: Revision 1.22  1998/10/16 20:45:22  mmiers
 * LOG: The "NEW! And IMPROVED!" SCCP.  Let the bug reports begin.
 * LOG:
 * LOG: Revision 1.21  1998/10/15 01:45:03  mmiers
 * LOG: Add -D_REENTRANT for alpha.  Add connRef to SCCP_CONN_CTXT.
 * LOG:
 * LOG: Revision 1.20  1998/10/15 01:19:16  mmiers
 * LOG: Remove assert().  We shouldn't terminate, we should gracefully work
 * LOG: around errors.
 * LOG:
 * LOG: More work on SCCP COC.  Added connection timer, release timer,
 * LOG: reset timer.  Check for proper handling of missing information.
 * LOG:
 * LOG: Revision 1.19  1998/10/14 23:29:37  mmiers
 * LOG: Set trace levels from INI file.
 * LOG:
 * LOG: Revision 1.18  1998/09/30 02:41:01  mmiers
 * LOG: Compromise on what we can do with SCCP.
 * LOG:
 * LOG: Revision 1.17  1998/09/29 01:24:58  mmiers
 * LOG: Implement needed MTP3 functionality.
 * LOG:
 * LOG: Revision 1.16  1998/09/28 17:37:52  mmiers
 * LOG: More work on SCCP.  Starting to take better shape.
 * LOG:
 * LOG: Revision 1.15  1998/09/28 16:25:24  mmiers
 * LOG: Add information to debug output.
 * LOG:
 * LOG: Revision 1.14  1998/09/27 00:53:11  mmiers
 * LOG: Start cleaning up connectionless.
 * LOG:
 * LOG: Revision 1.13  1998/09/27 00:04:10  mmiers
 * LOG: More work on SCCP.
 * LOG:
 * LOG: Revision 1.12  1998/09/25 21:10:57  mmiers
 * LOG: Fixup for trace.
 * LOG:
 * LOG: Revision 1.11  1998/09/24 23:27:30  mmiers
 * LOG: Continue work on improved SCCP.
 * LOG:
 * LOG: Revision 1.10  1998/09/24 19:24:38  mmiers
 * LOG: More work on SCCP.
 * LOG:
 * LOG: Revision 1.9  1998/09/24 17:31:50  mmiers
 * LOG: More working with SCCP.
 * LOG:
 * LOG: Revision 1.8  1998/09/24 16:33:11  mmiers
 * LOG: Rearrange vendor lib a little for smarter SCCP.
 * LOG:
 * LOG: Revision 1.7  1998/09/18 22:47:58  mmiers
 * LOG: Add tracing.
 * LOG:
 * LOG: Revision 1.6  1998/09/10 21:00:25  whu
 * LOG: Must have point code when handling UDT, XUDT messages in SCCP.  Need to
 * LOG: check that the PC received in a UDT is the "localPC" in TCAP.  HOLE.
 * LOG:
 * LOG: Revision 1.5  1998/09/06 20:05:48  mmiers
 * LOG: Convert to using ROUTE_SendToApplication where possible.
 * LOG:
 * LOG: Revision 1.4  1998/07/21 21:28:29  mmiers
 * LOG: Modify SCCP implementation.
 * LOG:
 * LOG: Revision 1.3  1998/07/03 19:42:19  mmiers
 * LOG: SCCP as a separate thread.
 * LOG:
 * LOG: Revision 1.2  1998/06/30 22:47:00  mmiers
 * LOG: Start adding SCCP-as-a-thread infrastructure.
 * LOG:
 * LOG: Revision 1.1  1998/06/22 14:58:33  mmiers
 * LOG: Forgot to add this file.
 * LOG:
 *
 ****************************************************************************/

#ifndef SCCP_INTERN_H
#define SCCP_INTERN_H

#if defined(__cplusplus)
extern "C"
{
#endif

#include <its_timers.h>
#include <its_trace.h>

#include <ansi/mtp3.h>
#include <itu/mtp3.h>

/*
 * SCCP RIDs
 */
#define SCCP_CONN_RID    1
#define SCCP_CPC_RID     2
#define SCCP_LPC_RID     3

/*
 * SCCP Tracing information
 */
extern TRACE_Data* SCCP_CCITT_TraceData;
extern TRACE_Data* SCCP_ANSI_TraceData;

#define SCCP_TRACE_CRITICAL  0
#define SCCP_TRACE_ERROR     1
#define SCCP_TRACE_WARNING   2
#define SCCP_TRACE_DEBUG     3

#if defined(CCITT)

#define SCCP_CRITICAL(args) \
    TRACE(SCCP_CCITT_TraceData, SCCP_TRACE_CRITICAL, args)

#define SCCP_ERROR(args) \
    TRACE(SCCP_CCITT_TraceData, SCCP_TRACE_ERROR, args)

#define SCCP_WARNING(args) \
    TRACE(SCCP_CCITT_TraceData, SCCP_TRACE_WARNING, args)

#define SCCP_DEBUG(args) \
    TRACE(SCCP_CCITT_TraceData, SCCP_TRACE_DEBUG, args)

#elif defined(ANSI)

#define SCCP_CRITICAL(args) \
    TRACE(SCCP_ANSI_TraceData, SCCP_TRACE_CRITICAL, args)

#define SCCP_ERROR(args) \
    TRACE(SCCP_ANSI_TraceData, SCCP_TRACE_ERROR, args)

#define SCCP_WARNING(args) \
    TRACE(SCCP_ANSI_TraceData, SCCP_TRACE_WARNING, args)

#define SCCP_DEBUG(args) \
    TRACE(SCCP_ANSI_TraceData, SCCP_TRACE_DEBUG, args)

#endif

/*
 * resource file keys
 */
#define SCCP_TRACE_CRITICAL_STRING  ITS_TRACE_CRITICAL_STRING
#define SCCP_TRACE_ERROR_STRING     ITS_TRACE_ERROR_STRING
#define SCCP_TRACE_WARNING_STRING   ITS_TRACE_WARNING_STRING
#define SCCP_TRACE_DEBUG_STRING     ITS_TRACE_DEBUG_STRING

#define SCCP_TSTAT_INFO_STRING      "TstatInfo"
#define SCCP_TCOORD_CHG_STRING      "TcoordChg"
#define SCCP_TIGNORE_SST_STRING     "TignoreSST"
#define SCCP_TRTG_STAT_INFO_STRING  "TrtgStatInfo"
#define SCCP_TCONN_STRING           "Tconnect"
#define SCCP_TRESET_STRING          "Treset"
#define SCCP_TRELEASE_STRING        "Trelease"
#define SCCP_TINACT_SEND_STRING     "Tias"
#define SCCP_TINACT_RECV_STRING     "Tiar"
#define SCCP_TGUARD_STRING          "Tguard"
#define SCCP_TREASSEM_STRING        "Treassembly"
#define SCCP_TINTERVAL_STRING       "Tinterval"
#define SCCP_TREPEAT_REL_STRING     "TrepeatRelease"


#define SCCP_CRITICAL_STRING        ITS_CRITICAL_STRING
#define SCCP_ERROR_STRING           ITS_ERROR_STRING
#define SCCP_WARNING_STRING         ITS_WARNING_STRING
#define SCCP_DEBUG_STRING           ITS_DEBUG_STRING

#define SCCP_STDOUT_STRING          ITS_STDOUT_STRING
#define SCCP_FILE_STRING            ITS_FILE_STRING

#if defined(CCITT)

#define SCCP_TRACE_CRITICAL_FILE    ".itu-sccp-traceCritical"
#define SCCP_TRACE_ERROR_FILE       ".itu-sccp-traceError"
#define SCCP_TRACE_WARNING_FILE     ".itu-sccp-traceWarning"
#define SCCP_TRACE_DEBUG_FILE       ".itu-sccp-traceDebug"

#elif defined(ANSI)

#define SCCP_TRACE_CRITICAL_FILE    ".ansi-sccp-traceCritical"
#define SCCP_TRACE_ERROR_FILE       ".ansi-sccp-traceError"
#define SCCP_TRACE_WARNING_FILE     ".ansi-sccp-traceWarning"
#define SCCP_TRACE_DEBUG_FILE       ".ansi-sccp-traceDebug"

#endif

#define SCCP_PROPAGATE_ERR_STRING   "PropagateERR"
#define SCCP_PROPAGATE_IT_STRING    "PropagateIT"
#define SCCP_PROPAGATE_SCMG_STRING  "PropagateSCMG"
#define SCCP_ENABLE_SCMG_STRING     "EnableSCMG"

/*
 * states
 */
typedef enum
{
    SCCP_CONN_IDLE,
    SCCP_CONN_IN_PEND,
    SCCP_CONN_OUT_PEND,
    SCCP_DATA_TRANSFER,
    SCCP_IN_RESET_PEND,
    SCCP_OUT_RESET_PEND,
    SCCP_IN_RELEASE_PEND,
    SCCP_OUT_RELEASE_PEND
}
SCCP_CONN_STATE;

typedef enum
{
    SCCP_DATA_NORMAL,
    SCCP_DATA_IN_ED,
    SCCP_DATA_OUT_ED,
    SCCP_DATA_BOTH_ED
}
SCCP_DATA_STATE;

/*
 * fragmentation/reassembly
 */
typedef struct _SCCP_Frag
{
    struct _SCCP_Frag*  next;
    ITS_OCTET           data[SCCP_MAX_DATA];
}
SCCP_DATA_FRAG;

/*
 * connection context
 */
typedef struct
{
    ITS_MUTEX       lock;
    MTP3_HEADER     inLabel;
    MTP3_HEADER     outLabel;
    ITS_USHORT      connRef;
    ITS_USHORT      assocRef;
    SCCP_CONN_STATE state;
    SCCP_DATA_STATE dataState;
    ITS_SERIAL      connectTimer;
    ITS_SERIAL      releaseTimer;
    ITS_SERIAL      resetTimer;
    ITS_SERIAL      sendInactivity;
    ITS_SERIAL      receiveInactivity;
    ITS_BOOLEAN     isIntermediate;
    ITS_BOOLEAN     sequenceOn;
    ITS_UINT        slref;
    ITS_UINT        dlref;
    SCCP_DATA_FRAG* fragList;
    SCCP_ADDR       oaddr;
    SCCP_ADDR       daddr;
    ITS_OCTET       sequenceSLS;
    ITS_OCTET       windowSize;
    ITS_OCTET       pclass;
    ITS_OCTET       fsn;
    ITS_OCTET       rsn;
}
SCCP_CONN_CTXT;

/*
 * generic SCCP functions.
 */
void SCCP_DeleteLocalReference_ANSI(ITS_USHORT cref);
void SCCP_DeleteLocalReference_CCITT(ITS_USHORT cref);

int ANSI_SCCPHandleAPPMsg_ANSI(ITS_EVENT *ev);
int ANSI_SCCPHandleMTP3Msg_ANSI(ITS_EVENT *ev);

int SCCPHandleAPPMsg_CCITT(ITS_EVENT *ev);
int SCCPHandleMTP3Msg_CCITT(ITS_EVENT *ev);

int SCCP_GTTTranslate_ANSI(MTP3_HEADER_ANSI *mtp3,
                           ITS_UINT *dpc, ITS_OCTET ai,
                           ITS_UINT pc, ITS_OCTET ssn,
                           ITS_OCTET* gttInfo, ITS_USHORT gttLen,
                           SCCP_ADDR* transAddr,
                           ITS_SCCP_IE *ies, int ieCount);
int SCCP_GTTTranslate_CCITT(MTP3_HEADER_CCITT *mtp3,
                            ITS_UINT *dpc, ITS_OCTET ai,
                            ITS_UINT pc, ITS_OCTET ssn,
                            ITS_OCTET* gttInfo, ITS_USHORT gttLen,
                            SCCP_ADDR* transAddr,
                            ITS_SCCP_IE *ies, int ieCount);

int SCCP_UserIntervention_ANSI(MTP3_HEADER_ANSI *mtp3,
                               ITS_UINT pc, ITS_OCTET ssn,
                               SCCP_ADDR* transAddr,
                               ITS_SCCP_IE *ies, int ieCount);
int SCCP_UserIntervention_CCITT(MTP3_HEADER_CCITT *mtp3,
                                ITS_UINT pc, ITS_OCTET ssn,
                                SCCP_ADDR* transAddr,
                                ITS_SCCP_IE *ies, int ieCount);
/*
 * SCRC functions
 */
int SCRCHandleMTP3Msg_ANSI(ITS_EVENT* ev);
int SCRCHandleSCLCMsg_ANSI(MTP3_HEADER* mtp3, ITS_OCTET mType,
                           ITS_SCCP_IE* ies, int ieCount);
int SCRCHandleSCOCMsg_ANSI(MTP3_HEADER* mtp3, ITS_OCTET mType,
                           ITS_SCCP_IE* ies, int ieCount,
                           SCCP_ADDR* cdp);

/*
 * SCLC functions
 */
int SCLCHandleRoutingFailure_ANSI(MTP3_HEADER* mtp3, ITS_OCTET mType,
                                  ITS_SCCP_IE* ies, int ieCount,
                                  ITS_OCTET reason);
int SCLCHandleSCRCMsg_ANSI(MTP3_HEADER* mtp3, ITS_OCTET mType,
                           ITS_SCCP_IE* ies, int ieCount,
                           ITS_UINT pc, ITS_OCTET ssn);
int SCLCHandleSCMGMsg_ANSI(MTP3_HEADER* mtp3, ITS_OCTET mType,
                           ITS_SCCP_IE* ies, int ieCount);
int SCLCHandleAPPMsg_ANSI(ITS_EVENT* ev);

/*
 * SCOC functions
 */
int SCOCHandleRoutingFailure_ANSI(MTP3_HEADER* mtp3, ITS_OCTET mType,
                                  ITS_SCCP_IE* ies, int ieCount,
                                  ITS_OCTET reason);
int SCOCHandleSCRCMsg_ANSI(MTP3_HEADER* mtp3, ITS_OCTET mType,
                           ITS_SCCP_IE* ies, int ieCount,
                           ITS_UINT pc, ITS_OCTET ssn, ITS_BOOLEAN needCouple);
int SCOCHandleAPPMsg_ANSI(ITS_EVENT* ev);
int SCOCHandleTimer_ANSI(ITS_TimerData* td);

/*
 * SCMG functions
 */
int SCMGSSPCHandleMsgForProhibitedSSN_ANSI(MTP3_HEADER* mtp3, ITS_OCTET mType,
                                           ITS_SCCP_IE* ies, int ieCount,
                                           ITS_UINT pc, ITS_OCTET ssn,
                                           ITS_OCTET reason);
int SCMGHandleSCLCMsg_ANSI(MTP3_HEADER* mtp3, ITS_OCTET mType,
                           ITS_SCCP_IE* ies, int ieCount);
int SCMGHandleMTP3Msg_ANSI(MTP3_HEADER* mtp3, ITS_OCTET mType,
                           ITS_OCTET* data, ITS_USHORT len);
int SCMGHandleSSTTimeout_ANSI();
void SCMGCleanSSTInfo_ANSI();

/*
 * SCRC functions
 */
int SCRCHandleMTP3Msg_CCITT(ITS_EVENT* ev);
int SCRCHandleSCLCMsg_CCITT(MTP3_HEADER* mtp3, ITS_OCTET mType,
                            ITS_SCCP_IE* ies, int ieCount);
int SCRCHandleSCOCMsg_CCITT(MTP3_HEADER* mtp3, ITS_OCTET mType,
                            ITS_SCCP_IE* ies, int ieCount,
                            SCCP_ADDR* cdp);

/*
 * SCLC functions
 */
int SCLCHandleRoutingFailure_CCITT(MTP3_HEADER* mtp3, ITS_OCTET mType,
                                   ITS_SCCP_IE* ies, int ieCount,
                                   ITS_OCTET reason);
int SCLCHandleSCRCMsg_CCITT(MTP3_HEADER* mtp3, ITS_OCTET mType,
                            ITS_SCCP_IE* ies, int ieCount,
                            ITS_UINT pc, ITS_OCTET ssn);
int SCLCHandleSCMGMsg_CCITT(MTP3_HEADER* mtp3, ITS_OCTET mType,
                            ITS_SCCP_IE* ies, int ieCount);
int SCLCHandleAPPMsg_CCITT(ITS_EVENT* ev);

/*
 * SCOC functions
 */
int SCOCHandleRoutingFailure_CCITT(MTP3_HEADER* mtp3, ITS_OCTET mType,
                                   ITS_SCCP_IE* ies, int ieCount,
                                   ITS_OCTET reason);
int SCOCHandleSCRCMsg_CCITT(MTP3_HEADER* mtp3, ITS_OCTET mType,
                            ITS_SCCP_IE* ies, int ieCount,
                            ITS_UINT pc, ITS_OCTET ssn, ITS_BOOLEAN needCouple);
int SCOCHandleAPPMsg_CCITT(ITS_EVENT* ev);
int SCOCHandleTimer_CCITT(ITS_TimerData* td);

/*
 * SCMG functions
 */
int SCMGSSPCHandleMsgForProhibitedSSN_CCITT(MTP3_HEADER* mtp3, ITS_OCTET mType,
                                            ITS_SCCP_IE* ies, int ieCount,
                                            ITS_UINT pc, ITS_OCTET ssn,
                                            ITS_OCTET reason);
int SCMGHandleSCLCMsg_CCITT(MTP3_HEADER* mtp3, ITS_OCTET mType,
                            ITS_SCCP_IE* ies, int ieCount);
int SCMGHandleMTP3Msg_CCITT(MTP3_HEADER* mtp3, ITS_OCTET mType,
                            ITS_OCTET* data, ITS_USHORT len);
int SCMGHandleSSTTimeout_CCITT();
void SCMGCleanSSTInfo_CCITT();

#if defined(__cplusplus)
}
#endif

#endif /* SCCP_INTERN_H */
