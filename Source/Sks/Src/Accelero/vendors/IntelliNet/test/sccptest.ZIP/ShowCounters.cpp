#define CCITT 1
//#define ANSI 1

#include <stdlib.h>
#include <iostream>
#include <time.h>
#include <sys/timeb.h>
#include <string>
#include <map>

#include <its.h>
#include <its++.h>
#include <engine.h>
#include <its_thread_pool.h>
#include <its_work_item.h>
#include <its_mutex.h>
#include <PegCounters.h>


extern "C"
{


////////////////////////////////////////////////////////////////////////////////
//
//  Peg Counter Display
//
ITS_EVENT ev, *pev=&ev;

TCAP_DLG dlg, *pdlg=&dlg;

TCAP_CPT cpt, *pcpt=&cpt;

ITS_OCTET cptType;
ITS_OCTET group;
//#define TBLgrp(tid,n) typedef struct { unsigned char id; char *pname;} TAGTBL; TAGTBL grptbl_##tid[n+1] = { 

typedef struct { unsigned char id; char *pname;} TAGTBL, *PTAGTBL;

#define TBLgrp(tid,n) struct { unsigned char id; char *pname;} grptbl_##tid[n+1] = { 
#define TBLent(X, Y) X, Y,
#define TBLend 0, (char *) -1 }

#define TBLptr(n) struct {void *ptbl;} tblptrs[n+1] = {
#define TBLptrent(X) X, 
#define TBLptrend (char *) -1 }


#define REJdef(n)  struct { unsigned char type; unsigned char code;}  rejtbl[n+1] = { 
#define REJent(X, Y) X, Y,
#define REJend 0xFF, 0xFF }

#define REASONdef(n) struct { unsigned char reason;}  reasontbl[n+1] = { 
#define REASONent(X) X,
#define REASONend 0xFF }


	REJdef(19)
		REJent (TCAP_PROB_GENERAL_CCITT, TCAP_PROB_SPEC_GEN_UNREC_COMP_CCITT)
		REJent (TCAP_PROB_GENERAL_CCITT, TCAP_PROB_SPEC_GEN_MISTYPED_COMP_CCITT)
		REJent (TCAP_PROB_GENERAL_CCITT, TCAP_PROB_SPEC_GEN_BADLY_STRUCT_COMP_CCITT)
		REJent (TCAP_PROB_INVOKE_CCITT, TCAP_PROB_SPEC_INV_DUPLICATE_INV_ID_CCITT)
		REJent (TCAP_PROB_INVOKE_CCITT, TCAP_PROB_SPEC_INV_UNREC_OP_CODE_CCITT)
		REJent (TCAP_PROB_INVOKE_CCITT, TCAP_PROB_SPEC_INV_MISTYPED_PARAM_CCITT)
		REJent (TCAP_PROB_INVOKE_CCITT, TCAP_PROB_SPEC_INV_RESOURCE_LIMIT_CCITT)
		REJent (TCAP_PROB_INVOKE_CCITT, TCAP_PROB_SPEC_INV_INITIATE_RELEASE_CCITT)
		REJent (TCAP_PROB_INVOKE_CCITT, TCAP_PROB_SPEC_INV_UNREC_LINKED_ID_CCITT)
		REJent (TCAP_PROB_INVOKE_CCITT, TCAP_PROB_SPEC_INV_UNEXPECTED_LINK_RESP_CCITT)
		REJent (TCAP_PROB_INVOKE_CCITT, TCAP_PROB_SPEC_INV_UNEXPECTED_LINKED_OP_CCITT)
		REJent (TCAP_PROB_RETURN_RES_CCITT, TCAP_PROB_SPEC_RES_UNREC_INVOKE_ID_CCITT)
		REJent (TCAP_PROB_RETURN_RES_CCITT, TCAP_PROB_SPEC_RES_UNEXPECTED_RET_RES_CCITT)
		REJent (TCAP_PROB_RETURN_RES_CCITT, TCAP_PROB_SPEC_RES_MISTYPED_PARAM_CCITT)
		REJent (TCAP_PROB_RETURN_ERR_CCITT, TCAP_PROB_SPEC_ERR_UNREC_INVOKE_ID_CCITT)
		REJent (TCAP_PROB_RETURN_ERR_CCITT, TCAP_PROB_SPEC_ERR_UNEXPECTED_RET_ERROR_CCITT)
		REJent (TCAP_PROB_RETURN_ERR_CCITT, TCAP_PROB_SPEC_ERR_UNREC_ERROR_CCITT)
		REJent (TCAP_PROB_RETURN_ERR_CCITT, TCAP_PROB_SPEC_ERR_UNEXPECTED_ERROR_CCITT)
		REJent (TCAP_PROB_RETURN_ERR_CCITT, TCAP_PROB_SPEC_ERR_MISTYPED_PARAM_CCITT)
	REJend;


	REASONdef(3)
		REASONent(TCAP_UABT_AC_NOT_SUP_CCITT)
		REASONent(TCAP_UABT_DLG_REFUSED_CCITT)
		REASONent(TCAP_UABT_USER_DEFINED_CCITT)
	REASONend;


	PTAGTBL ptbl;


	theCOUNTERS mytheCounters;
	theCOUNTERS *pmytheCounters=&mytheCounters;
	miscCOUNTERS mymiscCounters;
	miscCOUNTERS *pmymiscCounters=&mymiscCounters;

	TBLgrp(msgGroup,41)
		TBLent(PEG_TOTAL_TCAP_MSGS, "Total All TCAP Messages")	
		TBLent(PEG_TOTAL_SCCP_MSGS, "Total All SCCP Messages")
		TBLent(PEG_TCAP_UNKNOWN_MSG, "TCAP Unknown")
		TBLent(PEG_SCCP_UNKNOWN_MSG, "SCCP Unknown")
		TBLent(TCAP_PT_TC_UNI_CCITT, "(0x61U)  TC-Uni") 
		TBLent(TCAP_PT_TC_BEGIN_CCITT, "(0x62U)  TC-Begin") 
		TBLent(TCAP_PT_TC_END_CCITT, "(0x64U)  TC-End") 
		TBLent(TCAP_PT_TC_CONTINUE_CCITT, "(0x65U)  TC-Continue") 
		TBLent(TCAP_PT_TC_P_ABORT_CCITT, "(0x67U)  TC-P-Abort") 
		TBLent(TCAP_PT_TC_U_ABORT_CCITT, "(0x68U)  TC-U-Abort") 
		TBLent(TCAP_PT_TC_NOTICE_CCITT, "(0x69U)  TC-Notice")
		TBLent(TCAP_PT_TC_UNI_ANSI, "(0xE1U)  TC-Uni") 
		TBLent(TCAP_PT_TC_QUERY_W_PERM_ANSI, "(0xE2U)  TC-Query-WIP") 
		TBLent(TCAP_PT_TC_QUERY_WO_PERM_ANSI, "(0xE3U)  TC-Query-WOP")
		TBLent(TCAP_PT_TC_RESP_ANSI, "(0xE4U)  TC-Resp") 
		TBLent(TCAP_PT_TC_CONV_W_PERM_ANSI, "(0xE5U)  TC-Conv-WIP") 
		TBLent(TCAP_PT_TC_CONV_WO_PERM_ANSI, "(0xE6U)  TC-Conv-WOP") 
		TBLent(TCAP_PT_TC_ABORT_ANSI, "(0xE6U)  TC-Conv-WOP") 
		TBLent(TCAP_PT_TC_NOTICE_ANSI, "(0xE8U)  TC-Notice") 
		TBLent(SCCP_MSG_CR, "(0x01U) Connection Request")
		TBLent(SCCP_MSG_CC, "(0x02U) Conection Confirm")
		TBLent(SCCP_MSG_CREF, "(0x03U) Connection REFused")
		TBLent(SCCP_MSG_RLSD, "(0x04U) ReLeaSed")
		TBLent(SCCP_MSG_RLC, "(0x05U) ReLease Complete")
		TBLent(SCCP_MSG_DT1, "(0x06U) DaTa form 1")
		TBLent(SCCP_MSG_DT2, "(0x07U) DaTa form 2")
		TBLent(SCCP_MSG_AK, "(0x08U) AcKnowledgement")
		TBLent(SCCP_MSG_UDT, "(0x09U) Unit DaTa")
		TBLent(SCCP_MSG_UDTS, "(0x0AU) Unit DaTa Service")
		TBLent(SCCP_MSG_ED, "(0x0BU) Expedited Data")
		TBLent(SCCP_MSG_EA, "(0x0CU) Expedited data Acknowledgement")
		TBLent(SCCP_MSG_RSR, "(0x0DU) ReSet Request")
		TBLent(SCCP_MSG_RSC, "(0x0EU) ReSet Confirmation")
		TBLent(SCCP_MSG_ERR, "(0x0FU) ERRor")
		TBLent(SCCP_MSG_IT, "(0x10U) Inactivity Test")
		TBLent(SCCP_MSG_XUDT, "(0x11U) eXtended Unit DaTa")
		TBLent(SCCP_MSG_XUDTS, "(0x12U) eXtended Unit DaTa Service")
		TBLent(SCCP_MSG_LUDT, "(0x13U) Long Unitdata message")
		TBLent(SCCP_MSG_LUDTS, "(0x14U) Long Unitdata Service Msg")
		TBLent(SCCP_MSG_NOTICE, "(0xFFU) Notice from MTP3/to user")
	TBLend;

	TBLgrp(scmgGroup,13)
		TBLent(PEG_TOTAL_SCMG_MSGS, "Total All SCMG Messages")
		TBLent(PEG_SCMG_UNKNOWN_MSG, "SCMG Unknown")
		TBLent(SCCP_SCMG_SS_ALLOWED, "(0x01U) SubSystem Allowed")
		TBLent(SCCP_SCMG_SS_PROHIBIT, "(0x02U) SubSystem Prohibited")
		TBLent(SCCP_SCMG_SS_STATUS_TEST, "(0x03U) SubSystem Status Test")
		TBLent(SCCP_SCMG_SS_OOS_REQ, "(0x04U) SubSystem Out Of Service Request")
		TBLent(SCCP_SCMG_SS_OOS_GRANT, "(0x05U) SubSystem Out Of Service Grant")
		TBLent(SCCP_SCMG_SS_BACKUP_ROUTE, "(0xFDU) SubSystem Backup Routing")
		TBLent(SCCP_SCMG_SS_NORMAL_ROUTE, "(0xFEU) SubSystem  Normal Routing")
		TBLent(SCCP_SCMG_SS_ROUTE_STATUS, "(0xFFU) SubSystem Route Status")  
		TBLent(SCCP_SCMG_SS_UIS, "(0xF0U)	  User In Service")
		TBLent(SCCP_SCMG_SS_UOS, "(0xF1U)   User Out of Service")
		TBLent(SCCP_SCMG_SS_CONG, "(0xF2U)	  User Congested")
	TBLend;


	TBLgrp(cptGroup,19)
		TBLent(PEG_TOTAL_CMPS,"Total All Components")
		TBLent(TCAP_PT_TC_INVOKE_CCITT, "(0xA1U)  TC-Invoke") 
		TBLent(TCAP_PT_TC_RESULT_L_CCITT, "(0xA2U)  TC-Result-L")
		TBLent(TCAP_PT_TC_U_ERROR_CCITT, "(0xA3U)  TC-U-Error") 
		TBLent(TCAP_PT_TC_R_REJECT_CCITT, "(0xA4U)  TC-R-Reject") 
		TBLent(TCAP_PT_TC_RESULT_NL_CCITT, "(0xA7U)  TC-Result-NL") 
		TBLent(TCAP_PT_TC_L_CANCEL_CCITT, "(0xA8U)  TC-L-Cancel") 
		TBLent(TCAP_PT_TC_U_CANCEL_CCITT, "(0xA9U)  TC-U-Cancel") 
		TBLent(TCAP_PT_TC_L_REJECT_CCITT, "(0xAAU)  TC-L-Reject") 
		TBLent(TCAP_PT_TC_U_REJECT_CCITT, "(0xABU)  TC-U-Reject") 
		TBLent(TCAP_PT_TC_TIMER_RESET_CCITT, "(0xACU)  TC-Timer-Reset") 
		TBLent(TCAP_PT_TC_INVOKE_ANSI, "(0xE9U)  TC-Invoke-L")
		TBLent(TCAP_PT_TC_RESULT_L_ANSI, "(0xEAU)  TC-Result-L")
		TBLent(TCAP_PT_TC_ERROR_ANSI, "(0xEBU)  TC-Error") 
		TBLent(TCAP_PT_TC_REJECT_ANSI, "(0xECU)  TC-Reject") 
		TBLent(TCAP_PT_TC_INVOKE_NL_ANSI, "(0xEDU)  TC-Invoke-NL")
		TBLent(TCAP_PT_TC_RESULT_NL_ANSI, "(0xEEU)  TC-Result-NL :") 
		TBLent(TCAP_PT_TC_CANCEL_ANSI, "(0xEFU) this doesn't exist but several vendors use it")
	TBLend;


	TBLgrp(reasonABTGroup,0)
	TBLend;


	TBLgrp(reasonUABTGroup,3)
		TBLent(TCAP_UABT_AC_NOT_SUP_CCITT, "1 - Application context not supported")
		TBLent(TCAP_UABT_DLG_REFUSED_CCITT, "2 - Dialogue refused")
		TBLent(TCAP_UABT_USER_DEFINED_CCITT, "3 - User defined")
	TBLend;

	TBLgrp(reasonPABTGroup,7)
		TBLent(TCAP_ABT_REASON_UNREC_MSG_TYPE_CCITT, "(0x00U) UNREC_MSG_TYPE")
		TBLent(TCAP_ABT_REASON_UNREC_TRANS_ID_CCITT, "(0x01U) UNREC_TRANS_ID")
		TBLent(TCAP_ABT_REASON_BADLY_STRUCT_TRANS_PORT_CCITT, "(0x02U) BADLY_STRUCT_TRANS_PORT")
		TBLent(TCAP_ABT_REASON_INCORRECT_TRANS_PORT_CCITT, "(0x03U) INCORRECT_TRANS_PORT")
		TBLent(TCAP_ABT_REASON_RES_UNAVAIL_CCITT, "(0x04U) RES_UNAVAIL")
		TBLent(TCAP_PABT_ABNORMAL_DLG_CCITT, "(126) ABNORMAL_DLG")
		TBLent(TCAP_PABT_NO_COMMON_DLG_CCITT, "(127) NO_COMMON_DLG")
	TBLend;

	TBLgrp(rejCodeResGroup,3)
		TBLent(TCAP_PROB_SPEC_RES_UNREC_INVOKE_ID_CCITT, "(0x00U) RES_UNREC_INVOKE_ID")
		TBLent(TCAP_PROB_SPEC_RES_UNEXPECTED_RET_RES_CCITT, "(0x01U) RES_UNEXPECTED_RET_RES")
		TBLent(TCAP_PROB_SPEC_RES_MISTYPED_PARAM_CCITT, "(0x02U) RES_MISTYPED_PARAM")
	TBLend;

	TBLgrp(rejCodeGenGroup,3)
		TBLent(TCAP_PROB_SPEC_GEN_UNREC_COMP_CCITT, "(0x00U) GEN_UNREC_COMP")
		TBLent(TCAP_PROB_SPEC_GEN_MISTYPED_COMP_CCITT, "(0x01U) GEN_MISTYPED_COMP")
		TBLent(TCAP_PROB_SPEC_GEN_BADLY_STRUCT_COMP_CCITT, "(0x02U) GEN_BADLY_STRUCT_COMP")
	TBLend;

	TBLgrp(rejCodeInvGroup,8)
		TBLent(TCAP_PROB_SPEC_INV_DUPLICATE_INV_ID_CCITT, "(0x00U) INV_DUPLICATE_INV_ID")
		TBLent(TCAP_PROB_SPEC_INV_UNREC_OP_CODE_CCITT, " (0x01U) INV_UNREC_OP_CODE")
		TBLent(TCAP_PROB_SPEC_INV_MISTYPED_PARAM_CCITT, "(0x02U) INV_MISTYPED_PARAM")
		TBLent(TCAP_PROB_SPEC_INV_RESOURCE_LIMIT_CCITT, "(0x03U) INV_RESOURCE_LIMIT")
		TBLent(TCAP_PROB_SPEC_INV_INITIATE_RELEASE_CCITT, "(0x04U) INV_INITIATE_RELEASE")
		TBLent(TCAP_PROB_SPEC_INV_UNREC_LINKED_ID_CCITT, "(0x05U) INV_UNREC_LINKED_ID")
		TBLent(TCAP_PROB_SPEC_INV_UNEXPECTED_LINK_RESP_CCITT, "(0x06U) INV_UNEXPECTED_LINK_RESP")
		TBLent(TCAP_PROB_SPEC_INV_UNEXPECTED_LINKED_OP_CCITT, "(0x07U) INV_UNEXPECTED_LINKED_OP")
	TBLend;


	TBLgrp(rejCodeErrGroup,5)
		TBLent(TCAP_PROB_SPEC_ERR_UNREC_INVOKE_ID_CCITT, "(0x00U) ERR_UNREC_INVOKE_ID")
		TBLent(TCAP_PROB_SPEC_ERR_UNEXPECTED_RET_ERROR_CCITT, "(0x01U) ERR_UNEXPECTED_RET_ERROR")
		TBLent(TCAP_PROB_SPEC_ERR_UNREC_ERROR_CCITT, "(0x02U) ERR_UNREC_ERROR")
		TBLent(TCAP_PROB_SPEC_ERR_UNEXPECTED_ERROR_CCITT, "(0x03U) ERR_UNEXPECTED_ERROR")
		TBLent(TCAP_PROB_SPEC_ERR_MISTYPED_PARAM_CCITT, "(0x04U) ERR_MISTYPED_PARAM")
	TBLend;


	TBLgrp(rejCodeTransGroup,0)
	TBLend;


	TBLgrp(miscGroup,66)
		TBLent(PEG_TCAP_ACTIVE_DIALOGUE, "TCAP_ACTIVE_DIALOGUE")
		TBLent(PEG_TCAP_ACTIVATED_DIALOGUE, "TCAP_ACTIVATED_DIALOGUE")
		TBLent(PEG_TCAP_ACTIVE_TRANSACTIONS, "TCAP_ACTIVE_TRANSACTIONS")
		TBLent(PEG_TCAP_ACTIVATED_TRANSACTIONS, "TCAP_ACTIVATED_TRANSACTIONS")
		TBLent(PEG_TCAP_INV_CLASS_1_SENT, "TCAP_INV_CLASS_1 SENT")
		TBLent(PEG_TCAP_INV_CLASS_2_SENT, "TCAP_INV_CLASS_2 SENT")
		TBLent(PEG_TCAP_INV_CLASS_3_SENT, "TCAP_INV_CLASS_3 SENT")
		TBLent(PEG_TCAP_INV_CLASS_4_SENT, "TCAP_INV_CLASS_4 SENT")
		TBLent(PEG_TCAP_INV_CONTEXT, "TCAP_INV_CONTEXT")
		TBLent(PEG_TCAP_INV_CONTEXT_ACTIVE, "TCAP_INV_CONTEXT_ACTIVE")
		TBLent(PEG_TCAP_SEND_DIALOGUE, "TCAP_SEND_DIALOGUE")
		TBLent(PEG_TCAP_RECEIVE_DIALOGUE, "TCAP_RECEIVE_DIALOGUE")
		TBLent(PEG_TCAP_SEND_COMPONENT, "TCAP_SEND_COMPONENT")
		TBLent(PEG_TCAP_RECEIVE_COMPONENT, "TCAP_RECEIVE_COMPONENT")
		TBLent(PEG_TCAP_RECEIVE_UDT, "TCAP_RECEIVE_UDT")
		TBLent(PEG_TCAP_RECEIVE_XUDT, "TCAP_RECEIVE_XUDT")
		TBLent(PEG_TCAP_RECEIVE_UDTS, "TCAP_RECEIVE_UDTS")
		TBLent(PEG_TCAP_RECEIVE_XUDTS, "TCAP_RECEIVE_XUDTS")
		TBLent(PEG_TCAP_RECEIVE_INVALID_SCCP, "TCAP_RECEIVE_INVALID_SCCP")
		TBLent(PEG_TCAP_SEND_UDT, "TCAP_SEND_UDT")
		TBLent(PEG_TCAP_SEND_XUDT, "TCAP_SEND_XUDT")
		TBLent(PEG_TCAP_SEND_UDTS, "TCAP_SEND_UDTS")
		TBLent(PEG_TCAP_SEND_XUDTS, "TCAP_SEND_XUDTS")
		TBLent(PEG_TCAP_PREARRANGED_END, "TCAP_PREARRANGED_END")
		TBLent(PEG_TCAP_SCCP_CLASS_0_SENT, "TCAP_SCCP_CLASS_0_SENT")
		TBLent(PEG_TCAP_SCCP_CLASS_1_SENT, "TCAP_SCCP_CLASS_1_SENT")
		TBLent(PEG_TCAP_SCCP_CLASS_0_RECEIVED, "TCAP_SCCP_CLASS_0_RECEIVED")
		TBLent(PEG_TCAP_SCCP_CLASS_1_RECEIVED, "TCAP_SCCP_CLASS_1_RECEIVED")
		TBLent(PEG_TCAP_SCCP_RET_ON_ERR_SENT, "TCAP_SENT_WITH_RET_ON_ERR_SET")
		TBLent(PEG_MTP3_MSG_PAUSE, "MTP3_MSG_PAUSE")
		TBLent(PEG_MTP3_MSG_RESUME, "MTP3_MSG_RESUME")
		TBLent(PEG_MTP3_MSG_STATUS, "MTP3_MSG_STATUS")
		TBLent(PEG_SCCP_ACTIVE_CONNECTION, "SCCP_ACTIVE_CONNECTION")		
		TBLent(PEG_SCCP_ACTIVATED_CONNECTION, "SCCP_ACTIVATED_CONNECTION")	
		TBLent(PEG_SCCP_MSG_FOR_PROHIBITED_SSN, "SCCP_MSG_FOR_PROHIBITED_SSN")						
		TBLent(PEG_SCCP_USER_INTERVENTION, "SCCP_USER_INTERVENTION")		
		TBLent(PEG_SCCP_USER_SEND_EVENT, "SCCP_USER_SEND_EVENT")		
		TBLent(PEG_SCCP_USER_RECEIVE_EVENT, "SCCP_USER_RECEIVE_EVENT")		
		TBLent(PEG_SCCP_SEND_USER_OUT_OF_SERVICE, "SCCP_SEND_USER_OUT_OF_SERVICE")	
		TBLent(PEG_SCCP_SEND_USER_IN_SERVICE, "SCCP_SEND_USER_IN_SERVICE")	
		TBLent(PEG_SCCP_SEND_USER_CONGESTED, "SCCP_SEND_USER_CONGESTED")	
		TBLent(PEG_SCCP_ROUTING_FAILURE, "SCCP_ROUTING_FAILURE")		
		TBLent(PEG_SCCP_LBC_SS_IN_SERVICE, "SCCP_LBC_SS_IN_SERVICE")		
		TBLent(PEG_SCCP_LBC_SS_OUT_OF_SERVICE, "SCCP_LBC_SS_OUT_OF_SERVICE")	
		TBLent(PEG_SCCP_LBC_SS_CONGESTED, "SCCP_LBC_SS_CONGESTED")		
		TBLent(PEG_SCCP_LBC_SS_ALLOWED, "SCCP_LBC_SS_ALLOWED")			
		TBLent(PEG_SCCP_LBC_SS_PROHIBITED, "SCCP_LBC_SS_PROHIBITED")		
		TBLent(PEG_SCCP_LBC_USER_IN_SERVICE, "SCCP_LBC_USER_IN_SERVICE")	
		TBLent(PEG_SCCP_LBC_USER_OUT_OF_SERVICE, "SCCP_LBC_USER_OUT_OF_SERVICE")	
		TBLent(PEG_SCCP_GTT_REQUEST, "SCCP_GTT_REQUEST")
		TBLent(PEG_SCCP_GTT_SUCCESS, "SCCP_GTT_SUCCESS")
		TBLent(PEG_SCCP_GTT_FAILURE, "SCCP_GTT_FAILURE")
		TBLent(PEG_SCCP_PCLASS_0_SENT, "SCCP_PCLASS_0_SENT")
		TBLent(PEG_SCCP_PCLASS_1_SENT, "SCCP_PCLASS_1_SENT")
		TBLent(PEG_SCCP_PCLASS_2_SENT, "SCCP_PCLASS_2_SENT")
		TBLent(PEG_SCCP_PCLASS_3_SENT, "SCCP_PCLASS_3_SENT")
		TBLent(PEG_SCCP_PCLASS_0_RECEIVED, "SCCP_PCLASS_0_RECEIVED")
		TBLent(PEG_SCCP_PCLASS_1_RECEIVED, "SCCP_PCLASS_0_RECEIVED")
		TBLent(PEG_SCCP_PCLASS_2_RECEIVED, "SCCP_PCLASS_0_RECEIVED")
		TBLent(PEG_SCCP_PCLASS_3_RECEIVED, "SCCP_PCLASS_0_RECEIVED")
		TBLent(PEG_SCCP_RET_ON_ERR_SENT, "SCCP_RET_ON_ERR_SENT")
		TBLent(PEG_SCCP_RET_ON_ERR_RECEIVED, "SCCP_RET_ON_ERR_RECEIVED")


		TBLent(PEG_MISC_UNUSED, "Unused - for testing")
	TBLend;



	TBLptr(13)
		TBLptrent(0)
		TBLptrent(grptbl_msgGroup)
		TBLptrent(grptbl_scmgGroup)
		TBLptrent(grptbl_cptGroup)
		TBLptrent(grptbl_reasonABTGroup)
		TBLptrent(grptbl_reasonUABTGroup)
		TBLptrent(grptbl_reasonPABTGroup)
		TBLptrent(grptbl_rejCodeResGroup)
		TBLptrent(grptbl_rejCodeGenGroup)
		TBLptrent(grptbl_rejCodeInvGroup)
		TBLptrent(grptbl_rejCodeErrGroup)
		TBLptrent(grptbl_rejCodeTransGroup)
		TBLptrent(grptbl_miscGroup)
	TBLptrend;



void
patsPrintCounters()
{
		int group=1, i=1, i2=1, *pi=&i, ti=1, ret;

		PegGetCounter_CCITT(3, TCAP_PT_TC_INVOKE_CCITT, pmytheCounters);
		ptbl = (PTAGTBL) tblptrs[3].ptbl;

		for (ti=1; ti<90; ti++)
		{
			if (ptbl[ti].id == TCAP_PT_TC_INVOKE_CCITT) 
			{
				break;
			} /* if */
		} /* if */

		printf ("\n MsgType = %d %s\n", pmytheCounters->cntName, (char *)ptbl[ti].pname);
		printf ("Type %d MSG rec %d snt %d discard %d \n\n\n", pmytheCounters->cntName,
			pmytheCounters->u.m.msg_received, pmytheCounters->u.m.msg_sent, 
			pmytheCounters->u.m.msg_discarded);

		PegGetCounter_CCITT(10, PEG_TCAP_RECEIVE_COMPONENT, pmymiscCounters);
		ptbl = (PTAGTBL) tblptrs[3].ptbl;

		for (ti=1; ti<90; ti++)
		{
			if (ptbl[ti].id == PEG_TCAP_RECEIVE_COMPONENT) 
			{
				break;
			} /* if */
		} /* if */
		printf ("\n i = %d - MsgType = %d %s\n", i2, pmymiscCounters->cntName, (char *)ptbl[ti].pname);
		if (pmymiscCounters->cntName != 0)
		{
			printf ("Type %d Count %d \n", pmymiscCounters->cntName,
				pmymiscCounters->cnt);
		} /* if */




	for (group = msgGroup; group <= rejCodeTransGroup; group++)
	{
		printf("Group < %d > \n", group);

		for (i = 1;;)
		{
			ret = PegGetNextCounter_CCITT(group, pi, pmytheCounters);

			if (ret == -1) 
			{
				printf("Break on error\n");
				break;	// exit on error
			} /* if */
			if (*pi == -1) 
			{
				printf ("Break on EOF\n");
				break;	// exit on EOF
			} /* if */

			ptbl = (PTAGTBL) tblptrs[group].ptbl;

			if (pmytheCounters->cntName != 0)
			{
				for (ti=1; ti<90; ti++)
				{
					if (ptbl[ti].id == pmytheCounters->cntName) 
					{
						break;
					} /* if */
				} /* for */
			} /* if */

			if (group == reasonUABTGroup || group == reasonPABTGroup)
			{
				printf ("\n i = %d - MsgType = %d %s\n", i2, pmytheCounters->cntName, (char *)ptbl[ti].pname);
				if (pmytheCounters->cntName != 0)
				{
					printf ("Type %d MSG Received from Remote %d Sent to Remote %d Sent to App %d \n", pmytheCounters->cntName,
						pmytheCounters->u.o.ot_received, pmytheCounters->u.o.ot_sentTOremote, 
						pmytheCounters->u.o.ot_sentTOapp);

				} /* if */
			} /* if */
			else
			{
				printf ("\n i = %d - MsgType = %d %s\n", i2, pmytheCounters->cntName, (char *)ptbl[ti].pname);
				if (pmytheCounters->cntName != 0)
				{
					printf ("Type %d MSG rec %d snt %d discard %d \n", pmytheCounters->cntName,
						pmytheCounters->u.m.msg_received, pmytheCounters->u.m.msg_sent, 
						pmytheCounters->u.m.msg_discarded);
				} /* if */
			} /* else */
		} /* for - EOF or Error */
	} /* for - first 11 groups */

	group = miscGroup;

	printf("Group < %d > \n", group);

	for (i = 1;;)
	{
		ret = PegGetNextCounter_CCITT(group, pi, pmymiscCounters);
		if (ret == -1) 
		{
			printf("Break on error\n");
			break;	// exit on error
		} /* if */
		if (*pi == -1) 
		{
			printf ("Break on EOF\n");
			break;	// exit on EOF
		} /* if */

		ptbl = (PTAGTBL) tblptrs[group].ptbl;

		if (pmymiscCounters->cntName != 0)
		{
			for (ti=0; ti<90; ti++)
			{
				if (ptbl[ti].id == pmymiscCounters->cntName) 
				{
					break;
				} /* if */
			} /* for */
		} /* if */


		printf ("\n i = %d - MsgType = %d %s\n", i2, pmymiscCounters->cntName, (char *)ptbl[ti].pname);
		if (pmymiscCounters->cntName != 0)
		{
			printf ("Type %d Count %d \n", pmymiscCounters->cntName,
				pmymiscCounters->cnt);
		} /* if */
	} /* for - EOF or Error */

	printf("Press Enter to Continue: ");
	getchar();

} /* patsPrintCounters */

}	/* extern "C" */
