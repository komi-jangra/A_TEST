/************************************************************************************************/
/*																								*/
/*							SCCP Send Side Test Program											*/
/*																								*/
/************************************************************************************************/

#define CCITT 1
//#define ANSI 1
#define PEGDSMPR5 1
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <time.h>
#include <sys/timeb.h>
//#include <string>
//#include <map>

#include <its.h>
#include <its++.h>
#include <engine++.h>
#include <its_thread_pool.h>
#include <its_work_item.h>

#include <itu/sccp.h>
#include <itu/tcap.h>
#include <sccp++.h>
#include <tcap++.h>
#include <its_dsm.h>
#include "sccp_intern.h"
#include "bit.h"


#define VALID_CHOICE(x)     ( x >= 1 && x <= 4 || x == 99 )
#define MAX_RK_NUM    5
#define BUILD_DATA    2
#define CONNECT    1
#define TEST_EXIT    99

#define SEND_DT1      1
#define SEND_DT2     2
#define DISCONNECT   3

#define IMPORT
#define EXPORT

//
using namespace std;
using namespace its;
using namespace engine;


extern "C"
{

void
iTOa(int n, char s[]);
void
reverseString(char s[]);
int
strLen(char s[]);


void
SccpThreadFunction(its::ITS_ThreadPoolThread* thr, ITS_HANDLE handle);

void
RouteSS7();

ITS_USHORT 
RouteAPP(ITS_HDR *pHdr, ITS_EVENT *pEvent);

void 
MyPreFunc();


void 
MyPreFunc();


int 
AppMain(its::ThreadPoolThread *thr, its::Event &event);

int 
FilterCacheMsgs(its::ThreadPoolThread *thr, its::Event &ev);

int 
ClientPostInit(its::ThreadPoolThread *thr, ITS_HANDLE h);

int 
ClientPreInit(its::ThreadPoolThread *thr, ITS_HANDLE h);



void RouteSS7()
{
  cout << "Inside RouteSS7 " << endl;
}

FILE *fh = NULL;

ITS_USHORT 
RouteAPP(ITS_HDR *pHdr, ITS_EVENT *pEvent)
{
	int i;
	cout << "Inside RouteAPP " << endl;

	ROUTE_AddApplication(ITS_DEFAULT_USER_SRC, pHdr);

	printf("Event Length %d SRC %d Data:\n", pEvent->len, pEvent->src);
	for (i = 0; i < pEvent->len; i++)
	{
		printf("%02x ", pEvent->data[i]);
		if (fh != NULL)
		{
			fprintf( fh, "%02x ", pEvent->data[i]);
		} /* if */
	} /* for */
	printf("\nEnd Of Data \n");

	cout << "Leaving RouteAPP" << endl;

	return (ITS_DEFAULT_USER_SRC);

} /* RouteAPP */


void MyPreFunc()
{
  ThreadPoolEntry thr;
  engine::Worker *eng;

  cout << "Inside MyPreFunc!!!! " << endl;
  workerPool->GetFirstAvailThread(thr);
  eng = reinterpret_cast<engine::Worker *>(thr.GetThread());
  workerPool->DispatchOnThread(thr, DISP_Dispatch_USER_CPP,
                            (void *)eng->GetCallbackStruct());

  cout << "Leaving MyPreFunc " << endl;
  return;
  
}

void MyPostFunc()
{
  cout << "Inside MyPostFunc " << endl;
  return; 
}

int AppMain(its::ThreadPoolThread *thr, its::Event &event)
{
  cout << "Inside AppMain " << endl;
  return ITS_SUCCESS;
}

int FilterCacheMsgs(its::ThreadPoolThread *thr, its::Event &ev)
{
  printf("FilterCacheMsgs\n");
  return(ITS_SUCCESS);
}

int ClientPostInit(its::ThreadPoolThread *thr, ITS_HANDLE h)
{
  printf("ClientPostInit\n");
  return ITS_SUCCESS;
}

int ClientPreInit(its::ThreadPoolThread *thr, ITS_HANDLE h)
{
  printf("ClientPostInit\n");
  return ITS_SUCCESS;
}

void
patMain(ITS_USHORT instance, ITS_HANDLE handle);
int
SendUIS(ITS_USHORT instance, ITS_HANDLE handle);
int
SendUOS(ITS_USHORT instance, ITS_HANDLE handle);
int
SendUCong(ITS_USHORT instance, ITS_HANDLE handle);
int
SendCR2(ITS_USHORT instance, ITS_HANDLE handle);
int
SendCR3(ITS_USHORT instance, ITS_HANDLE handle);
int
SendCC(ITS_USHORT instance, ITS_HANDLE handle);
int
SendCREF(ITS_USHORT instance, ITS_HANDLE handle);
int
SendRLSD(ITS_USHORT instance, ITS_HANDLE handle);
int
SendRLC(ITS_USHORT instance, ITS_HANDLE handle);
int
SendDT1(ITS_USHORT instance, ITS_HANDLE handle);
int
SendDT2(ITS_USHORT instance, ITS_HANDLE handle);
int
SendAK(ITS_USHORT instance, ITS_HANDLE handle);
int
SendUDT0(ITS_USHORT instance, ITS_HANDLE handle);
int
SendUDT1(ITS_USHORT instance, ITS_HANDLE handle);
int
SendUDTS(ITS_USHORT instance, ITS_HANDLE handle);
int
SendED(ITS_USHORT instance, ITS_HANDLE handle);
int
SendEA(ITS_USHORT instance, ITS_HANDLE handle);
int
SendRSR(ITS_USHORT instance, ITS_HANDLE handle);
int
SendRSC(ITS_USHORT instance, ITS_HANDLE handle);
int
SendERR(ITS_USHORT instance, ITS_HANDLE handle);
int
SendIT(ITS_USHORT instance, ITS_HANDLE handle);
int
SendXUDT0(ITS_USHORT instance, ITS_HANDLE handle);
int
SendXUDT1(ITS_USHORT instance, ITS_HANDLE handle);
int
SendXUDTS(ITS_USHORT instance, ITS_HANDLE handle);
int
SendLUDT0(ITS_USHORT instance, ITS_HANDLE handle);
int
SendLUDT1(ITS_USHORT instance, ITS_HANDLE handle);
int
SendLUDTS(ITS_USHORT instance, ITS_HANDLE handle);
int
WaitToReceive(ITS_USHORT instance, ITS_HANDLE handle);
int
SetAutoRespOn(ITS_USHORT instance, ITS_HANDLE handle);;
int
SetAutoRespOff(ITS_USHORT instance, ITS_HANDLE handle);
int
SetAutoRecvOn(ITS_USHORT instance, ITS_HANDLE handle);
int
SetAutoRecvOff(ITS_USHORT instance, ITS_HANDLE handle);
int
SetReceiverModeOn(ITS_USHORT instance, ITS_HANDLE handle);
int
SetReceiverModeOff(ITS_USHORT instance, ITS_HANDLE handle);
int
SetPeekModeOn(ITS_USHORT instance, ITS_HANDLE handle);
int
SetPeekModeOff(ITS_USHORT instance, ITS_HANDLE handle);
int
ShowStatus(ITS_USHORT instance, ITS_HANDLE handle);
int
ExitPgm(ITS_USHORT instance, ITS_HANDLE handle);
int
RecvCR(ITS_USHORT instance, ITS_HANDLE handle);
int
RecvCC(ITS_USHORT instance, ITS_HANDLE handle); 
int
RecvCREF(ITS_USHORT instance, ITS_HANDLE handle); 
int
RecvRLSD(ITS_USHORT instance, ITS_HANDLE handle); 
int
RecvRLC(ITS_USHORT instance, ITS_HANDLE handle); 
int
RecvDT1(ITS_USHORT instance, ITS_HANDLE handle); 
int
RecvDT2(ITS_USHORT instance, ITS_HANDLE handle); 
int
RecvAK(ITS_USHORT instance, ITS_HANDLE handle); 
int
RecvED(ITS_USHORT instance, ITS_HANDLE handle); 
int
RecvEA(ITS_USHORT instance, ITS_HANDLE handle); 
int
RecvRSR(ITS_USHORT instance, ITS_HANDLE handle); 
int
RecvRSC(ITS_USHORT instance, ITS_HANDLE handle); 
int
RecvERR(ITS_USHORT instance, ITS_HANDLE handle); 
int
RecvIT(ITS_USHORT instance, ITS_HANDLE handle); 
int
RecvUDT(ITS_USHORT instance, ITS_HANDLE handle); 
int
RecvUDTS(ITS_USHORT instance, ITS_HANDLE handle); 
int
RecvXUDT(ITS_USHORT instance, ITS_HANDLE handle); 
int
RecvXUDTS(ITS_USHORT instance, ITS_HANDLE handle);
void
saveCrash();
void
recoverCrash();

#ifdef PEGDSMPR5
void
testdsm();
void
searchContext();
void
printContext(SCCP_CONN_CTXT *pFoundCtxt);
void
patsPrintCounters();
#endif
}

#define ASK(Y, N, M) \
	for (char selection = ' '; ;) \
	{ \
		cout << M; \
		cin >> selection; \
		selection = tolower(selection); \
		if (selection == 'y') \
		{ \
			Y; \
		}  \
		if (selection == 'n')  \
	{  \
			N;  \
		}  \
		cout << "Invalid Answer " << endl; \
	}


#define CMDdef(n, c) struct { char sel; char *pdescription; void *pfn; } n##tbl[c+1] = {
#define CMDent(S, D, F) S, D, &F,
#define CMDend (unsigned char) 0xFF, (char *) 0xFFFFFFFF }

	CMDdef(Oper,43)
		CMDent('a', "Send UIS             ", SendUIS)
		CMDent('b', "Send UOS             ", SendUOS)
		CMDent('c', "Send UCong           ", SendUCong)
		CMDent('d', "Send CR - Class 2    ", SendCR2)
		CMDent('e', "Send CR - Class 3    ", SendCR3)
		CMDent('f', "Send CC              ", SendCC)
		CMDent('g', "Send CREF            ", SendCREF)
		CMDent('h', "Send RLSD            ", SendRLSD)
		CMDent('i', "Send RLC             ", SendRLC)
		CMDent('j', "Send DT1             ", SendDT1)
		CMDent('k', "Send DT2             ", SendDT2)
		CMDent('l', "Send AK              ", SendAK)
		CMDent('m', "Send UDT Class 0     ", SendUDT0)
		CMDent('n', "Send UDT Class 1     ", SendUDT1)
		CMDent('o', "Send UDTS            ", SendUDTS)
		CMDent('p', "Send ED              ", SendED)
		CMDent('q', "Send EA              ", SendEA)
		CMDent('r', "Send RSR             ", SendRSR)
		CMDent('s', "Send RSC             ", SendRSC)
		CMDent('t', "Send ERR             ", SendERR)
		CMDent('u', "Send IT              ", SendIT)
		CMDent('v', "Send XUDT Class 0    ", SendXUDT0)
		CMDent('w', "Send XUDT Class 1    ", SendXUDT1)
		CMDent('x', "Send XUDTS           ", SendXUDTS)
		CMDent('y', "Send LUDT Class 0    ", SendLUDT0)
		CMDent('z', "Send LUDT Class 1    ", SendLUDT1)
		CMDent('1', "Send LUDTS           ", SendLUDTS)
		CMDent('2', "Wait for Message     ", WaitToReceive)
		CMDent('3', "Set Auto Response On ", SetAutoRespOn)
		CMDent('4', "Set Auto Response Off", SetAutoRespOff)
		CMDent('5', "Set Auto Receive On  ", SetAutoRecvOn)
		CMDent('6', "Set Auto Receive Off ", SetAutoRecvOff)
		CMDent('7', "Set Receiver Mode On ", SetReceiverModeOn)
		CMDent('8', "Set Receiver Mode Off", SetReceiverModeOff)
		CMDent('9', "Set Peek Mode On     ", SetPeekModeOn)
		CMDent('0', "Set Peek Mode Off    ", SetPeekModeOff)
		CMDent('$', "Show Status          ", ShowStatus)
#ifdef PEGDSMPR5
		CMDent('^', "Test DSM locally     ", testdsm)
		CMDent('@', "Print Counters       ", patsPrintCounters)
		CMDent('&', "Display Context      ", searchContext)
#endif
		CMDent('>', "Save and Crash       ", saveCrash)
		CMDent('<', "Recover from Crash   ", recoverCrash)
		CMDent('!', "Exit                 ", ExitPgm)
	CMDend;

/*
 * parameter tags
 */

/*
#define SCCP_PRM_EOP                (0x00U)
#define SCCP_PRM_DEST_LOCAL_REF     (0x01U)
#define SCCP_PRM_SRC_LOCAL_REF      (0x02U)
#define SCCP_PRM_CALLED_PARTY_ADDR  (0x03U)
#define SCCP_PRM_CALLING_PARTY_ADDR (0x04U)
#define SCCP_PRM_PROTOCOL_CLASS     (0x05U)
#define SCCP_PRM_SEGMENT_REASSEM    (0x06U)
#define SCCP_PRM_RCV_SEQ_NUM        (0x07U)
#define SCCP_PRM_SEQUENCE_SEGMENT   (0x08U)
#define SCCP_PRM_CREDIT             (0x09U)
#define SCCP_PRM_RELEASE_CAUSE      (0x0AU)
#define SCCP_PRM_RETURN_CAUSE       (0x0BU)
#define SCCP_PRM_RESET_CAUSE        (0x0CU)
#define SCCP_PRM_ERROR_CAUSE        (0x0DU)
#define SCCP_PRM_REFUSAL_CAUSE      (0x0EU)
#define SCCP_PRM_DATA               (0x0FU)
#define SCCP_PRM_SEGMENTATION       (0x10U)
#define SCCP_PRM_HOP_COUNTER        (0x11U)
#define SCCP_PRM_IMPORTANCE         (0x12U)
#define SCCP_PRM_LONG_DATA          (0x13U)
#define SCCP_PRM_ISNI               (0xFAU)
#define SCCP_PRM_ROUTING_LABEL      (0xFFU)  
*/

#define IE_BIT_DEST_LOCAL_REF		B0b00000001
#define IE_BIT_SRC_LOCAL_REF		B0b00000010
#define IE_BIT_CALLED_PARTY_ADDR	B0b00000100
#define IE_BIT_CALLING_PARTY_ADDR	B0b00001000
#define IE_BIT_PROTOCOL_CLASS		B0b00010000
#define IE_BIT_SEGMENT_REASSEM		B0b00100000
#define IE_BIT_RCV_SEQ_NUM			B0b01000000
#define IE_BIT_SEQUENCE_SEGMENT		B0b10000000

#define IE_BIT_CREDIT				B1b00000001
#define IE_BIT_RELEASE_CAUSE		B1b00000010
#define IE_BIT_RETURN_CAUSE			B1b00000100
#define IE_BIT_RESET_CAUSE			B1b00001000
#define IE_BIT_ERROR_CAUSE			B1b00010000
#define IE_BIT_REFUSAL_CAUSE		B1b00100000
#define IE_BIT_DATA					B1b01000000
#define IE_BIT_SEGMENTATION			B1b10000000

#define IE_BIT_HOP_COUNTER			B2b00000001
#define IE_BIT_IMPORTANCE			B2b00000010
#define IE_BIT_LONG_DATA			B2b00000100
#define IE_BIT_ISNI					B2b00001000
#define IE_BIT_ROUTING_LABEL		B2b00010000 

#define MSGdef(n, c) struct { unsigned char msgid; char *pdesc; unsigned int ie_bits; void *pfn; } n##tbl[c+1] = {
#define MSGent(M, D, B, F) (unsigned int) M, D, B, &F, 
#define MSGend (unsigned char) 0x00, (char *) NULL, (unsigned int) 0x00000000, (char *) 0xFFFFFFFF }

	MSGdef(MsgIe, 18)
		MSGent(SCCP_MSG_CR,		"Connection Request",
								IE_BIT_SRC_LOCAL_REF +
								IE_BIT_PROTOCOL_CLASS +
								IE_BIT_CALLED_PARTY_ADDR +
								IE_BIT_CALLING_PARTY_ADDR +
								IE_BIT_CREDIT +
								IE_BIT_HOP_COUNTER +
								IE_BIT_DATA, 
								RecvCR)
		MSGent(SCCP_MSG_CC,		"Connection Confirm",
								IE_BIT_DEST_LOCAL_REF +
								IE_BIT_SRC_LOCAL_REF +
								IE_BIT_PROTOCOL_CLASS +
								IE_BIT_CALLED_PARTY_ADDR +
								IE_BIT_CREDIT + 
								IE_BIT_DATA, 
								RecvCC)
		MSGent(SCCP_MSG_CREF,	"Connection Refused",
								IE_BIT_DEST_LOCAL_REF +
								IE_BIT_REFUSAL_CAUSE +
								IE_BIT_CALLED_PARTY_ADDR +
								IE_BIT_DATA, 
								RecvCREF)
		MSGent(SCCP_MSG_RLSD,	"Release Request",
								IE_BIT_DEST_LOCAL_REF +
								IE_BIT_SRC_LOCAL_REF +
								IE_BIT_PROTOCOL_CLASS +
								IE_BIT_DATA,
								RecvRLSD)
		MSGent(SCCP_MSG_RLC,	"Release Complete",
								IE_BIT_DEST_LOCAL_REF +
								IE_BIT_SRC_LOCAL_REF,
								RecvRLC)
		MSGent(SCCP_MSG_DT1,	"Data Form 1",
								IE_BIT_DEST_LOCAL_REF +
								IE_BIT_SEGMENT_REASSEM +
								IE_BIT_DATA,
								RecvDT1) 
		MSGent(SCCP_MSG_DT2,	"Data Form 2",
								IE_BIT_DEST_LOCAL_REF +
								IE_BIT_SEGMENT_REASSEM +
								IE_BIT_DATA,
								RecvDT2)
		MSGent(SCCP_MSG_AK,		"Data Acknowledgement",
								IE_BIT_DEST_LOCAL_REF +
								IE_BIT_RCV_SEQ_NUM +
								IE_BIT_CREDIT,
								RecvAK)
		MSGent(SCCP_MSG_UDT,	"Unitdata",
								IE_BIT_CALLED_PARTY_ADDR +
								IE_BIT_CALLING_PARTY_ADDR +
								IE_BIT_PROTOCOL_CLASS +
								IE_BIT_DATA,
								RecvUDT) 
		MSGent(SCCP_MSG_UDTS,	"Unitdata Service",
								IE_BIT_CALLED_PARTY_ADDR +
								IE_BIT_CALLING_PARTY_ADDR +
								IE_BIT_RETURN_CAUSE +
								IE_BIT_DATA,
								RecvUDTS)
		MSGent(SCCP_MSG_ED,		"Expedited Data",
								IE_BIT_DEST_LOCAL_REF +
								IE_BIT_DATA,
								RecvED)
		MSGent(SCCP_MSG_EA,		"Expedited Data Acknowledgement",
								IE_BIT_DEST_LOCAL_REF,
								RecvEA)
		MSGent(SCCP_MSG_RSR,	"Reset Request",
								IE_BIT_DEST_LOCAL_REF +
								IE_BIT_SRC_LOCAL_REF +
								IE_BIT_RELEASE_CAUSE,
								RecvRSR)
		MSGent(SCCP_MSG_RSC,	"Reset Confirm",
								IE_BIT_DEST_LOCAL_REF +
								IE_BIT_SRC_LOCAL_REF,
								RecvRSC)
		MSGent(SCCP_MSG_ERR,	"Error",
								IE_BIT_DEST_LOCAL_REF +
								IE_BIT_ERROR_CAUSE,
								RecvERR)
		MSGent(SCCP_MSG_IT,		"Inactivity Test",
								IE_BIT_SRC_LOCAL_REF +
								IE_BIT_SRC_LOCAL_REF +
								IE_BIT_PROTOCOL_CLASS +
								IE_BIT_SEQUENCE_SEGMENT +
								IE_BIT_CREDIT,
								RecvIT) 
		MSGent(SCCP_MSG_XUDT,	"Extended Unitdata",
								IE_BIT_CALLED_PARTY_ADDR +
								IE_BIT_CALLING_PARTY_ADDR +
								IE_BIT_PROTOCOL_CLASS +
								IE_BIT_HOP_COUNTER +
								IE_BIT_SEGMENTATION +
								IE_BIT_DATA,
								RecvXUDT)
		MSGent(SCCP_MSG_XUDTS,	"Extended Unitdata Service",
								IE_BIT_CALLED_PARTY_ADDR +
								IE_BIT_CALLING_PARTY_ADDR +
								IE_BIT_RETURN_CAUSE +
								IE_BIT_HOP_COUNTER +
								IE_BIT_SEGMENTATION +
								IE_BIT_DATA,
								RecvXUDTS)
	MSGend;




#define MAX_XUDT_LEN 255	//Enlarge later
#define MAX_LUDT_LEN 255	//Enlarge later


#define IN_SERVICE			b00000001
#define CONGESTED			b00000010
#define ACTIVE_CONNECTION	b00000100

#define RSC_PENDING			b00000010
#define CC_PENDING			b00000100
#define RLC_PENDING			b00001000
#define AK_PENDING			b00010000
#define ED_PENDING			b00100000
#define EA_PENDING			b01000000

#define AUTO_RESP			b00000001
#define AUTO_RECV			b00000010
#define AUTO_RESOPNDED		b00000100
#define RECEIVER_MODE		b00001000
#define PEEK_MODE			b00010000

#define SETON(f, b) f = f | b
#define SETOFF(f, b) f = f & ~b

#define TESTON(f, b) b == (f & b)
#define TESTOFF(f, b) !(b ==  (f & b))
//
// local subsystem for testing
//

#define SERVER_PC    30
#define SERVER_SSN   40

#define CLIENT_PC   60
#define CLIENT_SSN  40

#define HAVE_NO_MORE 0
#define HAVE_MORE 1

//
// address indicator
//
#define ADDR_IND    (SCCP_CPA_ROUTE_NAT|SCCP_CPA_ROUTE_SSN|\
                     SCCP_CPA_HAS_PC|SCCP_CPA_HAS_SSN)

//Data Areas

unsigned int ssnState = 0;
unsigned int pendingRecvState = 0;
unsigned int pendingSendState = 0;
unsigned int pgmCntl = 0;

ITS_UINT local_pc = 0;
ITS_UINT remote_pc = 0;
ITS_OCTET local_ssn = 0;
ITS_OCTET remote_ssn = 0;

ITS_OCTET ssnCongestion = 0;
ITS_INT theClass = 0;

ITS_HDR sccpReceivedHdr;

SCCP_SourceLocalRef *pRecvSlr = NULL;
SCCP_DestinationLocalRef *pRecvDlr = NULL;
ITS_OCTET sendSequenceNumber = 0, receiveSequenceNumber = 0;
ITS_USHORT XRecvSlr = 0, XRecvDlr = 0, LocalRef = 0, DestRef = 0;
SCCP_ProtocolClass *pRecvProtocolClass = NULL;
ITS_OCTET RecvProtocolClass = 0;
SCCP_CalledPartyAddr *pRecvCalled_Pa = NULL;
ITS_UINT RecvLocal_PC = 0;
ITS_OCTET RecvLocal_SSN = 0;
bool RecvLocal_ByPC_SSN = 0;
bool RecvLocal_InternationalRouting = 0;
SCCP_CallingPartyAddr *pRecvCalling_Pa = NULL;
ITS_UINT RecvRemote_PC = 0;
ITS_OCTET RecvRemote_SSN = 0;
bool RecvRemote_ByPC_SSN = 0;
bool RecvRemote_InternationalRouting = 0;
SCCP_HopCount *pRecvHopCount = NULL;
ITS_OCTET XRecvHopCount = 0;
SCCP_Credit *pRecvCredit = NULL;
ITS_OCTET XRecvCredit = 0;
SCCP_SegmentReassem *pRecvSegmentReassem = NULL;
ITS_OCTET XRecvHaveMore = 0;
SCCP_SequenceSegment *pRecvSequenceSegment = NULL;
ITS_OCTET XRecvTransSeqNum = 0;
ITS_OCTET XRecvRecvSeqNum = 0;
SCCP_ReceiveSequenceNum *pRecvSeqenceNumber = NULL;
ITS_UINT XRecvReleaseCause = 0;
ITS_UINT XRecvResetCause = 0;
ITS_UINT XRecvErrorCause = 0;
ITS_UINT XRecvReturnCause = 0;
ITS_UINT XRecvRefusalCause = 0;
ITS_OCTET XRecvDataBuf[4000], *pRecvDataBuf = &XRecvDataBuf[0];
ITS_INT XRecvDataLen = 0;
SCCP_UserData *pRecvUserData = NULL;



ITS_HDR srchdr, remhdr;

struct  
{
unsigned int ssnState;
unsigned int pendingRecvState;
unsigned int pendingSendState;
unsigned int pgmCntl;
ITS_UINT local_pc;
ITS_UINT remote_pc;
ITS_OCTET local_ssn;
ITS_OCTET remote_ssn;
ITS_OCTET ssnCongestion;
ITS_INT theClass;
ITS_OCTET sendSequenceNumber;
ITS_OCTET receiveSequenceNumber;
ITS_USHORT XRecvSlr;
ITS_USHORT XRecvDlr;
ITS_USHORT LocalRef;
ITS_USHORT DestRef;
ITS_OCTET RecvProtocolClass;
ITS_UINT RecvLocal_PC;
ITS_OCTET RecvLocal_SSN;
ITS_UINT RecvRemote_PC;
ITS_OCTET RecvRemote_SSN;
ITS_OCTET XRecvHopCount;
ITS_OCTET XRecvCredit;
ITS_OCTET XRecvHaveMore;
ITS_OCTET XRecvTransSeqNum;
ITS_OCTET XRecvRecvSeqNum;
ITS_UINT XRecvReleaseCause;
ITS_UINT XRecvResetCause;
ITS_UINT XRecvErrorCause;
ITS_UINT XRecvReturnCause;
ITS_UINT XRecvRefusalCause;
ITS_INT XRecvDataLen;
bool RecvLocal_ByPC_SSN;
bool RecvLocal_InternationalRouting;
bool RecvRemote_ByPC_SSN;
bool RecvRemote_InternationalRouting;
ITS_HDR sccpReceivedHdr;
ITS_HDR srchdr;
ITS_HDR remhdr;
ITS_OCTET XRecvDataBuf[4000];
} saveData;


void
SccpThreadFunction(its::ITS_ThreadPoolThread* thr, ITS_HANDLE handle)
{
	int ret;
	char selection = ' ';

	ITS_Worker* worker = static_cast<ITS_Worker*> (thr);
	ITS_USHORT instance = worker->GetInstance();

	cout << "Inside SccpThreadFunction " << endl;

    ret = SCCP_SendUserInService(handle, local_pc, local_ssn);
	if (ret != ITS_SUCCESS)
    {
       cout << "Error Sendin UIS" <<  endl;
       return ;
	} /* if */



   /* Open for write */
   if( (fh = fopen( "outfile", "w+" )) == NULL )
   {
	   printf( "The file 'outfile' was not opened\n" );
   } /* if */
   else
   {
	   printf( "The file 'outfile' was opened\n" );
   } /* else */

   
	SETON(ssnState,IN_SERVICE);

	while (local_pc == 0)
	{
		cout << "Enter 1 for SERVER or 2 for CLIENT: "; 
		cin >> selection;
		selection = tolower(selection);
		if (selection == '1')
		{
			local_pc = SERVER_PC;
			remote_pc = CLIENT_PC;
			local_ssn = SERVER_SSN;
			remote_ssn = CLIENT_SSN;
		} /* if */
		if (selection == '2')
		{
			local_pc = CLIENT_PC;
			remote_pc = SERVER_PC;
			local_ssn = CLIENT_SSN;
			remote_ssn = SERVER_SSN;
		} /* if */
	} /* while */



	patMain(instance, handle);

} /* SccpThreadFunction */



void
patMain(ITS_USHORT instance, ITS_HANDLE handle)
{
	int i, ret, even_odd;
	char selection;
	int (*pFN)(ITS_USHORT instance, ITS_HANDLE handle);

	for (;;)
	{
		system("clear");
		cout << "\t" << endl;

		for(i = 0, even_odd = 0; Opertbl[i].sel != (char) 0xFF; i++)
		{
			if (even_odd == 0)
			{
				cout << Opertbl[i].sel << "\t" << (char *) Opertbl[i].pdescription << "\t ";
				even_odd =1;
			}
			else
			{
				cout << Opertbl[i].sel << "\t" << (char *) Opertbl[i].pdescription << endl;
				even_odd =0;
			}
		} /* for */

		cin >> selection;
		selection = tolower(selection);

		for (i = 0, pFN = 0; Opertbl[i].sel != (char) 0xFF; i++)
		{
			if (Opertbl[i].sel == selection)
			{
				pFN =  (int (*)(unsigned short,void *)) Opertbl[i].pfn;
				break;
			} /* if */
		} /* for */
	
		if (pFN != 0)
		{
		// Call appropirate function for selected operation
			ret = (*pFN)(instance, handle);
		} /* if */
		else
		{
			cout << "Invalid Selection " << endl;
		} /* else */
	} /* for - ever */
			
} /* patMain */

int
SendUIS(ITS_USHORT instance, ITS_HANDLE handle)
{
	int ret;
    ret = SCCP_SendUserInService(handle, local_pc, local_ssn);
    if (ret == ITS_SUCCESS)
	{
		SETON(ssnState,IN_SERVICE);
	} /* else */
	return (ret);
} /* SendUIS */


int
SendUOS(ITS_USHORT instance, ITS_HANDLE handle)
{
	int ret;
	ret = SCCP_SendUserOutOfService(handle, local_pc, local_ssn);
    if (ret == ITS_SUCCESS)
    {
		SETOFF(ssnState,IN_SERVICE);
    } /* if */

	return (ret);
} /* SendUOS */


int
SendUCong(ITS_USHORT instance, ITS_HANDLE handle)
{
ITS_OCTET cong = 1;
int ret;

//Need to input cong	
	ret = SCCP_SendSetCongestion(handle, local_pc, local_ssn, cong);
    if (ret == ITS_SUCCESS)
    {
		SETON(ssnState, CONGESTED);
		ssnCongestion = cong;;
    } /* if */
	return (ret);
} /* SendUCong */


int
SendCR2(ITS_USHORT instance, ITS_HANDLE handle)
{
    int ret = ITS_SUCCESS, i;
	


	if (!TESTON(ssnState, IN_SERVICE))
	{
		ASK(break, return(ITS_SUCCESS), " Local User is Out Of Service -- Continue (Y/N)??? ");
	} /* if */


	theClass = 2;

//		ITS_HDR srchdr, remhdr;

	srchdr.type = ITS_SCCP;
	ret = SCCP_GetNextLocalRef(&srchdr.context.conref);
	LocalRef = srchdr.context.conref;
	ROUTE_AddApplication(instance, &srchdr);
	ITS_THROW_ASSERT(ret == ITS_SUCCESS);

	cout<<"Using Local Reference (SLR) ("<<srchdr.context.conref<<") "<<"For Establishing Connection"<<endl;

	// Instantiate the Class
	SCCP_ConnectionRequest cr;

	// Instantiate the Class
	SCCP_SourceLocalRef slr(srchdr.context.conref);
	cr.AddIE(&slr);

	// Instantiate the Class
	SCCP_ProtocolClass pc(SCCP_PCLASS_2);
	cr.AddIE(&pc);

	/* Called Party Address */
	//len=3 min
	SCCP_CalledPartyAddr called_pa;
	called_pa.SetPointCode(remote_pc);          //octet 3 - any
	called_pa.SetSSN(remote_ssn);               //octet 2 - 0000 0001
	called_pa.SetRouteByPCSSN(true);            //octet 1 bit 7
	called_pa.SetInternationalRouting(false);   //octet 1 bit 8
	cr.AddIE(&called_pa);

	/* Calling Party Address */
	//len=3 min
	SCCP_CallingPartyAddr calling_pa;
	calling_pa.SetPointCode(local_pc);           //octet 3 - any
	calling_pa.SetSSN(local_ssn);                //octet 2 - 0000 0001
	calling_pa.SetRouteByPCSSN(true);            //octet 1 bit 7
	calling_pa.SetInternationalRouting(false);   //octet 1 bit 8
	cr.AddIE(&calling_pa);

	/* SCCP hop Counter  */           //len=3
	// Instantiate the Class
	SCCP_HopCount hc(10);
	cr.AddIE(&hc);


	/* Data */
	// Instantiate the Class
	SCCP_UserData ud;
	int len = 10;
	ITS_OCTET data[10];
	//fill data
	for(i=0; i<len; i++)
	{
	    data[i] = i;
	}
	ud.SetUserData(data, len);
	cr.AddIE(&ud);



	/* Importance ?? */
	/* Credit */


	ret = SCCP_MessageClass::Send(handle, &srchdr, &cr);

	if (ret != ITS_SUCCESS)
	{
	    printf("Error Sending SCCP_MSG_CR to Stack !! %d\n", ret);
	}
	else
	{
	    cout<<"Successfully sending CR"<<endl;
		SETON(ssnState, ACTIVE_CONNECTION);
		SETON(pendingRecvState, CC_PENDING);

	}

	if (TESTON(pgmCntl, AUTO_RECV))
	{
		cout << "Auto Wait for CC or CREF" << endl;
		WaitToReceive(instance, handle);
	} /* if */
	return (ITS_SUCCESS);


} /* SendCR2 */

int
SendCR3(ITS_USHORT instance, ITS_HANDLE handle)
{
//    ITS_SCCP_IE sccpIES[7];
    int ret = ITS_SUCCESS, i;
	
	if (!TESTON(ssnState, IN_SERVICE))
	{
		ASK(break, return(ITS_SUCCESS), " Local User is Out Of Service -- Continue (Y/N)??? ");
	} /* if */

	theClass = 3;

	srchdr.type = ITS_SCCP;
	ret = SCCP_GetNextLocalRef(&srchdr.context.conref);
	LocalRef = srchdr.context.conref;
	ROUTE_AddApplication(instance, &srchdr);
	ITS_THROW_ASSERT(ret == ITS_SUCCESS);

	cout<<"Using Local Reference (SLR) ("<<srchdr.context.conref<<") "<<"For Establishing Connection"<<endl;

	// Instantiate the Class
	SCCP_ConnectionRequest cr;

	// Instantiate the Class
	SCCP_SourceLocalRef slr(srchdr.context.conref);
	cr.AddIE(&slr);

	// Instantiate the Class
	SCCP_ProtocolClass pc(SCCP_PCLASS_3);

	cr.AddIE(&pc);

	/* Called Party Address */
	//len=3 min
	// Instantiate the Class
	SCCP_CalledPartyAddr called_pa;
	called_pa.SetPointCode(remote_pc);          //octet 3 - any
	called_pa.SetSSN(remote_ssn);               //octet 2 - 0000 0001
	called_pa.SetRouteByPCSSN(true);            //octet 1 bit 7
	called_pa.SetInternationalRouting(false);   //octet 1 bit 8
	cr.AddIE(&called_pa);

	/* Calling Party Address */
	//len=3 min
	// Instantiate the Class
	SCCP_CallingPartyAddr calling_pa;
	calling_pa.SetPointCode(local_pc);           //octet 3 - any
	calling_pa.SetSSN(local_ssn);                //octet 2 - 0000 0001
	calling_pa.SetRouteByPCSSN(true);            //octet 1 bit 7
	calling_pa.SetInternationalRouting(false);   //octet 1 bit 8
	cr.AddIE(&calling_pa);

	/* SCCP hop Counter  */           //len=3
	// Instantiate the Class
	SCCP_HopCount hc(10);
	cr.AddIE(&hc);


	/* Data */
	// Instantiate the Class
	SCCP_UserData ud;
	int len = 10;
	ITS_OCTET data[10];
	//fill data
	for(i=0;i<len;i++)
	{
	    data[i] = i;
	}
	ud.SetUserData(data, len);
	cr.AddIE(&ud);


	ret = SCCP_MessageClass::Send(handle, &srchdr, &cr);

	if (ret != ITS_SUCCESS)
	{
	    printf("Error Sending SCCP_MSG_CR to Stack !! %d\n", ret);
	}
	else
	{
	    cout<<"Successfully sending CR"<<endl;
		SETON(ssnState, ACTIVE_CONNECTION);
		SETON(pendingRecvState, CC_PENDING);
	}


	if (TESTON(pgmCntl, AUTO_RECV))
	{
		cout << "Auto Wait for CC or CREF" << endl;
		WaitToReceive(instance, handle);
	} /* if */

	return (ITS_SUCCESS);


  
} /* SendCR3 */


int
SendCC(ITS_USHORT instance, ITS_HANDLE handle)
{
//    ITS_SCCP_IE sccpIES[7];
    int ret = ITS_SUCCESS;

	if (!TESTON(ssnState, IN_SERVICE))
	{
		ASK(break, return(ITS_SUCCESS), " Local User is Out Of Service -- Continue (Y/N)??? ");
	} /* if */

	if (!((TESTON(theClass, 2)) | (TESTON(theClass, 3))))
	{
		ASK(break, return(ITS_SUCCESS), " Class is not 2 or 3 -- CC not Valid -- Continue (Y/N)??? ");
	} /* if */

	if (!TESTON(ssnState, ACTIVE_CONNECTION))
	{
		ASK(break, return(ITS_SUCCESS), " No Active Connection -- Continue (Y/N)??? ");
	} /* if */


	/***** Sending Connection Confirm in response to CR *****/ 
	srchdr.type = ITS_SCCP;
	srchdr.context.conref = LocalRef;

	// Instantiate the Class
	SCCP_ConnectionConfirm cc;

	/* Destination Local Reference */

	// Instantiate the Class
//	SCCP_DestinationLocalRef dlr(remhdr.context.conref);
	SCCP_DestinationLocalRef dlr(DestRef);
	cc.AddIE(&dlr);

	/* Source Local Reference */
	// Instantiate the Class
//	SCCP_SourceLocalRef slr(srchdr.context.conref);
	SCCP_SourceLocalRef slr(LocalRef);
	cc.AddIE(&slr);

	/* Protocol Class */
	// Instantiate the Class
	SCCP_ProtocolClass pc(theClass);
	cc.AddIE(&pc);

	/* Credit */                            //len=3
	// Instantiate the Class
	SCCP_Credit credit;
	credit.SetCredit(20);
	cc.AddIE(&credit);
        
	/* Called Party Address*/               //len=4 min
	// Instantiate the Class
	SCCP_CalledPartyAddr called_pa;
	called_pa.SetPointCode(remote_pc);          //octet 3 - any
	called_pa.SetSSN(remote_ssn);               //octet 2 - 0000 0001
	called_pa.SetRouteByPCSSN(true);          //octet 1 bit 7
	called_pa.SetInternationalRouting(false);   //octet 1 bit 8 
	cc.AddIE(&called_pa);

	// Data                                     //len=3-130
	// Instantiate the Class
	SCCP_UserData ud;
	int len = 10;
	ITS_OCTET data[10];
	//fill data
	for(ITS_OCTET i=0;i<len;i++)
	{
		data[i] = i;
	}
	ud.SetUserData(data, len);
	cc.AddIE(&ud);
        
	ret = SCCP_MessageClass::Send(handle, &srchdr, &cc);
	if (ret != ITS_SUCCESS)
	{
		cout << "Error while sending CC: " << ret << endl;
	}
	else
	{
		cout<<"Sending Connection Confirm ..."<<endl;
		SETON(ssnState, ACTIVE_CONNECTION);
		SETOFF(pendingSendState, CC_PENDING);
		pRecvSlr = NULL;
	}

	return (ITS_SUCCESS);
} /* SendCC */

int
SendCREF(ITS_USHORT instance, ITS_HANDLE handle)
{
//    ITS_SCCP_IE sccpIES[7];
    int ret = ITS_SUCCESS;


	if (!TESTON(ssnState, IN_SERVICE))
	{
		ASK(break, return(ITS_SUCCESS), " Local User is Out Of Service -- Continue (Y/N)??? ");
	} /* if */

	if (!((TESTON(theClass, 2)) | (TESTON(theClass, 3))))
	{
		ASK(break, return(ITS_SUCCESS), " Class is not 2 or 3 -- CC not Valid -- Continue (Y/N)??? ");
	} /* if */
	/***** Sending Connection Refused in response to CREF *****/ 
	srchdr.type = ITS_SCCP;
	srchdr.context.conref = LocalRef;
	ROUTE_DeleteApplication(instance, &srchdr);


	// Instantiate the Class
	SCCP_ConnectionRefused cref;

	/* Destination Local Reference */
	// Instantiate the Class
//	SCCP_DestinationLocalRef dlr(remhdr.context.conref);
	SCCP_DestinationLocalRef dlr(DestRef);
	cref.AddIE(&dlr);

      
	/* Called Party Address*/               //len=4 min
	// Instantiate the Class
	SCCP_CalledPartyAddr called_pa;
	called_pa.SetPointCode(remote_pc);          //octet 3 - any
	called_pa.SetSSN(remote_ssn);               //octet 2 - 0000 0001
	called_pa.SetRouteByPCSSN(true);          //octet 1 bit 7
	called_pa.SetInternationalRouting(false);   //octet 1 bit 8 
	cref.AddIE(&called_pa);


	SCCP_RefusalCause rc(SCCP_REF_BAD_USER_DATA);
	cref.AddIE(&rc);

	// Data                                     //len=3-130
	// Instantiate the Class
	SCCP_UserData ud;
	int len = 10;
	ITS_OCTET data[10];
	//fill data
	for(ITS_OCTET i=0;i<len;i++)
	{
		data[i] = i;
	}
	ud.SetUserData(data, len);
	cref.AddIE(&ud);
        
	ret = SCCP_MessageClass::Send(handle, &srchdr, &cref);
	if (ret != ITS_SUCCESS)
	{
		cout << "Error while sending CREF: " << ret << endl;
	} /* if */
	else
	{
		cout<<"Sending Connection Refused ..."<<endl;
		SETOFF(pendingSendState, CC_PENDING);
		pRecvSlr = NULL;
	} /* else */
	SETOFF(ssnState, ACTIVE_CONNECTION);

	LocalRef = 0;
	DestRef = 0;

	return (ITS_SUCCESS);
} /* SendCREF */


int
SendRLSD(ITS_USHORT instance, ITS_HANDLE handle)
{
//    ITS_SCCP_IE sccpIES[7];
    int ret = ITS_SUCCESS, i;

	if (!TESTON(ssnState, IN_SERVICE))
	{
		ASK(break, return(ITS_SUCCESS), " Local User is Out Of Service -- Continue (Y/N)??? ");
	} /* if */

	if (!((TESTON(theClass, 2)) | (TESTON(theClass, 3))))
	{
		ASK(break, return(ITS_SUCCESS), " Class is not 2 or 3 -- RLSD not Valid -- Continue (Y/N)??? ");
	} /* if */
	srchdr.type = ITS_SCCP;
	srchdr.context.conref = LocalRef;

	// Instantiate the Class
	SCCP_Released rm;

	/* Destination Local Reference */
	// Instantiate the Class
	SCCP_DestinationLocalRef dlr(DestRef);
	rm.AddIE(&dlr);

	/* Source Local Reference */
	// Instantiate the Class
	SCCP_SourceLocalRef slr(LocalRef);
	rm.AddIE(&slr);

	/* Released Cause */
	// Instantiate the Class
	SCCP_ReleaseCause rc(SCCP_RLC_END_USER_ORG);
	rm.AddIE(&rc);

	// Data
	// Instantiate the Class
	SCCP_UserData ud;
	int len = 10;                      //len=3-130
	ITS_OCTET data[10];
	// fill data
	for(i=0;i<len;i++)
	{
	    data[i] = i;
	}
	ud.SetUserData(data, len);
	rm.AddIE(&ud);

	/* Send the message  */
	ret = SCCP_MessageClass::Send(handle, &srchdr, &rm);
	if (ret != ITS_SUCCESS)
	{
	    printf("Error Sending SCCP_MSG_RLSD to Stack !! %d\n", ret);
	}
	else
	{
		SETON(pendingRecvState, RLC_PENDING);
		cout<<"Successfully sending RLSD"<<endl;
	}
 	SETOFF(ssnState, ACTIVE_CONNECTION);


	if (TESTON(pgmCntl, AUTO_RECV))
	{
		cout << "Auto Wait for RLC" << endl;
		WaitToReceive(instance, handle);
	} /* if */

	return (ITS_SUCCESS);
} /* SendRLSD */


int
SendRLC(ITS_USHORT instance, ITS_HANDLE handle)
{
//    ITS_SCCP_IE sccpIES[7];
    int ret = ITS_SUCCESS;

	if (!TESTON(ssnState, IN_SERVICE))
	{
		ASK(break, return(ITS_SUCCESS), " Local User is Out Of Service -- Continue (Y/N)??? ");
	} /* if */

	if (!((TESTON(theClass, 2)) | (TESTON(theClass, 3))))
	{
		ASK(break, return(ITS_SUCCESS), " Class is not 2 or 3 -- RLC not Valid -- Continue (Y/N)??? ");
	} /* if */

	srchdr.type = ITS_SCCP;
	srchdr.context.conref = LocalRef;
	/***** Sending Release Complete in response to RLSD *****/ 
	ROUTE_DeleteApplication(instance, &srchdr);


	// Instantiate the Class
	SCCP_ReleaseComplete rlc;

	/* Destination Local Reference */
	// Instantiate the Class
	SCCP_DestinationLocalRef dlr(DestRef);
	rlc.AddIE(&dlr);

	/* Source Local Reference */
	// Instantiate the Class
	SCCP_SourceLocalRef slr(LocalRef);
	rlc.AddIE(&slr);

        
	ret = SCCP_MessageClass::Send(handle, &srchdr, &rlc);
	if (ret != ITS_SUCCESS)
	{
		cout << "Error while sending RLC: " << ret << endl;
	}
	else
	{
		cout<<"Sending Release Complete ..."<<endl;
		SETOFF(pendingSendState, RLC_PENDING);
		pRecvSlr= NULL;
	}
	SETOFF(ssnState, ACTIVE_CONNECTION);

	LocalRef = 0;
	DestRef = 0;

	return (ITS_SUCCESS);
} /* SendRLC */

int
SendDT1(ITS_USHORT instance, ITS_HANDLE handle)
{
//    ITS_SCCP_IE sccpIES[7];
    int ret = ITS_SUCCESS;

	if (!TESTON(ssnState, IN_SERVICE))
	{
		ASK(break, return(ITS_SUCCESS), " Local User is Out Of Service -- Continue (Y/N)??? ");
	} /* if */

	if (!TESTON(theClass, 2))
	{
		ASK(break, return(ITS_SUCCESS), " Class is not 2 -- DT1 not Valid -- Continue (Y/N)??? ");
	} /* if */

	srchdr.type = ITS_SCCP;
	srchdr.context.conref = LocalRef;

	ITS_USHORT gttLen = 0;

	/* create a message */
	// Instantiate the Class
	SCCP_DataForm1 df1;

	/* Destination Local Reference */
	// Instantiate the Class
	SCCP_DestinationLocalRef dlr(DestRef);
	df1.AddIE(&dlr);

	/* segmenting/reassembling */
	// Instantiate the Class
	SCCP_SegmentReassem sr(0); //No more data
	/*  implementation can be changed to:
	SCCP_SegmentReassem sr();
	sr.SetSegmentReassem(1);    //0 means no data */
	df1.AddIE(&sr);

	// Instantiate the Class
	SCCP_UserData ud;
	ITS_OCTET data[11];
	int len = 5;
	/*fill data */
	data[0] = 1;
	data[1] = 2;
	data[2] = 3;
	data[3] = 4;
	data[4] = 5;
	ud.SetUserData(data, len);
	df1.AddIE(&ud);

	ret = SCCP_MessageClass::Send(handle, &srchdr, &df1);
	if(ret != ITS_SUCCESS)
	{
	    cout<<"Errors in sending DT1 "<<endl;
	}
	else
	{
	    cout<<"Successfully sending DT1 "<<endl;
	}

	return (ITS_SUCCESS);
} /* SendDT1 */

int
SendDT2(ITS_USHORT instance, ITS_HANDLE handle)
{
//    ITS_SCCP_IE sccpIES[7];
    int ret = ITS_SUCCESS;

	if (!TESTON(ssnState, IN_SERVICE))
	{
		ASK(break, return(ITS_SUCCESS), " Local User is Out Of Service -- Continue (Y/N)??? ");
	} /* if */

	if (!TESTON(theClass, 3))
	{
		ASK(break, return(ITS_SUCCESS), " Class is not 3 -- DT2 not Valid -- Continue (Y/N)??? ");
	} /* if */

	srchdr.type = ITS_SCCP;
	srchdr.context.conref = LocalRef;

	ITS_USHORT gttLen = 0;

	/* create a message */
	// Instantiate the Class
	SCCP_DataForm2 df2;

	// Instantiate the Class
	SCCP_DestinationLocalRef dlr(DestRef);
	df2.AddIE(&dlr);

	/* Sequencing/segmenting */
	// Instantiate the Class
	SCCP_SequenceSegment ss(1,1,0); // tsn=1, rsn=1, haveMore=0
	df2.AddIE(&ss);

	// Instantiate the Class
	SCCP_UserData ud;
	ITS_OCTET data[150];
	int len = 5;
	/*fill data */
	data[0] = 11;
	data[1] = 12;
	data[2] = 13;
	data[3] = 14;
	data[4] = 15;
	ud.SetUserData(data, len);
	df2.AddIE(&ud);

	/* Send the message  */
	ret = SCCP_MessageClass::Send(handle, &srchdr, &df2);
	if(ret != ITS_SUCCESS)
	{
	    cout<<"Error in sending DT2 "<<endl;
	}
	else
	{
	    cout<<"Successfully sending DT2 "<<endl;
		SETON(pendingRecvState, AK_PENDING);
	}

	if (TESTON(pgmCntl, AUTO_RECV))
	{
		cout << "Auto Wait for AK" << endl;
		WaitToReceive(instance, handle);
	} /* if */

	return (ITS_SUCCESS);
} /* SendDT2 */

int
SendAK(ITS_USHORT instance, ITS_HANDLE handle)
{
//    ITS_SCCP_IE sccpIES[7];
    int ret = ITS_SUCCESS;

	if (!TESTON(ssnState, IN_SERVICE))
	{
		ASK(break, return(ITS_SUCCESS), " Local User is Out Of Service -- Continue (Y/N)??? ");
	} /* if */

	if (!TESTON(theClass, 3))
	{
		ASK(break, return(ITS_SUCCESS), " Class is not 3 -- AK not Valid -- Continue (Y/N)??? ");
	} /* if */
	srchdr.type = ITS_SCCP;
	srchdr.context.conref = LocalRef;

	/***** Sending Data Acknowknowledgement in response to DT1 *****/ 

	// Instantiate the Class
	SCCP_Acknowledge ack;

	/* Destination Local Reference */
	// Instantiate the Class
	SCCP_DestinationLocalRef dlr(DestRef);
	ack.AddIE(&dlr);

	/* Credit */                            //len=3
	// Instantiate the Class
	SCCP_Credit credit;
	credit.SetCredit(20);					// Window of 20
	ack.AddIE(&credit);
        


    SCCP_ReceiveSequenceNum rsr(XRecvRecvSeqNum, XRecvHaveMore);
	ack.AddIE(&rsr);

	ret = SCCP_MessageClass::Send(handle, &srchdr, &ack);
	if (ret != ITS_SUCCESS)
	{
		cout << "Error while sending AK: " << ret << endl;
	}
	else
	{
		cout<<"Sending Data Acknoelegement ..."<<endl;
		SETOFF(pendingSendState, AK_PENDING);
		pRecvSlr = NULL;
	}

	return (ITS_SUCCESS);
} /* SendAK */

int
SendED(ITS_USHORT instance, ITS_HANDLE handle)
{
//    ITS_SCCP_IE sccpIES[7];
    int ret = ITS_SUCCESS;

	if (!TESTON(ssnState, IN_SERVICE))
	{
		ASK(break, return(ITS_SUCCESS), " Local User is Out Of Service -- Continue (Y/N)??? ");
	} /* if */

	if (!TESTON(theClass, 3))
	{
		ASK(break, return(ITS_SUCCESS), " Class is not 3 -- ED not Valid -- Continue (Y/N)??? ");
	} /* if */
	srchdr.type = ITS_SCCP;
	srchdr.context.conref = LocalRef;

	
	/***** Sending Expedited Data *****/ 

	// Instantiate the Class
	SCCP_ExpeditedData ed;

	/* Destination Local Reference */
	// Instantiate the Class
	SCCP_DestinationLocalRef dlr(DestRef);
	ed.AddIE(&dlr);


	// Data                                     //len=2-33
	// Instantiate the Class
	SCCP_UserData ud;
	int len = 10;
	ITS_OCTET data[10];
	//fill data
	for(ITS_OCTET i=0;i<len;i++)
	{
		data[i] = i;
	}
	ud.SetUserData(data, len);
	ed.AddIE(&ud);
        
	ret = SCCP_MessageClass::Send(handle, &srchdr, &ed);
	if (ret != ITS_SUCCESS)
	{
		cout << "Error while sending ED: " << ret << endl;
	}
	else
	{
		cout<<"Sending Expedited Data ..."<<endl;
		SETON(pendingRecvState, EA_PENDING);
	}

	if (TESTON(pgmCntl, AUTO_RECV))
	{
		cout << "Auto Wait for EA" << endl;
		WaitToReceive(instance, handle);
		pRecvSlr= NULL;
	} /* if */

	return (ITS_SUCCESS);
} /* SendED */

int
SendEA(ITS_USHORT instance, ITS_HANDLE handle)
{
//    ITS_SCCP_IE sccpIES[7];
    int ret = ITS_SUCCESS;

	if (!TESTON(ssnState, IN_SERVICE))
	{
		ASK(break, return(ITS_SUCCESS), " Local User is Out Of Service -- Continue (Y/N)??? ");
	} /* if */

	if (!TESTON(theClass, 3))
	{
		ASK(break, return(ITS_SUCCESS), " Class is not 3 -- EA not Valid -- Continue (Y/N)??? ");
	} /* if */

	srchdr.type = ITS_SCCP;
	srchdr.context.conref = LocalRef;

	/***** Sending Expedited Data Acknowledgement in response to ED *****/ 

	// Instantiate the Class
	SCCP_ExpeditedDataAcknowledge ea;

	/* Destination Local Reference */
	// Instantiate the Class
	SCCP_DestinationLocalRef dlr(DestRef);
	ea.AddIE(&dlr);


       
	ret = SCCP_MessageClass::Send(handle, &srchdr, &ea);
	if (ret != ITS_SUCCESS)
	{
		cout << "Error while sending EA: " << ret << endl;
	}
	else
	{
		cout<<"Sending Expedited Data Acknowledgement ..."<<endl;
		SETOFF(pendingSendState, EA_PENDING);
		pRecvSlr = NULL;
	}

	return (ITS_SUCCESS);
} /* SendEA */

int
SendRSR(ITS_USHORT instance, ITS_HANDLE handle)
{
//    ITS_SCCP_IE sccpIES[7];
    int ret = ITS_SUCCESS;

	if (!TESTON(ssnState, IN_SERVICE))
	{
		ASK(break, return(ITS_SUCCESS), " Local User is Out Of Service -- Continue (Y/N)??? ");
	} /* if */

	if (!TESTON(theClass, 3))
	{
		ASK(break, return(ITS_SUCCESS), " Class is not 3 -- RSR not Valid -- Continue (Y/N)??? ");
	} /* if */

	srchdr.type = ITS_SCCP;
	srchdr.context.conref = LocalRef;

	/***** Sending Reset Request *****/ 

	// Instantiate the Class
	SCCP_ResetRequest rsr;

	/* Destination Local Reference */
	// Instantiate the Class
	SCCP_DestinationLocalRef dlr(DestRef);
	rsr.AddIE(&dlr);

	/* Source Local Reference */
	// Instantiate the Class
	SCCP_SourceLocalRef slr(LocalRef);
	rsr.AddIE(&slr);

	// Instantiate the Class
	SCCP_ResetCause rc(SCCP_RES_END_USER_ORG);
 	rsr.AddIE(&rc);

	ret = SCCP_MessageClass::Send(handle, &srchdr, &rsr);
	if (ret != ITS_SUCCESS)
	{
		cout << "Error while sending RSR: " << ret << endl;
	}
	else
	{
		cout<<"Sending Reset Request ..."<<endl;
		SETON(pendingRecvState, RSC_PENDING);
		pRecvSlr = NULL;
	}

	if (TESTON(pgmCntl, AUTO_RECV))
	{
		cout << "Auto Wait for RSC" << endl;
		WaitToReceive(instance, handle);
	} /* if */

	return (ITS_SUCCESS);
} /* SendRSR */

int
SendRSC(ITS_USHORT instance, ITS_HANDLE handle)
{
//    ITS_SCCP_IE sccpIES[7];
    int ret = ITS_SUCCESS;

	if (!TESTON(ssnState, IN_SERVICE))
	{
		ASK(break, return(ITS_SUCCESS), " Local User is Out Of Service -- Continue (Y/N)??? ");
	} /* if */

	if (!TESTON(theClass, 3))
	{
		ASK(break, return(ITS_SUCCESS), " Class is not 3 -- RSC not Valid -- Continue (Y/N)??? ");
	} /* if */

	srchdr.type = ITS_SCCP;
	srchdr.context.conref = LocalRef;

	/***** Sending Reset Confirm in response to RSR *****/ 

	// Instantiate the Class
	SCCP_ResetConfirm rsc;

	/* Destination Local Reference */
	// Instantiate the Class
	SCCP_DestinationLocalRef dlr(DestRef);
	rsc.AddIE(&dlr);

	/* Source Local Reference */
	// Instantiate the Class
	SCCP_SourceLocalRef slr(LocalRef);
	rsc.AddIE(&slr);

 
	ret = SCCP_MessageClass::Send(handle, &srchdr, &rsc);
	if (ret != ITS_SUCCESS)
	{
		cout << "Error while sending RSC: " << ret << endl;
	}
	else
	{
		cout<<"Sending Connection Confirm ..."<<endl;
		SETOFF(pendingSendState, RSC_PENDING);
		pRecvSlr = NULL;
	}

	return (ITS_SUCCESS);
} /* SendRSC */

int
SendERR(ITS_USHORT instance, ITS_HANDLE handle)
{
//    ITS_SCCP_IE sccpIES[7];
    int ret = ITS_SUCCESS;

	if (!TESTON(ssnState, IN_SERVICE))
	{
		ASK(break, return(ITS_SUCCESS), " Local User is Out Of Service -- Continue (Y/N)??? ");
	} /* if */

	if (!((TESTON(theClass, 2)) | (TESTON(theClass, 3))))
	{
		ASK(break, return(ITS_SUCCESS), " Class is not 2 or 3 -- ERR not Valid -- Continue (Y/N)??? ");
	} /* if */
	srchdr.type = ITS_SCCP;
	srchdr.context.conref = LocalRef;


	/***** Sending Error Mesage *****/ 

	// Instantiate the Class
	SCCP_Error err;

	/* Destination Local Reference */
	// Instantiate the Class
	SCCP_DestinationLocalRef dlr(DestRef);
	err.AddIE(&dlr);

	// Instantiate the Class
	SCCP_ErrorCause ec(SCCP_ERR_UNQUAL);
	err.AddIE(&ec);

       
	ret = SCCP_MessageClass::Send(handle, &srchdr, &err);
	if (ret != ITS_SUCCESS)
	{
		cout << "Error while sending ERR: " << ret << endl;
	}
	else
	{
		cout<<"Sending Error Message ..."<<endl;
		pRecvSlr = NULL;
	}

	return (ITS_SUCCESS);
} /* SendERR */

int
SendIT(ITS_USHORT instance, ITS_HANDLE handle)
{
//    ITS_SCCP_IE sccpIES[7];
    int ret = ITS_SUCCESS;

	if (!TESTON(ssnState, IN_SERVICE))
	{
		ASK(break, return(ITS_SUCCESS), " Local User is Out Of Service -- Continue (Y/N)??? ");
	} /* if */

	if (!((TESTON(theClass, 2)) | (TESTON(theClass, 3))))
	{
		ASK(break, return(ITS_SUCCESS), " Class is not 2 or 3 -- IT not Valid -- Continue (Y/N)??? ");
	} /* if */
	srchdr.type = ITS_SCCP;
	srchdr.context.conref = LocalRef;

	/***** Sending Inactivity Test *****/ 

	// Instantiate the Class
	SCCP_InactivityTest it;

	/* Destination Local Reference */
	// Instantiate the Class
	SCCP_DestinationLocalRef dlr(DestRef);
	it.AddIE(&dlr);

	/* Source Local Reference */
	// Instantiate the Class
	SCCP_SourceLocalRef slr(LocalRef);
	it.AddIE(&slr);

	/* Protocol Class */
	// Instantiate the Class
	SCCP_ProtocolClass pc(SCCP_PCLASS_2);
	it.AddIE(&pc);

	/* Credit */                            //len=3
	// Instantiate the Class
	SCCP_Credit credit;
	credit.SetCredit(20);
	it.AddIE(&credit);


    SCCP_SequenceSegment ss(sendSequenceNumber, receiveSequenceNumber, HAVE_MORE);

        
	ret = SCCP_MessageClass::Send(handle, &srchdr, &it);
	if (ret != ITS_SUCCESS)
	{
		cout << "Error while sending IT: " << ret << endl;
	}
	else
	{
		cout<<"Sending Inactivity Test ..."<<endl;
		pRecvSlr = NULL;
	}


	return (ITS_SUCCESS);
} /* SendIT */



int
SendUDT0(ITS_USHORT instance, ITS_HANDLE handle)
{
//    ITS_SCCP_IE sccpIES[7];
    int ret = ITS_SUCCESS;

	if (!TESTON(ssnState, IN_SERVICE))
	{
		ASK(break, return(ITS_SUCCESS), " Local User is Out Of Service -- Continue (Y/N)??? ");
	} /* if */

	srchdr.type = ITS_SCCP;
	srchdr.context.ssn = (ITS_USHORT) local_ssn;

//        ITS_UINT pc;
//        ITS_OCTET ssn = SCCP_SSN_NONE, addrInd = 0, gttInfo[32];
	ITS_USHORT gttLen = 0;
//        SCCP_ADDR cdp;

	/* create a message */
	// Instantiate the Class
	SCCP_UnitData udt;


	// Instantiate the Class
	SCCP_ProtocolClass pc(SCCP_PCLASS_0);
	udt.AddIE(&pc);

	/* Called Party Address */
	//len=3 min
	SCCP_CalledPartyAddr called_pa;
	called_pa.SetPointCode(remote_pc);          //octet 3 - any
	called_pa.SetSSN(remote_ssn);               //octet 2 - 0000 0001
	called_pa.SetRouteByPCSSN(true);            //octet 1 bit 7
	called_pa.SetInternationalRouting(false);   //octet 1 bit 8
	udt.AddIE(&called_pa);

	/* Calling Party Address */
	//len=3 min
	SCCP_CallingPartyAddr calling_pa;
	calling_pa.SetPointCode(local_pc);           //octet 3 - any
	calling_pa.SetSSN(local_ssn);                //octet 2 - 0000 0001
	calling_pa.SetRouteByPCSSN(true);            //octet 1 bit 7
	calling_pa.SetInternationalRouting(false);   //octet 1 bit 8
	udt.AddIE(&calling_pa);


	// Instantiate the Class
	SCCP_UserData ud;
	ITS_OCTET data[11];
	int len = 5;
	/*fill data */
	data[0] = 1;
	data[1] = 2;
	data[2] = 3;
	data[3] = 4;
	data[4] = 5;
	ud.SetUserData(data, len);
	udt.AddIE(&ud);

	ret = SCCP_MessageClass::Send(handle, &srchdr, &udt);
	if(ret != ITS_SUCCESS)
	{
	    cout<<"Errors in sending UDT Class 0 "<<endl;
	}
	else
	{
	    cout<<"Successfully sending UDT Class 0 "<<endl;
	}


	return (ITS_SUCCESS);
} /* SendUDT0 */




int
SendUDT1(ITS_USHORT instance, ITS_HANDLE handle)
{
//    ITS_SCCP_IE sccpIES[7];
    int ret = ITS_SUCCESS;

	if (!TESTON(ssnState, IN_SERVICE))
	{
		ASK(break, return(ITS_SUCCESS), " Local User is Out Of Service -- Continue (Y/N)??? ");
	} /* if */

	srchdr.type = ITS_SCCP;
	srchdr.context.ssn = (ITS_USHORT) local_ssn;

//        ITS_UINT pc;
//        ITS_OCTET ssn = SCCP_SSN_NONE, addrInd = 0, gttInfo[32];
	ITS_USHORT gttLen = 0;
//        SCCP_ADDR cdp;

	/* create a message */
	// Instantiate the Class
	SCCP_UnitData udt;


	// Instantiate the Class
	SCCP_ProtocolClass pc(SCCP_PCLASS_1);
	udt.AddIE(&pc);

	/* Called Party Address */
	//len=3 min
	SCCP_CalledPartyAddr called_pa;
	called_pa.SetPointCode(remote_pc);          //octet 3 - any
	called_pa.SetSSN(remote_ssn);               //octet 2 - 0000 0001
	called_pa.SetRouteByPCSSN(true);            //octet 1 bit 7
	called_pa.SetInternationalRouting(false);   //octet 1 bit 8
	udt.AddIE(&called_pa);

	/* Calling Party Address */
	//len=3 min
	SCCP_CallingPartyAddr calling_pa;
	calling_pa.SetPointCode(local_pc);           //octet 3 - any
	calling_pa.SetSSN(local_ssn);                //octet 2 - 0000 0001
	calling_pa.SetRouteByPCSSN(true);            //octet 1 bit 7
	calling_pa.SetInternationalRouting(false);   //octet 1 bit 8
	udt.AddIE(&calling_pa);


	// Instantiate the Class
	SCCP_UserData ud;
	ITS_OCTET data[11];
	int len = 5;
	/*fill data */
	data[0] = 1;
	data[1] = 2;
	data[2] = 3;
	data[3] = 4;
	data[4] = 5;
	ud.SetUserData(data, len);
	udt.AddIE(&ud);

	ret = SCCP_MessageClass::Send(handle, &srchdr, &udt);
	if(ret != ITS_SUCCESS)
	{
	    cout<<"Errors in sending UDT Class 1 "<<endl;
	}
	else
	{
	    cout<<"Successfully sending UDT Class 1 "<<endl;
	}


	return (ITS_SUCCESS);
} /* SendUDT1 */


int
SendUDTS(ITS_USHORT instance, ITS_HANDLE handle)
{
//    ITS_SCCP_IE sccpIES[7];
    int ret = ITS_SUCCESS;

	if (!TESTON(ssnState, IN_SERVICE))
	{
		ASK(break, return(ITS_SUCCESS), " Local User is Out Of Service -- Continue (Y/N)??? ");
	} /* if */

	srchdr.type = ITS_SCCP;
	srchdr.context.ssn = (ITS_USHORT) local_ssn;

//        ITS_UINT pc;
//        ITS_OCTET ssn = SCCP_SSN_NONE, addrInd = 0, gttInfo[32];
	ITS_USHORT gttLen = 0;
//        SCCP_ADDR cdp;

	/* create a message */
	// Instantiate the Class
	SCCP_UnitDataService udts;


	// Instantiate the Class
	SCCP_ReturnCause rc(SCCP_RET_SUBSYS_CONG);
	udts.AddIE(&rc);

	/* Called Party Address */
	//len=3 min
	SCCP_CalledPartyAddr called_pa;
	called_pa.SetPointCode(remote_pc);          //octet 3 - any
	called_pa.SetSSN(remote_ssn);               //octet 2 - 0000 0001
	called_pa.SetRouteByPCSSN(true);            //octet 1 bit 7
	called_pa.SetInternationalRouting(false);   //octet 1 bit 8
	udts.AddIE(&called_pa);

	/* Calling Party Address */
	//len=3 min
	SCCP_CallingPartyAddr calling_pa;
	calling_pa.SetPointCode(local_pc);           //octet 3 - any
	calling_pa.SetSSN(local_ssn);                //octet 2 - 0000 0001
	calling_pa.SetRouteByPCSSN(true);            //octet 1 bit 7
	calling_pa.SetInternationalRouting(false);   //octet 1 bit 8
	udts.AddIE(&calling_pa);


	// Instantiate the Class
	SCCP_UserData ud;
	ITS_OCTET data[11];
	int len = 5;
	/*fill data */
	data[0] = 1;
	data[1] = 2;
	data[2] = 3;
	data[3] = 4;
	data[4] = 5;
	ud.SetUserData(data, len);
	udts.AddIE(&ud);

	ret = SCCP_MessageClass::Send(handle, &srchdr, &udts);
	if(ret != ITS_SUCCESS)
	{
	    cout<<"Errors in sending UDTS "<<endl;
	}
	else
	{
	    cout<<"Successfully sending UDTS "<<endl;
	}


	return (ITS_SUCCESS);
} /* SendUDTS */


int
SendXUDT0(ITS_USHORT instance, ITS_HANDLE handle)
{
//    ITS_SCCP_IE sccpIES[7];
    int ret = ITS_SUCCESS;
	int i;

	if (!TESTON(ssnState, IN_SERVICE))
	{
		ASK(break, return(ITS_SUCCESS), " Local User is Out Of Service -- Continue (Y/N)??? ");
	} /* if */

	srchdr.type = ITS_SCCP;
	srchdr.context.ssn = (ITS_USHORT) local_ssn;

	ITS_USHORT gttLen = 0;

	/* create a message */
	// Instantiate the Class
	SCCP_ExtendedUnitData eudt;


	// Instantiate the Class
	SCCP_ProtocolClass pc(SCCP_PCLASS_0);
	eudt.AddIE(&pc);

	/* Called Party Address */
	//len=3 min
	SCCP_CalledPartyAddr called_pa;
	called_pa.SetPointCode(remote_pc);          //octet 3 - any
	called_pa.SetSSN(remote_ssn);               //octet 2 - 0000 0001
	called_pa.SetRouteByPCSSN(true);            //octet 1 bit 7
	called_pa.SetInternationalRouting(false);   //octet 1 bit 8
	eudt.AddIE(&called_pa);

	/* Calling Party Address */
	//len=3 min
	SCCP_CallingPartyAddr calling_pa;
	calling_pa.SetPointCode(local_pc);           //octet 3 - any
	calling_pa.SetSSN(local_ssn);                //octet 2 - 0000 0001
	calling_pa.SetRouteByPCSSN(true);            //octet 1 bit 7
	calling_pa.SetInternationalRouting(false);   //octet 1 bit 8
	eudt.AddIE(&calling_pa);

	SCCP_HopCount hop_Counter(10);
	eudt.AddIE(&hop_Counter);

	// Instantiate the Class
	SCCP_UserData ud;
	ITS_OCTET data[MAX_XUDT_LEN+1];
	int len = MAX_XUDT_LEN;
	/*fill data */
	for(i = 0; i <= MAX_XUDT_LEN; i++)
	{
		data[i] = (unsigned char) i+1;
	} /* for */
	ud.SetUserData(data, len);
	eudt.AddIE(&ud);

	ret = SCCP_MessageClass::Send(handle, &srchdr, &eudt);
	if(ret != ITS_SUCCESS)
	{
	    cout<<"Errors in sending XUDT Class 0 "<<endl;
	}
	else
	{
	    cout<<"Successfully sending XUDT Class 0 "<<endl;
	}

	return (ITS_SUCCESS);
} /* SendXUDT0 */


int
SendXUDT1(ITS_USHORT instance, ITS_HANDLE handle)
{
//    ITS_SCCP_IE sccpIES[7];
    int ret = ITS_SUCCESS;
	int i;

	if (!TESTON(ssnState, IN_SERVICE))
	{
		ASK(break, return(ITS_SUCCESS), " Local User is Out Of Service -- Continue (Y/N)??? ");
	} /* if */

	srchdr.type = ITS_SCCP;
	srchdr.context.ssn = (ITS_USHORT) local_ssn;

	ITS_USHORT gttLen = 0;

	/* create a message */
	// Instantiate the Class
	SCCP_ExtendedUnitData eudt;


	// Instantiate the Class
	SCCP_ProtocolClass pc(SCCP_PCLASS_1);
	eudt.AddIE(&pc);

	/* Called Party Address */
	//len=3 min
	SCCP_CalledPartyAddr called_pa;
	called_pa.SetPointCode(remote_pc);          //octet 3 - any
	called_pa.SetSSN(remote_ssn);               //octet 2 - 0000 0001
	called_pa.SetRouteByPCSSN(true);            //octet 1 bit 7
	called_pa.SetInternationalRouting(false);   //octet 1 bit 8
	eudt.AddIE(&called_pa);

	/* Calling Party Address */
	//len=3 min
	SCCP_CallingPartyAddr calling_pa;
	calling_pa.SetPointCode(local_pc);           //octet 3 - any
	calling_pa.SetSSN(local_ssn);                //octet 2 - 0000 0001
	calling_pa.SetRouteByPCSSN(true);            //octet 1 bit 7
	calling_pa.SetInternationalRouting(false);   //octet 1 bit 8
	eudt.AddIE(&calling_pa);

	
	SCCP_HopCount hop_Counter(10);
	eudt.AddIE(&hop_Counter);

	// Instantiate the Class
	SCCP_UserData ud;
	ITS_OCTET data[MAX_XUDT_LEN+1];
	int len = MAX_XUDT_LEN;
	/*fill data */
	for(i = 0; i <= MAX_XUDT_LEN; i++)
	{
		data[i] = (unsigned char) i+1;
	} /* for */
	ud.SetUserData(data, len);
	eudt.AddIE(&ud);

	ret = SCCP_MessageClass::Send(handle, &srchdr, &eudt);
	if(ret != ITS_SUCCESS)
	{
	    cout<<"Errors in sending XUDT Class 1 "<<endl;
	}
	else
	{
	    cout<<"Successfully sending XUDT Class 1 "<<endl;
	}

	return (ITS_SUCCESS);
} /* SendXUDT1 */



int
SendXUDTS(ITS_USHORT instance, ITS_HANDLE handle)
{
//    ITS_SCCP_IE sccpIES[7];
    int ret = ITS_SUCCESS;
	int i;

	if (!TESTON(ssnState, IN_SERVICE))
	{
		ASK(break, return(ITS_SUCCESS), " Local User is Out Of Service -- Continue (Y/N)??? ");
	} /* if */

	srchdr.type = ITS_SCCP;
	srchdr.context.ssn = (ITS_USHORT) local_ssn;

//        ITS_UINT pc;
//        ITS_OCTET ssn = SCCP_SSN_NONE, addrInd = 0, gttInfo[32];
	ITS_USHORT gttLen = 0;
//        SCCP_ADDR cdp;

	/* create a message */
	// Instantiate the Class
	SCCP_ExtendedUnitDataService eudts;


	// Instantiate the Class
	SCCP_ReturnCause rc(SCCP_RET_SUBSYS_CONG);
	eudts.AddIE(&rc);

	/* Called Party Address */
	//len=3 min
	SCCP_CalledPartyAddr called_pa;
	called_pa.SetPointCode(remote_pc);          //octet 3 - any
	called_pa.SetSSN(remote_ssn);               //octet 2 - 0000 0001
	called_pa.SetRouteByPCSSN(true);            //octet 1 bit 7
	called_pa.SetInternationalRouting(false);   //octet 1 bit 8
	eudts.AddIE(&called_pa);

	/* Calling Party Address */
	//len=3 min
	SCCP_CallingPartyAddr calling_pa;
	calling_pa.SetPointCode(local_pc);           //octet 3 - any
	calling_pa.SetSSN(local_ssn);                //octet 2 - 0000 0001
	calling_pa.SetRouteByPCSSN(true);            //octet 1 bit 7
	calling_pa.SetInternationalRouting(false);   //octet 1 bit 8
	eudts.AddIE(&calling_pa);


	SCCP_HopCount hop_Counter(10);
	eudts.AddIE(&hop_Counter);

	// Instantiate the Class
	SCCP_UserData ud;
	ITS_OCTET data[MAX_XUDT_LEN+1];
	int len = MAX_XUDT_LEN;
	/*fill data */
	for(i = 0; i <= MAX_XUDT_LEN; i++)
	{
		data[i] = (unsigned char) i+1;
	} /* for */
	ud.SetUserData(data, len);
	eudts.AddIE(&ud);

	ret = SCCP_MessageClass::Send(handle, &srchdr, &eudts);
	if(ret != ITS_SUCCESS)
	{
	    cout<<"Errors in sending XUDTS "<<endl;
	}
	else
	{
	    cout<<"Successfully sending XUDTS "<<endl;
	}


	return (ITS_SUCCESS);
} /* SendXUDTS */


int
SendLUDT0(ITS_USHORT instance, ITS_HANDLE handle)
{
//    ITS_SCCP_IE sccpIES[7];
    int ret = ITS_SUCCESS;
	int i;

	if (!TESTON(ssnState, IN_SERVICE))
	{
		ASK(break, return(ITS_SUCCESS), " Local User is Out Of Service -- Continue (Y/N)??? ");
	} /* if */

	srchdr.type = ITS_SCCP;
	srchdr.context.ssn = (ITS_USHORT) local_ssn;

	ITS_USHORT gttLen = 0;

	/* create a message */
	// Instantiate the Class
	SCCP_UnitData ludt;		// Send it with more than 255 bytes of data  -- SCCP converts to long form


	// Instantiate the Class
	SCCP_ProtocolClass pc(SCCP_PCLASS_0);
	ludt.AddIE(&pc);

	/* Called Party Address */
	//len=3 min
	SCCP_CalledPartyAddr called_pa;
	called_pa.SetPointCode(remote_pc);          //octet 3 - any
	called_pa.SetSSN(remote_ssn);               //octet 2 - 0000 0001
	called_pa.SetRouteByPCSSN(true);            //octet 1 bit 7
	called_pa.SetInternationalRouting(false);   //octet 1 bit 8
	ludt.AddIE(&called_pa);

	/* Calling Party Address */
	//len=3 min
	SCCP_CallingPartyAddr calling_pa;
	calling_pa.SetPointCode(local_pc);           //octet 3 - any
	calling_pa.SetSSN(local_ssn);                //octet 2 - 0000 0001
	calling_pa.SetRouteByPCSSN(true);            //octet 1 bit 7
	calling_pa.SetInternationalRouting(false);   //octet 1 bit 8
	ludt.AddIE(&calling_pa);

	// Instantiate the Class
	SCCP_UserData ud;
	ITS_OCTET data[MAX_LUDT_LEN+1];
	int len = MAX_LUDT_LEN;
	/*fill data */
	for(i = 0; i <= MAX_LUDT_LEN; i++)
	{
		data[i] = (unsigned char) i+1;
	} /* for */
	ud.SetUserData(data, len);
	ludt.AddIE(&ud);

	ret = SCCP_MessageClass::Send(handle, &srchdr, &ludt);
	if(ret != ITS_SUCCESS)
	{
	    cout<<"Errors in sending LUDT Class 0 "<<endl;
	}
	else
	{
	    cout<<"Successfully sending LUDT Class 0 "<<endl;
	}


	return (ITS_SUCCESS);
} /* SendLUDT0 */




int
SendLUDT1(ITS_USHORT instance, ITS_HANDLE handle)
{
//    ITS_SCCP_IE sccpIES[7];
    int ret = ITS_SUCCESS;
	int i;

	if (!TESTON(ssnState, IN_SERVICE))
	{
		ASK(break, return(ITS_SUCCESS), " Local User is Out Of Service -- Continue (Y/N)??? ");
	} /* if */

	srchdr.type = ITS_SCCP;
	srchdr.context.ssn = (ITS_USHORT) local_ssn;

	ITS_USHORT gttLen = 0;

	/* create a message */
	// Instantiate the Class
	SCCP_UnitData ludt;		// Send it with more than 255 bytes of data  -- SCCP converts to long form


	// Instantiate the Class
	SCCP_ProtocolClass pc(SCCP_PCLASS_1);
	ludt.AddIE(&pc);

	/* Called Party Address */
	//len=3 min
	SCCP_CalledPartyAddr called_pa;
	called_pa.SetPointCode(remote_pc);          //octet 3 - any
	called_pa.SetSSN(remote_ssn);               //octet 2 - 0000 0001
	called_pa.SetRouteByPCSSN(true);            //octet 1 bit 7
	called_pa.SetInternationalRouting(false);   //octet 1 bit 8
	ludt.AddIE(&called_pa);

	/* Calling Party Address */
	//len=3 min
	SCCP_CallingPartyAddr calling_pa;
	calling_pa.SetPointCode(local_pc);           //octet 3 - any
	calling_pa.SetSSN(local_ssn);                //octet 2 - 0000 0001
	calling_pa.SetRouteByPCSSN(true);            //octet 1 bit 7
	calling_pa.SetInternationalRouting(false);   //octet 1 bit 8
	ludt.AddIE(&calling_pa);

	// Instantiate the Class
	SCCP_UserData ud;
	ITS_OCTET data[MAX_LUDT_LEN+1];
	int len = MAX_LUDT_LEN;
	/*fill data */
	for(i = 0; i <= MAX_LUDT_LEN; i++)
	{
		data[i] = (unsigned char) i+1;
	} /* for */
	ud.SetUserData(data, len);
	ludt.AddIE(&ud);

	ret = SCCP_MessageClass::Send(handle, &srchdr, &ludt);
	if(ret != ITS_SUCCESS)
	{
	    cout<<"Errors in sending LUDT Class 1 "<<endl;
	}
	else
	{
	    cout<<"Successfully sending LUDT Class 1 "<<endl;
	}


	return (ITS_SUCCESS);
} /* SendLUDT1 */



int
SendLUDTS(ITS_USHORT instance, ITS_HANDLE handle)
{
//    ITS_SCCP_IE sccpIES[7];
    int ret = ITS_SUCCESS;
	int i;

	if (!TESTON(ssnState, IN_SERVICE))
	{
		ASK(break, return(ITS_SUCCESS), " Local User is Out Of Service -- Continue (Y/N)??? ");
	} /* if */

	srchdr.type = ITS_SCCP;
	srchdr.context.ssn = (ITS_USHORT) local_ssn;

//        ITS_UINT pc;
//        ITS_OCTET ssn = SCCP_SSN_NONE, addrInd = 0, gttInfo[32];
	ITS_USHORT gttLen = 0;
//        SCCP_ADDR cdp;

	/* create a message */
	// Instantiate the Class
	SCCP_UnitDataService ludts;


	// Instantiate the Class
	SCCP_ReturnCause rc(SCCP_RET_SUBSYS_CONG);
	ludts.AddIE(&rc);

	/* Called Party Address */
	//len=3 min
	SCCP_CalledPartyAddr called_pa;
	called_pa.SetPointCode(remote_pc);          //octet 3 - any
	called_pa.SetSSN(remote_ssn);               //octet 2 - 0000 0001
	called_pa.SetRouteByPCSSN(true);            //octet 1 bit 7
	called_pa.SetInternationalRouting(false);   //octet 1 bit 8
	ludts.AddIE(&called_pa);

	/* Calling Party Address */
	//len=3 min
	SCCP_CallingPartyAddr calling_pa;
	calling_pa.SetPointCode(local_pc);           //octet 3 - any
	calling_pa.SetSSN(local_ssn);                //octet 2 - 0000 0001
	calling_pa.SetRouteByPCSSN(true);            //octet 1 bit 7
	calling_pa.SetInternationalRouting(false);   //octet 1 bit 8
	ludts.AddIE(&calling_pa);


	// Instantiate the Class
	SCCP_UserData ud;
	ITS_OCTET data[MAX_XUDT_LEN+1];
	int len = MAX_XUDT_LEN;
	/*fill data */
	for(i = 0; i <= MAX_XUDT_LEN; i++)
	{
		data[i] = (unsigned char) i+1;
	} /* for */
	ud.SetUserData(data, len);
	ludts.AddIE(&ud);

	ret = SCCP_MessageClass::Send(handle, &srchdr, &ludts);
	if(ret != ITS_SUCCESS)
	{
	    cout<<"Errors in sending LUDTS "<<endl;
	}
	else
	{
	    cout<<"Successfully sending LUDTS "<<endl;
	}


	return (ITS_SUCCESS);
} /* SendLUDTS */

int
SetAutoRespOn(ITS_USHORT instance, ITS_HANDLE handle)
{
	SETON(pgmCntl, AUTO_RESP);
	return (ITS_SUCCESS);
} /* SetAutoRespOn */

int
SetAutoRespOff(ITS_USHORT instance, ITS_HANDLE handle)
{
	SETOFF(pgmCntl, AUTO_RESP);
	return (ITS_SUCCESS);
} /* SetAutoRespOff */

int
SetAutoRecvOn(ITS_USHORT instance, ITS_HANDLE handle)
{
	SETON(pgmCntl, AUTO_RECV);
	return (ITS_SUCCESS);
} /* SetAutoRecvOn */

int
SetAutoRecvOff(ITS_USHORT instance, ITS_HANDLE handle)
{
	SETOFF(pgmCntl, AUTO_RECV);
	return (ITS_SUCCESS);
} /* SetAutoRecvOff */

int
SetReceiverModeOn(ITS_USHORT instance, ITS_HANDLE handle)
{
	SETON(pgmCntl, RECEIVER_MODE);
	return (ITS_SUCCESS);
} /* SetReceiverModeOn */


int
SetReceiverModeOff(ITS_USHORT instance, ITS_HANDLE handle)
{
	SETOFF(pgmCntl, RECEIVER_MODE);
	return (ITS_SUCCESS);
} /* SetReceiverModeOff */

int
SetPeekModeOn(ITS_USHORT instance, ITS_HANDLE handle)
{
	SETON(pgmCntl, PEEK_MODE);
	return (ITS_SUCCESS);
} /* SetPeekModeOn */

int
SetPeekModeOff(ITS_USHORT instance, ITS_HANDLE handle)
{
	SETOFF(pgmCntl, PEEK_MODE);
	return (ITS_SUCCESS);
} /* SetPeekModeOff */
int
ShowStatus(ITS_USHORT instance, ITS_HANDLE handle)
{
	char x;

	if (TESTON(ssnState, IN_SERVICE))
	{
		cout << "In Service --";
	} /* if */

	if (TESTON(ssnState, CONGESTED))
	{
		cout << "In Service --";
	} /* if */

	if (TESTON(ssnState, ACTIVE_CONNECTION))
	{
		cout << "Active Connection --";
	} /* if */

	if (TESTON(pendingRecvState, RSC_PENDING))
	{
		cout << "RSC Pending Receive --";
	} /* if */

	if (TESTON(pendingRecvState, CC_PENDING))
	{
		cout << "CC Pending Receive --";
	} /* if */

	if (TESTON(pendingRecvState, RLC_PENDING))
	{
		cout << "RLC Pending Receive --";
	} /* if */

	if (TESTON(pendingRecvState, AK_PENDING))
	{
		cout << "AK Pending Receive --";
	} /* if */

	if (TESTON(pendingRecvState, EA_PENDING))
	{
		cout << "EA Pending Receive --";
	} /* if */

	if (TESTON(pendingSendState, RSC_PENDING))
	{
		cout << "RSC Pending Receive";
	} /* if */

	cout << endl;


	if (TESTON(pendingSendState, CC_PENDING))
	{
		cout << "CC Pending Send --";
	} /* if */

	if (TESTON(pendingSendState, RLC_PENDING))
	{
		cout << "RLC Pending Send --";
	} /* if */

	if (TESTON(pendingSendState, AK_PENDING))
	{
		cout << "AK Pending Send --";
	} /* if */


	if (TESTON(pendingSendState, EA_PENDING))
	{
		cout << "EA Pending Send";
	} /* if */

	cout << endl;

	if (TESTON(pgmCntl, AUTO_RESP))
	{
		cout << "Auto Response --";
	} /* if */

	if (TESTON(pgmCntl, AUTO_RECV))
	{
		cout << "Auto Receive --";
	} /* if */

	if (TESTON(pgmCntl, AUTO_RESOPNDED))
	{
		cout << "Auto Responded --";
	} /* if */

	if (TESTON(pgmCntl, RECEIVER_MODE))
	{
		cout << "Receiver Mode -- ";
	} /* if */

	if (TESTON(pgmCntl, PEEK_MODE))
	{
		cout << "Peek Mode";
	} /* if */

	cout << endl;

	cout << "Press Enter To Continue ";
	cin >> x;

	return (ITS_SUCCESS);
} /* ShowStatus */

int
ExitPgm(ITS_USHORT instance, ITS_HANDLE handle)
{
	fclose(fh);
	cout << "outfile closed" << endl;

	exit (ITS_SUCCESS);
} /* ExitPgm */

    ITS_USHORT len;
    ITS_USHORT src;
    ITS_OCTET* data;


int
WaitToReceive(ITS_USHORT instance, ITS_HANDLE handle)
{
	int ret = ITS_SUCCESS, i, tbl_index;
	ITS_Event event;
	const ITS_OCTET *data;
	SCCP_MessageClass *msg;
	char x, charnum[4];
	int (*pFN)(ITS_USHORT instance, ITS_HANDLE handle);
	bool cont = true;
	bool peeking = true;

	while (cont)
	{
		SETOFF(pgmCntl, AUTO_RESOPNDED);

		system("clear");
		
		while (peeking)
		{
			if (TESTON(pgmCntl, PEEK_MODE))
			{
//				if (ITS_PeekNextEvent(handle, &event.GetEvent()) == ITS_SUCCESS)
				event.SetLength(0);
				event.SetSource(0);
				event.SetData(NULL,0);

				ret = ITS_PeekNextEvent(handle, &event.GetEvent());
				if (event.GetData() != NULL) //(ret == ITS_SUCCESS)
				{
					peeking = false;
				} /* if */
				else
				{
					cout << "No Events waiting to be read - Peek Again(y) or exit function (n)  (y/n)?" << endl;
					cin >> x;
					x = tolower(x);
					if (x == 'n' || x == 'N')
					{
						return(ITS_SUCCESS);
					} /* if */
				} /* else */
			} /* if */
			peeking = false;
		} /* while */


		printf("Waiting for Event \n");
		int res = ITS_GetNextEvent(handle, &event.GetEvent());

		if (res != ITS_SUCCESS)
		{
			ITS_Error itsError(res, __FILE__, __LINE__);

			cout << endl << itsError.GetDescription() << endl;
		} /* if */
		
		peeking = true;
		
		data = event.GetData();
		cout<<endl<<"-----------------------------------------------------"<<endl;
		cout << "Received Event..." <<endl;

		//cout << "Source: <" << event.GetSource() << ">." << endl;

		printf("*---> Dump Event <---*\n");
		fprintf( fh, "*---> Dump Received Event <---*\n");

		for(i=0; i < event.GetLength(); i++)
		{
			printf("%02x ", data[i]);
			fprintf( fh, "%02x ", data[i]);

		} /* for */
		printf("\n");
		fprintf( fh, "\n");
  
		// Process Received Message

		ret = SCCP_MessageClass::Receive(handle, &sccpReceivedHdr, event, &msg);

		ITS_OCTET msgid = msg->GetMsgType();

		// Find Message in Msg Info Element Table
		for(tbl_index = 0; MsgIetbl[tbl_index].pdesc != NULL; tbl_index++)
		{
			if (MsgIetbl[tbl_index].msgid == msgid)
			{
				break;
			} /* if */
		} /* for */

		if (MsgIetbl[tbl_index].pdesc == NULL)
		{
			cout << "Received Unknown Mesage Type <" << (unsigned char) msgid << ">" << endl;
			fprintf( fh, "Received Unknown Message Type <%02x> \n", msgid);
			return(ITS_SUCCESS);
		} /* if */
	
		pFN =  (int (*)(unsigned short,void *)) MsgIetbl[tbl_index].pfn;

		cout << "Received " << (char *) MsgIetbl[tbl_index].pdesc << " message from remote" << endl;
		fprintf( fh, "Received Message Type %s \n", (char *) MsgIetbl[tbl_index].pdesc);


		if (TESTON(MsgIetbl[tbl_index].ie_bits, IE_BIT_SRC_LOCAL_REF))
		{
			pRecvSlr = (SCCP_SourceLocalRef *)msg->FindIE(SCCP_PRM_SRC_LOCAL_REF);
			if (pRecvSlr != NULL)
			{
				remhdr.context.conref = XRecvSlr = pRecvSlr->GetRefNum();

				cout<<"Source Local Reference <" << XRecvSlr << "> ";
				fprintf( fh, "Source Local Reference <%02x> ", XRecvSlr);
			} /* if */
		} /* if */

		if (TESTON(MsgIetbl[tbl_index].ie_bits, IE_BIT_DEST_LOCAL_REF))
		{
			pRecvDlr = (SCCP_DestinationLocalRef *)msg->FindIE(SCCP_PRM_DEST_LOCAL_REF);
			if (pRecvDlr != NULL)
			{
				XRecvDlr = pRecvDlr->GetRefNum();

				cout<<"Destination Local Reference <" << XRecvDlr << "> ";
				fprintf( fh, "Destination Local Reference <%02x> ", XRecvDlr);
			} /* if */
		} /* if */

		if (TESTON(MsgIetbl[tbl_index].ie_bits, IE_BIT_PROTOCOL_CLASS))
		{
			// Instantiate the Class
			pRecvProtocolClass = (SCCP_ProtocolClass *)msg->FindIE(SCCP_PRM_PROTOCOL_CLASS);
			if (pRecvProtocolClass != NULL)
			{
				if (pRecvProtocolClass->HasProtocolClass())
				{
					RecvProtocolClass = pRecvProtocolClass->GetProtocolClass();
					theClass = RecvProtocolClass;
					iTOa((ITS_OCTET) RecvProtocolClass, charnum);
					cout << "Protocol Class <" << (char *) charnum << "> ";
					fprintf( fh, "Protocol Class <%02x> ", RecvProtocolClass);
				} /* if */
			} /* if */
		} /* if */
	
		cout << endl;

		if (TESTON(MsgIetbl[tbl_index].ie_bits, IE_BIT_CALLED_PARTY_ADDR))
		{

			/* Called Party Address */
			//len=3 min
			pRecvCalled_Pa = (SCCP_CalledPartyAddr *)msg->FindIE(SCCP_PRM_CALLED_PARTY_ADDR);
			if (pRecvCalled_Pa != NULL)
			{
				RecvLocal_PC = pRecvCalled_Pa->GetPointCode();		//octet 3 - any
				cout << "Called Party Addr: Point Code <" << (ITS_UINT) RecvLocal_PC << "> ";
				fprintf( fh, "Called Party Addr: Point Code <%06x> ", RecvLocal_PC);

				if (pRecvCalled_Pa->HasSSN())
				{
					RecvLocal_SSN = pRecvCalled_Pa->GetSSN();			//octet 2 - 0000 0001
					iTOa((ITS_OCTET) RecvLocal_SSN, charnum);
					cout << " SSN <" << (char *) charnum << "> ";
					fprintf( fh, "Called Party Addr: Point Code <%02x> ", RecvLocal_SSN);
				} /* if */

				RecvLocal_ByPC_SSN = pRecvCalled_Pa->IsRoutedByPCSSN();			//octet 1 bit 7
				if (RecvLocal_ByPC_SSN)
				{
					cout << " Route By PC SSN ";
					fprintf( fh, " Route By PC SSN ");
				} /* if */

				RecvLocal_InternationalRouting = pRecvCalled_Pa->IsInternationalRouting();  //octet 1 bit 8
				if (RecvLocal_InternationalRouting)
				{
					cout << " International Routing ";
					fprintf( fh, " International Routing ");
				} /* if */
				cout << endl;
				fprintf( fh, "\n");

//				HasGlobalTitle()
			} /* if */
		} /* if */
	
		if (TESTON(MsgIetbl[tbl_index].ie_bits, IE_BIT_CALLING_PARTY_ADDR))
		{
			/* Calling Party Address */
			//len=3 min
			pRecvCalling_Pa = (SCCP_CallingPartyAddr *)msg->FindIE(SCCP_PRM_CALLING_PARTY_ADDR);
			if (pRecvCalling_Pa != NULL)
			{
				RecvRemote_PC = pRecvCalling_Pa->GetPointCode();           //octet 3 - any
				cout << "Calling Party Addr: Point Code <" << (ITS_UINT) RecvRemote_PC << "> ";
				fprintf( fh, "Calling Party Addr: Point Code <%06x> ", RecvRemote_PC);

				if (pRecvCalling_Pa->HasSSN())
				{
					RecvRemote_SSN = pRecvCalling_Pa->GetSSN();                //octet 2 - 0000 0001
					iTOa((ITS_OCTET) RecvRemote_SSN, charnum);
					cout << " SSN <" << (char *) charnum << "> ";
					fprintf( fh, " SSN <%02x> ", RecvRemote_SSN);
				} /* if */

				RecvRemote_ByPC_SSN = pRecvCalling_Pa->IsRoutedByPCSSN();			//octet 1 bit 7
				if (RecvRemote_ByPC_SSN)
				{
					cout << " Route By PC SSN ";
					fprintf( fh, " Route By PC SSN ");
				} /* if */

				RecvRemote_InternationalRouting = pRecvCalling_Pa->IsInternationalRouting();  //octet 1 bit 7
				if (RecvRemote_InternationalRouting)
				{
					cout << " International Routing ";
					fprintf( fh, " International Routing ");
				} /* if */
				cout << endl;
				fprintf( fh, "\n");

//				HasGlobalTitle()
			} /* if */
		} /* if */


		if (TESTON(MsgIetbl[tbl_index].ie_bits, IE_BIT_HOP_COUNTER))
		{
			pRecvHopCount = (SCCP_HopCount *)msg->FindIE(SCCP_PRM_HOP_COUNTER);
			if (pRecvHopCount != NULL)
			{
				if (pRecvHopCount->HasHopCount())
				{
					XRecvHopCount = pRecvHopCount->GetHopCount();
					iTOa((ITS_OCTET) XRecvHopCount, charnum);
					cout << "Hop Count <" << (char *) charnum << "> ";
					fprintf( fh, " Hop Count <%02x> ", XRecvHopCount);
				} /* if */
			} /* if */
		} /* if */

		if (TESTON(MsgIetbl[tbl_index].ie_bits, IE_BIT_CREDIT))
		{
			pRecvCredit = (SCCP_Credit *)msg->FindIE(SCCP_PRM_CREDIT);
			if (pRecvCredit != NULL)
			{
				if (pRecvCredit->HasCredit())
				{
					XRecvCredit = pRecvCredit->GetCredit();
					iTOa((ITS_OCTET) XRecvCredit, charnum);
					cout << "Credit <" << (char *) charnum << "> ";
					fprintf( fh, " Credit <%02x> ", XRecvCredit);
				} /* if */
			} /* if */
		} /* if */


		if (TESTON(MsgIetbl[tbl_index].ie_bits, IE_BIT_SEGMENT_REASSEM))
		{
			pRecvSegmentReassem = (SCCP_SegmentReassem *)msg->FindIE(SCCP_PRM_SEGMENT_REASSEM);
			if (pRecvSegmentReassem != NULL)
			{
				if (pRecvSegmentReassem->HasSegmentReassem())
				{
					XRecvHaveMore = pRecvSegmentReassem->GetSegmentReassem();
					if (XRecvHaveMore)
					{
						cout << "More ";
						fprintf( fh, " More ");
					} /* if */
				} /* if */
			} /* if */
		} /* if */

		if (TESTON(MsgIetbl[tbl_index].ie_bits, IE_BIT_SEQUENCE_SEGMENT))
		{
		    pRecvSequenceSegment = (SCCP_SequenceSegment *)msg->FindIE(SCCP_PRM_SEQUENCE_SEGMENT);
			if (pRecvSequenceSegment != NULL)
			{
				if (pRecvSequenceSegment->HasTransmitSequenceNumber())
				{
					XRecvTransSeqNum = pRecvSequenceSegment->GetTransmitSequenceNumber();
					cout << "TransSeqNum <" << (ITS_OCTET) XRecvTransSeqNum << "> ";
					fprintf( fh, " TransSeqNum <%02x> ", XRecvTransSeqNum);
				} /* if */

				if (pRecvSequenceSegment->HasReceiveSequenceNumber())
				{
					XRecvRecvSeqNum = pRecvSequenceSegment->GetReceiveSequenceNumber();
					cout << "RecvSeqNum <" << (ITS_OCTET) XRecvRecvSeqNum << "> ";
					fprintf( fh, " RecvSeqNum <%02x> ", XRecvRecvSeqNum);
				} /* if */

				if (pRecvSequenceSegment->HasHaveMore())
				{
					XRecvHaveMore = pRecvSequenceSegment->GetHaveMore();
					if (XRecvHaveMore)
					{
						cout << "More ";
					fprintf( fh, " More");
					} /* if */
				} /* if */
			} /* if */
		} /* if */


		if (TESTON(MsgIetbl[tbl_index].ie_bits, IE_BIT_RCV_SEQ_NUM))
		{
			pRecvSeqenceNumber = (SCCP_ReceiveSequenceNum *)msg->FindIE(SCCP_PRM_RCV_SEQ_NUM);
			if (pRecvSeqenceNumber != NULL)
			{
				if (pRecvSeqenceNumber->HasReceiveSequenceNumber())
				{
					XRecvRecvSeqNum = pRecvSeqenceNumber->GetReceiveSequenceNumber();
					cout << "RecvSeqNum <" << (ITS_OCTET) XRecvRecvSeqNum << "> ";
					fprintf( fh, " RecvSeqNum <%02x> ", XRecvRecvSeqNum);
				} /* if */

				if (pRecvSeqenceNumber->HasHaveMore())
				{
					XRecvHaveMore = pRecvSeqenceNumber->GetHaveMore();
					if (XRecvHaveMore)
					{
						cout << "More ";
					fprintf( fh, " More");
					} /* if */
				} /* if */
			} /* if */
		} /* if */

		cout << endl;
		fprintf( fh, "\n");

		if (TESTON(MsgIetbl[tbl_index].ie_bits, IE_BIT_SEGMENTATION))
		{
			/* Not Supported */
		} /* if */
	
		if (TESTON(MsgIetbl[tbl_index].ie_bits, IE_BIT_RELEASE_CAUSE))
		{
			SCCP_Cause *pReleaseCause =
				(SCCP_Cause *)msg->FindIE(SCCP_PRM_RELEASE_CAUSE);
			if (pReleaseCause != NULL)
			{
				if (pReleaseCause->HasCause())
				{
					XRecvReleaseCause = pReleaseCause->GetCause();
					cout << "Release Cause <" << (ITS_UINT) XRecvReleaseCause << "> " << endl;
					fprintf( fh, " Release Cause <%02x> ", XRecvReleaseCause);
				} /* if */
			} /* if */
		} /* if */

		if (TESTON(MsgIetbl[tbl_index].ie_bits, IE_BIT_RESET_CAUSE))
		{
			SCCP_Cause *pResetCause =
				(SCCP_Cause *)msg->FindIE(SCCP_PRM_RESET_CAUSE);
			if (pResetCause != NULL)
			{
				if (pResetCause->HasCause())
				{
					XRecvResetCause = pResetCause->GetCause();
					cout << "Reset Cause <" << (ITS_UINT) XRecvResetCause << "> " << endl;
					fprintf( fh, " Reset Cause <%02x> ", XRecvResetCause);
				} /* if */
			} /* if */
		} /* if */
	
		if (TESTON(MsgIetbl[tbl_index].ie_bits, IE_BIT_ERROR_CAUSE))
		{
			SCCP_Cause *pErrorCause =
				(SCCP_Cause *)msg->FindIE(SCCP_PRM_RESET_CAUSE);
			if (pErrorCause != NULL)
			{
				if (pErrorCause->HasCause())
				{
					XRecvErrorCause = pErrorCause->GetCause();
					cout << "Error Cause <" << (ITS_UINT) XRecvErrorCause << "> " << endl;
					fprintf( fh, " Error Cause <%02x> ", XRecvErrorCause);
				} /* if */
			} /* if */
		} /* if */

		if (TESTON(MsgIetbl[tbl_index].ie_bits, IE_BIT_RETURN_CAUSE))
		{
			SCCP_Cause *pReturnCause =
				(SCCP_Cause *)msg->FindIE(SCCP_PRM_RETURN_CAUSE);
			if (pReturnCause != NULL)
			{
				if (pReturnCause->HasCause())
				{
					XRecvReturnCause = pReturnCause->GetCause();
					cout << "Return Cause <" << (ITS_UINT) XRecvReturnCause << "> " << endl;
					fprintf( fh, " Return Cause <%02x> ", XRecvReturnCause);
				} /* if */
			} /* if */
		} /* if */

		if (TESTON(MsgIetbl[tbl_index].ie_bits, IE_BIT_REFUSAL_CAUSE))
		{
			SCCP_Cause *pRefusalCause =
				(SCCP_Cause *)msg->FindIE(SCCP_PRM_REFUSAL_CAUSE);
			if (pRefusalCause != NULL)
			{
				if (pRefusalCause->HasCause())
				{
					XRecvRefusalCause = pRefusalCause->GetCause();
					cout << "Refusal Cause <" << (ITS_UINT) XRecvRefusalCause << "> " << endl;
					fprintf( fh, " Refusal Cause <%02x> ", XRecvRefusalCause);
				} /* if */
			} /* if */
		} /* if */


		if (TESTON(MsgIetbl[tbl_index].ie_bits, IE_BIT_DATA))
		{

			pRecvUserData = (SCCP_UserData *)msg->FindIE(SCCP_PRM_DATA);

			if (pRecvUserData != NULL)
			{
				pRecvUserData->GetUserData(pRecvDataBuf, XRecvDataLen);

				if (XRecvDataLen > 0)
				{
					cout << "Data Length <" << (ITS_INT) XRecvDataLen << "> Data: " << endl;
					fprintf( fh, " Data Length <%08x> \n User Data:<", XRecvDataLen);
					for(i=0; i < XRecvDataLen; i++)
					{
						printf("%02x ", XRecvDataBuf[i]);
						fprintf( fh, "%02x ", XRecvDataBuf[i]);
					} /* if */
					printf("\n");
					fprintf( fh, ">\n");
				} /* if -- data length gt 0 */
			} /* if -- have User Data*/
		} /* if -- msg type can have data field */

		fflush( fh );
		if (pFN != 0)
		{
		// Call Appropriate function for message received
			ret = (*pFN)(instance, handle);
		} /* if */

		if ((TESTON(pgmCntl, AUTO_RESOPNDED)) & (TESTON(pgmCntl, RECEIVER_MODE)))
		{
			cont = true;
		} /* if */
		else
		{
			cont = false;
		} /* else */

		cout << "Press Enter To Continue ";
		cin >> x;
	} /* while */

		SETOFF(pgmCntl, AUTO_RESOPNDED);


		return ret;
    
} /* WaitToReceive */

int
RecvCR(ITS_USHORT instance, ITS_HANDLE handle)
{
	ITS_INT ret = 0;
	DestRef = XRecvSlr;
//	ret = SCCP_GetNextLocalRef(&srchdr.context.conref);
	srchdr.context.conref = sccpReceivedHdr.context.conref;
	LocalRef = srchdr.context.conref;

	ROUTE_AddApplication(instance, &srchdr);

	SETON(ssnState, ACTIVE_CONNECTION);
	SETON(pendingSendState, CC_PENDING);

	if (TESTON(pgmCntl, AUTO_RESP))
	{
		cout << "Auto Responding with CC" << endl;
		ret = SendCC(instance, handle);
		SETON(pgmCntl, AUTO_RESOPNDED);
		return (ret);
	} /* if */

	return (ITS_SUCCESS);
} /*  */
int
RecvCC(ITS_USHORT instance, ITS_HANDLE handle)
{
	DestRef = XRecvSlr;
	SETOFF(pendingRecvState, CC_PENDING);
	return (ITS_SUCCESS);
} /*  */ 
int
RecvCREF(ITS_USHORT instance, ITS_HANDLE handle)
{
	LocalRef = 0;
	DestRef = 0;
	SETOFF(pendingRecvState, CC_PENDING);
	ROUTE_DeleteApplication(instance, &srchdr);
	return (ITS_SUCCESS);
} /*  */ 
int
RecvRLSD(ITS_USHORT instance, ITS_HANDLE handle)
{
	ITS_INT ret = 0;
	SETON(pendingSendState, RLC_PENDING);

	if (TESTON(pgmCntl, AUTO_RESP))
	{
		cout << "Auto Responding with RLC" << endl;
		ret = SendRLC(instance, handle);
		SETON(pgmCntl, AUTO_RESOPNDED);
		return (ret);
	} /* if */
	return (ITS_SUCCESS);
} /*  */ 
int
RecvRLC(ITS_USHORT instance, ITS_HANDLE handle)
{
	LocalRef = 0;
	DestRef = 0;
	SETOFF(pendingRecvState, RLC_PENDING);
	ROUTE_DeleteApplication(instance, &srchdr);
	return (ITS_SUCCESS);
} /*  */ 
int
RecvDT1(ITS_USHORT instance, ITS_HANDLE handle)
{
	return (ITS_SUCCESS);
} /*  */ 
int
RecvDT2(ITS_USHORT instance, ITS_HANDLE handle)
{
	ITS_INT ret = 0;
	SETON(pendingSendState, AK_PENDING);

	if (TESTON(pgmCntl, AUTO_RESP))
	{
		cout << "Auto Responding with AK" << endl;
		ret = SendAK(instance, handle);
		SETON(pgmCntl, AUTO_RESOPNDED);
		return (ret);
	} /* if */
	return (ITS_SUCCESS);
} /*  */ 
int
RecvAK(ITS_USHORT instance, ITS_HANDLE handle)
{
	SETOFF(pendingRecvState, AK_PENDING);
	return (ITS_SUCCESS);
} /*  */ 
int
RecvED(ITS_USHORT instance, ITS_HANDLE handle)
{
	ITS_INT ret = 0;
	SETON(pendingSendState, EA_PENDING);

	if (TESTON(pgmCntl, AUTO_RESP))
	{
		cout << "Auto Responding with EA" << endl;
		ret = SendEA(instance, handle);
		SETON(pgmCntl, AUTO_RESOPNDED);
		return (ret);
	} /* if */
	return (ITS_SUCCESS);
} /*  */ 
int
RecvEA(ITS_USHORT instance, ITS_HANDLE handle)
{
	SETOFF(pendingRecvState, EA_PENDING);
	return (ITS_SUCCESS);
} /*  */ 
int
RecvRSR(ITS_USHORT instance, ITS_HANDLE handle)
{
	ITS_INT ret = 0;
	SETON(pendingSendState, RSC_PENDING);

	if (TESTON(pgmCntl, AUTO_RESP))
	{
		cout << "Auto Responding with RSC" << endl;
		ret = SendRSC(instance, handle);
		SETON(pgmCntl, AUTO_RESOPNDED);
		return (ret);
	} /* if */
	return (ITS_SUCCESS);
} /*  */ 

int
RecvRSC(ITS_USHORT instance, ITS_HANDLE handle)
{
	SETOFF(pendingRecvState, RSC_PENDING);
	return (ITS_SUCCESS);
} /*  */ 

int
RecvERR(ITS_USHORT instance, ITS_HANDLE handle)
{
//	LocalRef = 0;
//	DestRef = 0;
	return (ITS_SUCCESS);
} /*  */ 
int
RecvIT(ITS_USHORT instance, ITS_HANDLE handle)
{
	return (ITS_SUCCESS);
} /*  */ 
int
RecvUDT(ITS_USHORT instance, ITS_HANDLE handle)
{
	return (ITS_SUCCESS);
} /*  */ 
int
RecvUDTS(ITS_USHORT instance, ITS_HANDLE handle)
{
	return (ITS_SUCCESS);
} /*  */ 
int
RecvXUDT(ITS_USHORT instance, ITS_HANDLE handle)
{
	return (ITS_SUCCESS);
} /*  */ 
int
RecvXUDTS(ITS_USHORT instance, ITS_HANDLE handle)
{
	return (ITS_SUCCESS);
} /*  */


void
saveCrash()
{
	FILE *pfile;
	int numbytes;
	char x;

	saveData.ssnState = ssnState;
	saveData.pendingRecvState = pendingRecvState;
	saveData.pendingSendState = pendingSendState;
	saveData.pgmCntl = pgmCntl;
	saveData.local_pc = local_pc;
	saveData.remote_pc = remote_pc;
	saveData.local_ssn = local_ssn;
	saveData.remote_ssn = remote_ssn;
	saveData.ssnCongestion = ssnCongestion;
	saveData.theClass = theClass;
	saveData.sendSequenceNumber = sendSequenceNumber; 
	saveData.receiveSequenceNumber = receiveSequenceNumber;
	saveData.XRecvSlr = XRecvSlr;
	saveData.XRecvDlr = XRecvDlr; 
	saveData.LocalRef = LocalRef;
	saveData.DestRef = DestRef;
	saveData.RecvProtocolClass = RecvProtocolClass;	
	saveData.RecvLocal_PC = RecvLocal_PC;
	saveData.RecvLocal_SSN = RecvLocal_SSN;
	saveData.RecvRemote_PC = RecvRemote_PC;
	saveData.RecvRemote_SSN = RecvRemote_SSN;
	saveData.XRecvHopCount = XRecvHopCount;
	saveData.XRecvCredit = XRecvCredit;
	saveData.XRecvHaveMore = XRecvHaveMore;
	saveData.XRecvTransSeqNum = XRecvTransSeqNum;
	saveData.XRecvRecvSeqNum = XRecvRecvSeqNum;
	saveData.XRecvReleaseCause = XRecvReleaseCause;
	saveData.XRecvResetCause = XRecvResetCause;
	saveData.XRecvErrorCause = XRecvErrorCause;
	saveData.XRecvReturnCause = XRecvReturnCause;
	saveData.XRecvRefusalCause = XRecvRefusalCause;
	saveData.XRecvDataLen = XRecvDataLen;
	
	saveData.RecvLocal_ByPC_SSN = RecvLocal_ByPC_SSN;
	saveData.RecvLocal_InternationalRouting = RecvLocal_InternationalRouting;
	saveData.RecvRemote_ByPC_SSN = RecvRemote_ByPC_SSN;
	saveData.RecvRemote_InternationalRouting = RecvRemote_InternationalRouting;

	memcpy(&saveData.sccpReceivedHdr, &sccpReceivedHdr, sizeof(sccpReceivedHdr));
	memcpy(&saveData.srchdr, &srchdr, sizeof(srchdr));
	memcpy(&saveData.remhdr, &remhdr, sizeof(remhdr));
	memcpy(&saveData.XRecvDataBuf[0], &XRecvDataBuf[0], sizeof(XRecvDataBuf));

   /* Open for write */
   if( (pfile = fopen( "saveCrash", "w+" )) == NULL )
   {
	   cout << "The file 'saveCrash' was not opened - Press Enter\n" << endl;
	   cin >> x;
	   return;
   } /* if */
   else
   {
	   cout << "The file 'saveCrash' was opened\n" << endl;
   } /* else */

   numbytes = fwrite(&saveData,sizeof(saveData),1,pfile);

   cout << "Bytes Written to saveCrash File: " << (int) numbytes << endl;
   fclose(pfile);

   return;
} /* saveCrash */

void
recoverCrash()
{
	FILE *pfile;
	int numbytes;
	char x;
   /* Open for write */
   if( (pfile = fopen( "saveCrash", "r" )) == NULL )
   {
	   cout << "The file 'saveCrash' was not opened - Press Enter\n" << endl;
	   cin >> x;
	   return;
   } /* if */
   else
   {
	   cout << "The file 'saveCrash' was opened\n" << endl;
   } /* else */

   numbytes = fread(&saveData, sizeof(saveData), 1, pfile);

   cout << "Bytes Read from saveCrash File: " << (int) numbytes << endl;
   fclose(pfile);

	ssnState = saveData.ssnState;
	pendingRecvState = saveData.pendingRecvState;

	pendingSendState = saveData.pendingSendState;
	pgmCntl = saveData.pgmCntl;
	local_pc = saveData.local_pc;
	remote_pc = saveData.remote_pc;
	local_ssn = saveData.local_ssn;
	remote_ssn = saveData.remote_ssn;
	ssnCongestion = saveData.ssnCongestion;
	theClass = saveData.theClass;
	sendSequenceNumber = saveData.sendSequenceNumber; 
	receiveSequenceNumber = saveData.receiveSequenceNumber;
	XRecvSlr = saveData.XRecvSlr;
	XRecvDlr = saveData.XRecvDlr; 
	LocalRef = saveData.LocalRef;
	DestRef = saveData.DestRef;
	RecvProtocolClass = saveData.RecvProtocolClass;	
	RecvLocal_PC = saveData.RecvLocal_PC;
	RecvLocal_SSN = saveData.RecvLocal_SSN;
	RecvRemote_PC = saveData.RecvRemote_PC;
	RecvRemote_SSN = saveData.RecvRemote_SSN;
	XRecvHopCount = saveData.XRecvHopCount;
	XRecvCredit = saveData.XRecvCredit;
	XRecvHaveMore = saveData.XRecvHaveMore;
	XRecvTransSeqNum = saveData.XRecvTransSeqNum;
	XRecvRecvSeqNum = saveData.XRecvRecvSeqNum;
	XRecvReleaseCause = saveData.XRecvReleaseCause;
	XRecvResetCause = saveData.XRecvResetCause;
	XRecvErrorCause = saveData.XRecvErrorCause;
	XRecvReturnCause = saveData.XRecvReturnCause;
	XRecvRefusalCause = saveData.XRecvRefusalCause;
	XRecvDataLen = saveData.XRecvDataLen;
	
	RecvLocal_ByPC_SSN = saveData.RecvLocal_ByPC_SSN;
	RecvLocal_InternationalRouting = saveData.RecvLocal_InternationalRouting;
	RecvRemote_ByPC_SSN = saveData.RecvRemote_ByPC_SSN;
	RecvRemote_InternationalRouting = saveData.RecvRemote_InternationalRouting;

	memcpy(&sccpReceivedHdr, &saveData.sccpReceivedHdr, sizeof(sccpReceivedHdr));
	memcpy(&srchdr, &saveData.srchdr, sizeof(srchdr));
	memcpy(&remhdr, &saveData.remhdr, sizeof(remhdr));
	memcpy(&XRecvDataBuf[0], &saveData.XRecvDataBuf[0], sizeof(XRecvDataBuf));

	return;

} /* recoverCrash */





void
iTOa(int n, char s[])
{
	int i, sign;

	if ((sign = n) < 0)	/* record sign */
	{
		n = -n;			/* Make Positive */
	} /* if */
	i = 0;
	do 
	{				/* generate digits in reverse order */
		s[i++] = n % 10 + '0';	/* get next digit */
	}
	while ((n /= 10) > 0);	/* delete it */
	if (sign < 0)
	{
		s[i++] = '-';
	} /* if */
	s[i] = '\0';
	reverseString(s);
} /* iTOa */

void
reverseString(char s[])
{
	int c, i, j;
	for (i = 0, j = strLen(s) -1; i < j; i++, j--)
	{
		c = s[i];
		s[i] = s[j];
		s[j] = c;
	} /* for */
} /* reverseString */

int
strLen(char s[])
{
	int i = 0;

	while (s[i] != '\0')
	{
		++i;
	} /* while */

	return(i);
} /* strLen */

#ifdef PEGDSMPR5
#ifdef CCITT
	ITS_UINT tableId = DSM_TABLE_ITU_SCCP_CTXT;
#endif
#ifdef ANSI
	ITS_UINT tableId = DSM_TABLE_ANSI_SCCP_CTXT;
#endif


void
testdsm()
{
    SCCP_CONN_CTXT *pFoundCtxt = NULL, *pNewCtxt = NULL;
	ITS_INT error;
	ITS_UINT size = sizeof(SCCP_CONN_CTXT);
    ITS_USHORT nextUnique = 5410;
	char x;

	pNewCtxt = (SCCP_CONN_CTXT *) DSM_Alloc(tableId, 
										(ITS_OCTET *)&nextUnique, 
										sizeof(nextUnique), size, &error);
	if (error != ITS_SUCCESS)
	{
		switch(error)
		{
			case (ITS_EBADMUTEX):
			        printf("Couldn't acquire mutex.\n");
				return;
				break;
			case (ITS_ENOMEM):
				printf("No Memory.\n");
				return;
				break;
			default:
				printf("Unknown Error <%d> \n", error);
				return;
				break;
		} /* switch */
	} /* if - error */


	pNewCtxt->connRef = nextUnique;
	pNewCtxt->sequenceSLS = 10;
	pNewCtxt->slref = nextUnique;
	pNewCtxt->dlref = 0;

	pNewCtxt->state = SCCP_DATA_TRANSFER;
	pNewCtxt->dataState = SCCP_DATA_BOTH_ED;
	pNewCtxt->connectTimer = 33;
	pNewCtxt->releaseTimer = 99;
	pNewCtxt->sequenceOn = ITS_FALSE;
	pNewCtxt->pclass = 2;
	pNewCtxt->sequenceOn = ITS_TRUE;
	pNewCtxt->isIntermediate = ITS_FALSE;

	error = DSM_Commit(tableId, (ITS_OCTET *)&nextUnique, 
						sizeof(nextUnique), pNewCtxt);
	if (error != ITS_SUCCESS)
	{
		printf("Couldn't add context.\n");
        return;
	} /* if */


	pFoundCtxt = (SCCP_CONN_CTXT *) DSM_Find(tableId, 
										(ITS_OCTET *)&nextUnique, 
										sizeof(nextUnique), &error);

	if (error != ITS_SUCCESS)
	{
		switch(error)
		{
			case (ITS_ENOTFOUND):
				printf("Could not find context.\n");
				break;
			case (ITS_EBADMUTEX):
		        printf("Couldn't acquire mutex.\n");
				return;
				break;
			case (ITS_EINUSE):
				printf("DSM Row Locked.\n");
				return;
				break;
			default:
				printf("Unknown Error <%d> \n", error);
				return;
				break;
		} /* switch */

	} /* if - error */

	printContext(pFoundCtxt);

	cout << endl << "Press Enter to Continue & Free It: " << endl;
	cin >> x;

	error = DSM_Free(tableId, (ITS_OCTET *)&nextUnique, 
						sizeof(nextUnique), pNewCtxt);

	if (error != ITS_SUCCESS)
	{
		printf("DSM unable to free Reference.\n");
	} /* if */

	return;


} /* testdsm */

void
searchContext()
{
    SCCP_CONN_CTXT *pFoundCtxt;
	ITS_INT error;
    ITS_USHORT nextUnique;
	char x; 
	unsigned short z;

	cout << "Enter start of Search: ";
	cin >> z;

    for (nextUnique = z; nextUnique < 65536; nextUnique++ )
    {
		pFoundCtxt = (SCCP_CONN_CTXT *) DSM_Find(tableId, 
												(ITS_OCTET *)&nextUnique, 
												sizeof(nextUnique), &error);

		if (error != ITS_SUCCESS)
		{

			switch(error)
			{
				case (ITS_ENOTFOUND):
					printf("Could not find context.\n");
					break;
				case (ITS_EBADMUTEX):
			        printf("Couldn't acquire mutex.\n");
					return;
					break;
				case (ITS_EINUSE):
					printf("DSM Row Locked.\n");
					return;
					break;
				default:
					printf("Unknown Error <%d> \n", error);
					break;
			} /* switch */

		} /* if - error */
		else
		{
			printContext(pFoundCtxt);
			cout << endl << "Press Enter to Continue & Commit It: " << endl;
			cin >> x;

			// Release the lock on row
			error = DSM_Commit(tableId, (ITS_OCTET *)&nextUnique, 
								sizeof(nextUnique), pFoundCtxt);
			pFoundCtxt = NULL;	// Not safe to use with out lock
	
			if (error != ITS_SUCCESS)
			{
				printf("DSM unable to free Reference.\n");
			} /* if */

		} /* else */

		cout << "Go To Next (Y/N): " << endl;
		cin >> x;
		x = tolower(x);
		if (x == 'n' || x == 'N')
		{
			return;
		} /* if */

	} /* for */

} /* searchContext */

void
printContext(SCCP_CONN_CTXT *pFoundCtxt)
{
	printf("connRef <%d> sequenceSLS <%d> slref <%d> dlref <%d> \n",
		pFoundCtxt->connRef,
		pFoundCtxt->sequenceSLS,
		pFoundCtxt->slref,
		pFoundCtxt->dlref);

    switch(pFoundCtxt->state)
	{
		case SCCP_CONN_IDLE:
			printf ("state = SCCP_CONN_IDLE  ");
			break;
		case SCCP_CONN_IN_PEND:
			printf ("state = SCCP_CONN_IN_PEND  ");
			break;
		case SCCP_CONN_OUT_PEND:
			printf ("state = SCCP_CONN_OUT_PEND  ");
			break;
		case SCCP_DATA_TRANSFER:
			printf ("state = SCCP_DATA_TRANSFER  ");
			break;
		case SCCP_IN_RESET_PEND:
			printf ("state = SCCP_IN_RESET_PEND  ");
			break;
		case SCCP_OUT_RESET_PEND:
			printf ("state = SCCP_OUT_RESET_PEND  ");
			break;
		case SCCP_IN_RELEASE_PEND:
			printf ("state = SCCP_IN_RELEASE_PEND  ");
			break;
		case SCCP_OUT_RELEASE_PEND:
			printf ("state = SCCP_OUT_RELEASE_PEND   ");
			break;
		default:
			printf ("state = Unknown  " );
			break;
	} /* switch */


    switch (pFoundCtxt->dataState)
	{
		case SCCP_DATA_NORMAL:
			printf ("dataState = SCCP_DATA_NORMAL \n");
			break;
		case SCCP_DATA_IN_ED:
			printf ("dataState = SCCP_DATA_IN_ED \n");
			break;
		case SCCP_DATA_OUT_ED:
			printf ("dataState = SCCP_DATA_OUT_ED \n");
			break;
		case SCCP_DATA_BOTH_ED:
			printf ("dataState = SCCP_DATA_BOTH_ED \n");
			break;
		default:
			printf ("dataState = Unknown\n");
			break;
	} /* switch */

	printf ("connectTimer <%d> releaseTimer <%d> resetTimer <>%d> pclass <%d>\n",
			pFoundCtxt->connectTimer,
			pFoundCtxt->releaseTimer,
			pFoundCtxt->sequenceOn,
			pFoundCtxt->pclass);

	if (pFoundCtxt->sequenceOn == ITS_FALSE)
	{
		printf ("sequenceOn = ITS_FALSE  ");
	} /* if */
	else
	{
		printf ("sequenceOn = ITS_TRUE  ");
	} /* else */

	if (pFoundCtxt->isIntermediate == ITS_FALSE)
	{
		printf ("isIntermediate = ITS_FALSE  \n");
	} /* if */
	else
	{
		printf ("isIntermediate = ITS_TRUE  \n");
	} /* else */

/*
    ITS_MUTEX       lock;
    MTP3_HEADER     inLabel;
    MTP3_HEADER     outLabel;
    ITS_USHORT      assocRef;
    ITS_SERIAL      sendInactivity;
    ITS_SERIAL      receiveInactivity;
    SCCP_DATA_FRAG* fragList;
    SCCP_ADDR       oaddr;
    SCCP_ADDR       daddr;
    ITS_OCTET       windowSize;
    ITS_OCTET       fsn;
    ITS_OCTET       rsn;
*/


} /* printContext */

#endif