#if !defined(BIT_H)

#define BIT_H 1

#define b00000000	(unsigned char) 0x00
#define b00000001	(unsigned char) 0x01
#define b00000010	(unsigned char) 0x02
#define b00000011	(unsigned char) 0x03
#define b00000100	(unsigned char) 0x04
#define b00000101	(unsigned char) 0x05
#define b00000110	(unsigned char) 0x06
#define b00000111	(unsigned char) 0x07
#define b00001000	(unsigned char) 0x08
#define b00001001	(unsigned char) 0x09
#define b00001010	(unsigned char) 0x0A
#define b00001011	(unsigned char) 0x0B
#define b00001100	(unsigned char) 0x0C
#define b00001101	(unsigned char) 0x0D
#define b00001110	(unsigned char) 0x0E
#define b00001111	(unsigned char) 0x0F

#define b00010000	(unsigned char) 0x10
#define b00010001	(unsigned char) 0x11
#define b00010010	(unsigned char) 0x12
#define b00010011	(unsigned char) 0x13
#define b00010100	(unsigned char) 0x14
#define b00010101	(unsigned char) 0x15
#define b00010110	(unsigned char) 0x16
#define b00010111	(unsigned char) 0x17
#define b00011000	(unsigned char) 0x18
#define b00011001	(unsigned char) 0x19
#define b00011010	(unsigned char) 0x1A
#define b00011011	(unsigned char) 0x1B
#define b00011100	(unsigned char) 0x1C
#define b00011101	(unsigned char) 0x1D
#define b00011110	(unsigned char) 0x1E
#define b00011111	(unsigned char) 0x1F

#define b00100000	(unsigned char) 0x20
#define b00100001	(unsigned char) 0x21
#define b00100010	(unsigned char) 0x22
#define b00100011	(unsigned char) 0x23
#define b00100100	(unsigned char) 0x24
#define b00100101	(unsigned char) 0x25
#define b00100110	(unsigned char) 0x26
#define b00100111	(unsigned char) 0x27
#define b00101000	(unsigned char) 0x28
#define b00101001	(unsigned char) 0x29
#define b00101010	(unsigned char) 0x2A
#define b00101011	(unsigned char) 0x2B
#define b00101100	(unsigned char) 0x2C
#define b00101101	(unsigned char) 0x2D
#define b00101110	(unsigned char) 0x2E
#define b00101111	(unsigned char) 0x2F

#define b00110000	(unsigned char) 0x30
#define b00110001	(unsigned char) 0x31
#define b00110010	(unsigned char) 0x32
#define b00110011	(unsigned char) 0x33
#define b00110100	(unsigned char) 0x34
#define b00110101	(unsigned char) 0x35
#define b00110110	(unsigned char) 0x36
#define b00110111	(unsigned char) 0x37
#define b00111000	(unsigned char) 0x38
#define b00111001	(unsigned char) 0x39
#define b00111010	(unsigned char) 0x3A
#define b00111011	(unsigned char) 0x3B
#define b00111100	(unsigned char) 0x3C
#define b00111101	(unsigned char) 0x3D
#define b00111110	(unsigned char) 0x3E
#define b00111111	(unsigned char) 0x3F

#define b01000000	(unsigned char) 0x40
#define b01000001	(unsigned char) 0x41
#define b01000010	(unsigned char) 0x42
#define b01000011	(unsigned char) 0x43
#define b01000100	(unsigned char) 0x44
#define b01000101	(unsigned char) 0x45
#define b01000110	(unsigned char) 0x46
#define b01000111	(unsigned char) 0x47
#define b01001000	(unsigned char) 0x48
#define b01001001	(unsigned char) 0x49
#define b01001010	(unsigned char) 0x4A
#define b01001011	(unsigned char) 0x4B
#define b01001100	(unsigned char) 0x4C
#define b01001101	(unsigned char) 0x4D
#define b01001110	(unsigned char) 0x4E
#define b01001111	(unsigned char) 0x4F

#define b01010000	(unsigned char) 0x50
#define b01010001	(unsigned char) 0x51
#define b01010010	(unsigned char) 0x52
#define b01010011	(unsigned char) 0x53
#define b01010100	(unsigned char) 0x54
#define b01010101	(unsigned char) 0x55
#define b01010110	(unsigned char) 0x56
#define b01010111	(unsigned char) 0x57
#define b01011000	(unsigned char) 0x58
#define b01011001	(unsigned char) 0x59
#define b01011010	(unsigned char) 0x5A
#define b01011011	(unsigned char) 0x5B
#define b01011100	(unsigned char) 0x5C
#define b01011101	(unsigned char) 0x5D
#define b01011110	(unsigned char) 0x5E
#define b01011111	(unsigned char) 0x5F

#define b01100000	(unsigned char) 0x60
#define b01100001	(unsigned char) 0x61
#define b01100010	(unsigned char) 0x62
#define b01100011	(unsigned char) 0x63
#define b01100100	(unsigned char) 0x64
#define b01100101	(unsigned char) 0x65
#define b01100110	(unsigned char) 0x66
#define b01100111	(unsigned char) 0x67
#define b01101000	(unsigned char) 0x68
#define b01101001	(unsigned char) 0x69
#define b01101010	(unsigned char) 0x6A
#define b01101011	(unsigned char) 0x6B
#define b01101100	(unsigned char) 0x6C
#define b01101101	(unsigned char) 0x6D
#define b01101110	(unsigned char) 0x6E
#define b01101111	(unsigned char) 0x6F

#define b01110000	(unsigned char) 0x70
#define b01110001	(unsigned char) 0x71
#define b01110010	(unsigned char) 0x72
#define b01110011	(unsigned char) 0x73
#define b01110100	(unsigned char) 0x74
#define b01110101	(unsigned char) 0x75
#define b01110110	(unsigned char) 0x76
#define b01110111	(unsigned char) 0x77
#define b01111000	(unsigned char) 0x78
#define b01111001	(unsigned char) 0x79
#define b01111010	(unsigned char) 0x7A
#define b01111011	(unsigned char) 0x7B
#define b01111100	(unsigned char) 0x7C
#define b01111101	(unsigned char) 0x7D
#define b01111110	(unsigned char) 0x7E
#define b01111111	(unsigned char) 0x7F


#define b10000000	(unsigned char) 0x80
#define b10000001	(unsigned char) 0x81
#define b10000010	(unsigned char) 0x82
#define b10000011	(unsigned char) 0x83
#define b10000100	(unsigned char) 0x84
#define b10000101	(unsigned char) 0x85
#define b10000110	(unsigned char) 0x86
#define b10000111	(unsigned char) 0x87
#define b10001000	(unsigned char) 0x88
#define b10001001	(unsigned char) 0x89
#define b10001010	(unsigned char) 0x8A
#define b10001011	(unsigned char) 0x8B
#define b10001100	(unsigned char) 0x8C
#define b10001101	(unsigned char) 0x8D
#define b10001110	(unsigned char) 0x8E
#define b10001111	(unsigned char) 0x8F

#define b10010000	(unsigned char) 0x90
#define b10010001	(unsigned char) 0x91
#define b10010010	(unsigned char) 0x92
#define b10010011	(unsigned char) 0x93
#define b10010100	(unsigned char) 0x94
#define b10010101	(unsigned char) 0x95
#define b10010110	(unsigned char) 0x96
#define b10010111	(unsigned char) 0x97
#define b10011000	(unsigned char) 0x98
#define b10011001	(unsigned char) 0x99
#define b10011010	(unsigned char) 0x9A
#define b10011011	(unsigned char) 0x9B
#define b10011100	(unsigned char) 0x9C
#define b10011101	(unsigned char) 0x9D
#define b10011110	(unsigned char) 0x9E
#define b10011111	(unsigned char) 0x9F

#define b10100000	(unsigned char) 0xA0
#define b10100001	(unsigned char) 0xA1
#define b10100010	(unsigned char) 0xA2
#define b10100011	(unsigned char) 0xA3
#define b10100100	(unsigned char) 0xA4
#define b10100101	(unsigned char) 0xA5
#define b10100110	(unsigned char) 0xA6
#define b10100111	(unsigned char) 0xA7
#define b10101000	(unsigned char) 0xA8
#define b10101001	(unsigned char) 0xA9
#define b10101010	(unsigned char) 0xAA
#define b10101011	(unsigned char) 0xAB
#define b10101100	(unsigned char) 0xAC
#define b10101101	(unsigned char) 0xAD
#define b10101110	(unsigned char) 0xAE
#define b10101111	(unsigned char) 0xAF

#define b10110000	(unsigned char) 0xB0
#define b10110001	(unsigned char) 0xB1
#define b10110010	(unsigned char) 0xB2
#define b10110011	(unsigned char) 0xB3
#define b10110100	(unsigned char) 0xB4
#define b10110101	(unsigned char) 0xB5
#define b10110110	(unsigned char) 0xB6
#define b10110111	(unsigned char) 0xB7
#define b10111000	(unsigned char) 0xB8
#define b10111001	(unsigned char) 0xB9
#define b10111010	(unsigned char) 0xBA
#define b10111011	(unsigned char) 0xBB
#define b10111100	(unsigned char) 0xBC
#define b10111101	(unsigned char) 0xBD
#define b10111110	(unsigned char) 0xBE
#define b10111111	(unsigned char) 0xBF

#define b11000000	(unsigned char) 0xC0
#define b11000001	(unsigned char) 0xC1
#define b11000010	(unsigned char) 0xC2
#define b11000011	(unsigned char) 0xC3
#define b11000100	(unsigned char) 0xC4
#define b11000101	(unsigned char) 0xC5
#define b11000110	(unsigned char) 0xC6
#define b11000111	(unsigned char) 0xC7
#define b11001000	(unsigned char) 0xC8
#define b11001001	(unsigned char) 0xC9
#define b11001010	(unsigned char) 0xCA
#define b11001011	(unsigned char) 0xCB
#define b11001100	(unsigned char) 0xCC
#define b11001101	(unsigned char) 0xCD
#define b11001110	(unsigned char) 0xCE
#define b11001111	(unsigned char) 0xCF

#define b11010000	(unsigned char) 0xD0
#define b11010001	(unsigned char) 0xD1
#define b11010010	(unsigned char) 0xD2
#define b11010011	(unsigned char) 0xD3
#define b11010100	(unsigned char) 0xD4
#define b11010101	(unsigned char) 0xD5
#define b11010110	(unsigned char) 0xD6
#define b11010111	(unsigned char) 0xD7
#define b11011000	(unsigned char) 0xD8
#define b11011001	(unsigned char) 0xD9
#define b11011010	(unsigned char) 0xDA
#define b11011011	(unsigned char) 0xDB
#define b11011100	(unsigned char) 0xDC
#define b11011101	(unsigned char) 0xDD
#define b11011110	(unsigned char) 0xDE
#define b11011111	(unsigned char) 0xDF

#define b11100000	(unsigned char) 0xE0
#define b11100001	(unsigned char) 0xE1
#define b11100010	(unsigned char) 0xE2
#define b11100011	(unsigned char) 0xE3
#define b11100100	(unsigned char) 0xE4
#define b11100101	(unsigned char) 0xE5
#define b11100110	(unsigned char) 0xE6
#define b11100111	(unsigned char) 0xE7
#define b11101000	(unsigned char) 0xE8
#define b11101001	(unsigned char) 0xE9
#define b11101010	(unsigned char) 0xEA
#define b11101011	(unsigned char) 0xEB
#define b11101100	(unsigned char) 0xEC
#define b11101101	(unsigned char) 0xED
#define b11101110	(unsigned char) 0xEE
#define b11101111	(unsigned char) 0xEF

#define b11110000	(unsigned char) 0xF0
#define b11110001	(unsigned char) 0xF1
#define b11110010	(unsigned char) 0xF2
#define b11110011	(unsigned char) 0xF3
#define b11110100	(unsigned char) 0xF4
#define b11110101	(unsigned char) 0xF5
#define b11110110	(unsigned char) 0xF6
#define b11110111	(unsigned char) 0xF7
#define b11111000	(unsigned char) 0xF8
#define b11111001	(unsigned char) 0xF9
#define b11111010	(unsigned char) 0xFA
#define b11111011	(unsigned char) 0xFB
#define b11111100	(unsigned char) 0xFC
#define b11111101	(unsigned char) 0xFD
#define b11111110	(unsigned char) 0xFE
#define b11111111	(unsigned char) 0xFF

#define B0b00000000	(unsigned int) 0x00
#define B0b00000001	(unsigned int) 0x01
#define B0b00000010	(unsigned int) 0x02
#define B0b00000011	(unsigned int) 0x03
#define B0b00000100	(unsigned int) 0x04
#define B0b00000101	(unsigned int) 0x05
#define B0b00000110	(unsigned int) 0x06
#define B0b00000111	(unsigned int) 0x07
#define B0b00001000	(unsigned int) 0x08
#define B0b00001001	(unsigned int) 0x09
#define B0b00001010	(unsigned int) 0x0A
#define B0b00001011	(unsigned int) 0x0B
#define B0b00001100	(unsigned int) 0x0C
#define B0b00001101	(unsigned int) 0x0D
#define B0b00001110	(unsigned int) 0x0E
#define B0b00001111	(unsigned int) 0x0F

#define B0b00010000	(unsigned int) 0x10
#define B0b00010001	(unsigned int) 0x11
#define B0b00010010	(unsigned int) 0x12
#define B0b00010011	(unsigned int) 0x13
#define B0b00010100	(unsigned int) 0x14
#define B0b00010101	(unsigned int) 0x15
#define B0b00010110	(unsigned int) 0x16
#define B0b00010111	(unsigned int) 0x17
#define B0b00011000	(unsigned int) 0x18
#define B0b00011001	(unsigned int) 0x19
#define B0b00011010	(unsigned int) 0x1A
#define B0b00011011	(unsigned int) 0x1B
#define B0b00011100	(unsigned int) 0x1C
#define B0b00011101	(unsigned int) 0x1D
#define B0b00011110	(unsigned int) 0x1E
#define B0b00011111	(unsigned int) 0x1F

#define B0b00100000	(unsigned int) 0x20
#define B0b00100001	(unsigned int) 0x21
#define B0b00100010	(unsigned int) 0x22
#define B0b00100011	(unsigned int) 0x23
#define B0b00100100	(unsigned int) 0x24
#define B0b00100101	(unsigned int) 0x25
#define B0b00100110	(unsigned int) 0x26
#define B0b00100111	(unsigned int) 0x27
#define B0b00101000	(unsigned int) 0x28
#define B0b00101001	(unsigned int) 0x29
#define B0b00101010	(unsigned int) 0x2A
#define B0b00101011	(unsigned int) 0x2B
#define B0b00101100	(unsigned int) 0x2C
#define B0b00101101	(unsigned int) 0x2D
#define B0b00101110	(unsigned int) 0x2E
#define B0b00101111	(unsigned int) 0x2F

#define B0b00110000	(unsigned int) 0x30
#define B0b00110001	(unsigned int) 0x31
#define B0b00110010	(unsigned int) 0x32
#define B0b00110011	(unsigned int) 0x33
#define B0b00110100	(unsigned int) 0x34
#define B0b00110101	(unsigned int) 0x35
#define B0b00110110	(unsigned int) 0x36
#define B0b00110111	(unsigned int) 0x37
#define B0b00111000	(unsigned int) 0x38
#define B0b00111001	(unsigned int) 0x39
#define B0b00111010	(unsigned int) 0x3A
#define B0b00111011	(unsigned int) 0x3B
#define B0b00111100	(unsigned int) 0x3C
#define B0b00111101	(unsigned int) 0x3D
#define B0b00111110	(unsigned int) 0x3E
#define B0b00111111	(unsigned int) 0x3F

#define B0b01000000	(unsigned int) 0x40
#define B0b01000001	(unsigned int) 0x41
#define B0b01000010	(unsigned int) 0x42
#define B0b01000011	(unsigned int) 0x43
#define B0b01000100	(unsigned int) 0x44
#define B0b01000101	(unsigned int) 0x45
#define B0b01000110	(unsigned int) 0x46
#define B0b01000111	(unsigned int) 0x47
#define B0b01001000	(unsigned int) 0x48
#define B0b01001001	(unsigned int) 0x49
#define B0b01001010	(unsigned int) 0x4A
#define B0b01001011	(unsigned int) 0x4B
#define B0b01001100	(unsigned int) 0x4C
#define B0b01001101	(unsigned int) 0x4D
#define B0b01001110	(unsigned int) 0x4E
#define B0b01001111	(unsigned int) 0x4F

#define B0b01010000	(unsigned int) 0x50
#define B0b01010001	(unsigned int) 0x51
#define B0b01010010	(unsigned int) 0x52
#define B0b01010011	(unsigned int) 0x53
#define B0b01010100	(unsigned int) 0x54
#define B0b01010101	(unsigned int) 0x55
#define B0b01010110	(unsigned int) 0x56
#define B0b01010111	(unsigned int) 0x57
#define B0b01011000	(unsigned int) 0x58
#define B0b01011001	(unsigned int) 0x59
#define B0b01011010	(unsigned int) 0x5A
#define B0b01011011	(unsigned int) 0x5B
#define B0b01011100	(unsigned int) 0x5C
#define B0b01011101	(unsigned int) 0x5D
#define B0b01011110	(unsigned int) 0x5E
#define B0b01011111	(unsigned int) 0x5F

#define B0b01100000	(unsigned int) 0x60
#define B0b01100001	(unsigned int) 0x61
#define B0b01100010	(unsigned int) 0x62
#define B0b01100011	(unsigned int) 0x63
#define B0b01100100	(unsigned int) 0x64
#define B0b01100101	(unsigned int) 0x65
#define B0b01100110	(unsigned int) 0x66
#define B0b01100111	(unsigned int) 0x67
#define B0b01101000	(unsigned int) 0x68
#define B0b01101001	(unsigned int) 0x69
#define B0b01101010	(unsigned int) 0x6A
#define B0b01101011	(unsigned int) 0x6B
#define B0b01101100	(unsigned int) 0x6C
#define B0b01101101	(unsigned int) 0x6D
#define B0b01101110	(unsigned int) 0x6E
#define B0b01101111	(unsigned int) 0x6F

#define B0b01110000	(unsigned int) 0x70
#define B0b01110001	(unsigned int) 0x71
#define B0b01110010	(unsigned int) 0x72
#define B0b01110011	(unsigned int) 0x73
#define B0b01110100	(unsigned int) 0x74
#define B0b01110101	(unsigned int) 0x75
#define B0b01110110	(unsigned int) 0x76
#define B0b01110111	(unsigned int) 0x77
#define B0b01111000	(unsigned int) 0x78
#define B0b01111001	(unsigned int) 0x79
#define B0b01111010	(unsigned int) 0x7A
#define B0b01111011	(unsigned int) 0x7B
#define B0b01111100	(unsigned int) 0x7C
#define B0b01111101	(unsigned int) 0x7D
#define B0b01111110	(unsigned int) 0x7E
#define B0b01111111	(unsigned int) 0x7F


#define B0b10000000	(unsigned int) 0x80
#define B0b10000001	(unsigned int) 0x81
#define B0b10000010	(unsigned int) 0x82
#define B0b10000011	(unsigned int) 0x83
#define B0b10000100	(unsigned int) 0x84
#define B0b10000101	(unsigned int) 0x85
#define B0b10000110	(unsigned int) 0x86
#define B0b10000111	(unsigned int) 0x87
#define B0b10001000	(unsigned int) 0x88
#define B0b10001001	(unsigned int) 0x89
#define B0b10001010	(unsigned int) 0x8A
#define B0b10001011	(unsigned int) 0x8B
#define B0b10001100	(unsigned int) 0x8C
#define B0b10001101	(unsigned int) 0x8D
#define B0b10001110	(unsigned int) 0x8E
#define B0b10001111	(unsigned int) 0x8F

#define B0b10010000	(unsigned int) 0x90
#define B0b10010001	(unsigned int) 0x91
#define B0b10010010	(unsigned int) 0x92
#define B0b10010011	(unsigned int) 0x93
#define B0b10010100	(unsigned int) 0x94
#define B0b10010101	(unsigned int) 0x95
#define B0b10010110	(unsigned int) 0x96
#define B0b10010111	(unsigned int) 0x97
#define B0b10011000	(unsigned int) 0x98
#define B0b10011001	(unsigned int) 0x99
#define B0b10011010	(unsigned int) 0x9A
#define B0b10011011	(unsigned int) 0x9B
#define B0b10011100	(unsigned int) 0x9C
#define B0b10011101	(unsigned int) 0x9D
#define B0b10011110	(unsigned int) 0x9E
#define B0b10011111	(unsigned int) 0x9F

#define B0b10100000	(unsigned int) 0xA0
#define B0b10100001	(unsigned int) 0xA1
#define B0b10100010	(unsigned int) 0xA2
#define B0b10100011	(unsigned int) 0xA3
#define B0b10100100	(unsigned int) 0xA4
#define B0b10100101	(unsigned int) 0xA5
#define B0b10100110	(unsigned int) 0xA6
#define B0b10100111	(unsigned int) 0xA7
#define B0b10101000	(unsigned int) 0xA8
#define B0b10101001	(unsigned int) 0xA9
#define B0b10101010	(unsigned int) 0xAA
#define B0b10101011	(unsigned int) 0xAB
#define B0b10101100	(unsigned int) 0xAC
#define B0b10101101	(unsigned int) 0xAD
#define B0b10101110	(unsigned int) 0xAE
#define B0b10101111	(unsigned int) 0xAF

#define B0b10110000	(unsigned int) 0xB0
#define B0b10110001	(unsigned int) 0xB1
#define B0b10110010	(unsigned int) 0xB2
#define B0b10110011	(unsigned int) 0xB3
#define B0b10110100	(unsigned int) 0xB4
#define B0b10110101	(unsigned int) 0xB5
#define B0b10110110	(unsigned int) 0xB6
#define B0b10110111	(unsigned int) 0xB7
#define B0b10111000	(unsigned int) 0xB8
#define B0b10111001	(unsigned int) 0xB9
#define B0b10111010	(unsigned int) 0xBA
#define B0b10111011	(unsigned int) 0xBB
#define B0b10111100	(unsigned int) 0xBC
#define B0b10111101	(unsigned int) 0xBD
#define B0b10111110	(unsigned int) 0xBE
#define B0b10111111	(unsigned int) 0xBF

#define B0b11000000	(unsigned int) 0xC0
#define B0b11000001	(unsigned int) 0xC1
#define B0b11000010	(unsigned int) 0xC2
#define B0b11000011	(unsigned int) 0xC3
#define B0b11000100	(unsigned int) 0xC4
#define B0b11000101	(unsigned int) 0xC5
#define B0b11000110	(unsigned int) 0xC6
#define B0b11000111	(unsigned int) 0xC7
#define B0b11001000	(unsigned int) 0xC8
#define B0b11001001	(unsigned int) 0xC9
#define B0b11001010	(unsigned int) 0xCA
#define B0b11001011	(unsigned int) 0xCB
#define B0b11001100	(unsigned int) 0xCC
#define B0b11001101	(unsigned int) 0xCD
#define B0b11001110	(unsigned int) 0xCE
#define B0b11001111	(unsigned int) 0xCF

#define B0b11010000	(unsigned int) 0xD0
#define B0b11010001	(unsigned int) 0xD1
#define B0b11010010	(unsigned int) 0xD2
#define B0b11010011	(unsigned int) 0xD3
#define B0b11010100	(unsigned int) 0xD4
#define B0b11010101	(unsigned int) 0xD5
#define B0b11010110	(unsigned int) 0xD6
#define B0b11010111	(unsigned int) 0xD7
#define B0b11011000	(unsigned int) 0xD8
#define B0b11011001	(unsigned int) 0xD9
#define B0b11011010	(unsigned int) 0xDA
#define B0b11011011	(unsigned int) 0xDB
#define B0b11011100	(unsigned int) 0xDC
#define B0b11011101	(unsigned int) 0xDD
#define B0b11011110	(unsigned int) 0xDE
#define B0b11011111	(unsigned int) 0xDF

#define B0b11100000	(unsigned int) 0xE0
#define B0b11100001	(unsigned int) 0xE1
#define B0b11100010	(unsigned int) 0xE2
#define B0b11100011	(unsigned int) 0xE3
#define B0b11100100	(unsigned int) 0xE4
#define B0b11100101	(unsigned int) 0xE5
#define B0b11100110	(unsigned int) 0xE6
#define B0b11100111	(unsigned int) 0xE7
#define B0b11101000	(unsigned int) 0xE8
#define B0b11101001	(unsigned int) 0xE9
#define B0b11101010	(unsigned int) 0xEA
#define B0b11101011	(unsigned int) 0xEB
#define B0b11101100	(unsigned int) 0xEC
#define B0b11101101	(unsigned int) 0xED
#define B0b11101110	(unsigned int) 0xEE
#define B0b11101111	(unsigned int) 0xEF

#define B0b11110000	(unsigned int) 0xF0
#define B0b11110001	(unsigned int) 0xF1
#define B0b11110010	(unsigned int) 0xF2
#define B0b11110011	(unsigned int) 0xF3
#define B0b11110100	(unsigned int) 0xF4
#define B0b11110101	(unsigned int) 0xF5
#define B0b11110110	(unsigned int) 0xF6
#define B0b11110111	(unsigned int) 0xF7
#define B0b11111000	(unsigned int) 0xF8
#define B0b11111001	(unsigned int) 0xF9
#define B0b11111010	(unsigned int) 0xFA
#define B0b11111011	(unsigned int) 0xFB
#define B0b11111100	(unsigned int) 0xFC
#define B0b11111101	(unsigned int) 0xFD
#define B0b11111110	(unsigned int) 0xFE
#define B0b11111111	(unsigned int) 0xFF

#define B1b00000000	(unsigned int) 0x00 * 256
#define B1b00000001	(unsigned int) 0x01 * 256
#define B1b00000010	(unsigned int) 0x02 * 256
#define B1b00000011	(unsigned int) 0x03 * 256
#define B1b00000100	(unsigned int) 0x04 * 256
#define B1b00000101	(unsigned int) 0x05 * 256
#define B1b00000110	(unsigned int) 0x06 * 256
#define B1b00000111	(unsigned int) 0x07 * 256
#define B1b00001000	(unsigned int) 0x08 * 256
#define B1b00001001	(unsigned int) 0x09 * 256
#define B1b00001010	(unsigned int) 0x0A * 256
#define B1b00001011	(unsigned int) 0x0B * 256
#define B1b00001100	(unsigned int) 0x0C * 256
#define B1b00001101	(unsigned int) 0x0D * 256
#define B1b00001110	(unsigned int) 0x0E * 256
#define B1b00001111	(unsigned int) 0x0F * 256

#define B1b00010000	(unsigned int) 0x10 * 256
#define B1b00010001	(unsigned int) 0x11 * 256
#define B1b00010010	(unsigned int) 0x12 * 256
#define B1b00010011	(unsigned int) 0x13 * 256
#define B1b00010100	(unsigned int) 0x14 * 256
#define B1b00010101	(unsigned int) 0x15 * 256
#define B1b00010110	(unsigned int) 0x16 * 256
#define B1b00010111	(unsigned int) 0x17 * 256
#define B1b00011000	(unsigned int) 0x18 * 256
#define B1b00011001	(unsigned int) 0x19 * 256
#define B1b00011010	(unsigned int) 0x1A * 256
#define B1b00011011	(unsigned int) 0x1B * 256
#define B1b00011100	(unsigned int) 0x1C * 256
#define B1b00011101	(unsigned int) 0x1D * 256
#define B1b00011110	(unsigned int) 0x1E * 256
#define B1b00011111	(unsigned int) 0x1F * 256

#define B1b00100000	(unsigned int) 0x20 * 256
#define B1b00100001	(unsigned int) 0x21 * 256
#define B1b00100010	(unsigned int) 0x22 * 256
#define B1b00100011	(unsigned int) 0x23 * 256
#define B1b00100100	(unsigned int) 0x24 * 256
#define B1b00100101	(unsigned int) 0x25 * 256
#define B1b00100110	(unsigned int) 0x26 * 256
#define B1b00100111	(unsigned int) 0x27 * 256
#define B1b00101000	(unsigned int) 0x28 * 256
#define B1b00101001	(unsigned int) 0x29 * 256
#define B1b00101010	(unsigned int) 0x2A * 256
#define B1b00101011	(unsigned int) 0x2B * 256
#define B1b00101100	(unsigned int) 0x2C * 256
#define B1b00101101	(unsigned int) 0x2D * 256
#define B1b00101110	(unsigned int) 0x2E * 256
#define B1b00101111	(unsigned int) 0x2F * 256

#define B1b00110000	(unsigned int) 0x30 * 256
#define B1b00110001	(unsigned int) 0x31 * 256
#define B1b00110010	(unsigned int) 0x32 * 256
#define B1b00110011	(unsigned int) 0x33 * 256
#define B1b00110100	(unsigned int) 0x34 * 256
#define B1b00110101	(unsigned int) 0x35 * 256
#define B1b00110110	(unsigned int) 0x36 * 256
#define B1b00110111	(unsigned int) 0x37 * 256
#define B1b00111000	(unsigned int) 0x38 * 256
#define B1b00111001	(unsigned int) 0x39 * 256
#define B1b00111010	(unsigned int) 0x3A * 256
#define B1b00111011	(unsigned int) 0x3B * 256
#define B1b00111100	(unsigned int) 0x3C * 256
#define B1b00111101	(unsigned int) 0x3D * 256
#define B1b00111110	(unsigned int) 0x3E * 256
#define B1b00111111	(unsigned int) 0x3F * 256

#define B1b01000000	(unsigned int) 0x40 * 256
#define B1b01000001	(unsigned int) 0x41 * 256
#define B1b01000010	(unsigned int) 0x42 * 256
#define B1b01000011	(unsigned int) 0x43 * 256
#define B1b01000100	(unsigned int) 0x44 * 256
#define B1b01000101	(unsigned int) 0x45 * 256
#define B1b01000110	(unsigned int) 0x46 * 256
#define B1b01000111	(unsigned int) 0x47 * 256
#define B1b01001000	(unsigned int) 0x48 * 256
#define B1b01001001	(unsigned int) 0x49 * 256
#define B1b01001010	(unsigned int) 0x4A * 256
#define B1b01001011	(unsigned int) 0x4B * 256
#define B1b01001100	(unsigned int) 0x4C * 256
#define B1b01001101	(unsigned int) 0x4D * 256
#define B1b01001110	(unsigned int) 0x4E * 256
#define B1b01001111	(unsigned int) 0x4F * 256

#define B1b01010000	(unsigned int) 0x50 * 256
#define B1b01010001	(unsigned int) 0x51 * 256
#define B1b01010010	(unsigned int) 0x52 * 256
#define B1b01010011	(unsigned int) 0x53 * 256
#define B1b01010100	(unsigned int) 0x54 * 256
#define B1b01010101	(unsigned int) 0x55 * 256
#define B1b01010110	(unsigned int) 0x56 * 256
#define B1b01010111	(unsigned int) 0x57 * 256
#define B1b01011000	(unsigned int) 0x58 * 256
#define B1b01011001	(unsigned int) 0x59 * 256
#define B1b01011010	(unsigned int) 0x5A * 256
#define B1b01011011	(unsigned int) 0x5B * 256
#define B1b01011100	(unsigned int) 0x5C * 256
#define B1b01011101	(unsigned int) 0x5D * 256
#define B1b01011110	(unsigned int) 0x5E * 256
#define B1b01011111	(unsigned int) 0x5F * 256

#define B1b01100000	(unsigned int) 0x60 * 256
#define B1b01100001	(unsigned int) 0x61 * 256
#define B1b01100010	(unsigned int) 0x62 * 256
#define B1b01100011	(unsigned int) 0x63 * 256
#define B1b01100100	(unsigned int) 0x64 * 256
#define B1b01100101	(unsigned int) 0x65 * 256
#define B1b01100110	(unsigned int) 0x66 * 256
#define B1b01100111	(unsigned int) 0x67 * 256
#define B1b01101000	(unsigned int) 0x68 * 256
#define B1b01101001	(unsigned int) 0x69 * 256
#define B1b01101010	(unsigned int) 0x6A * 256
#define B1b01101011	(unsigned int) 0x6B * 256
#define B1b01101100	(unsigned int) 0x6C * 256
#define B1b01101101	(unsigned int) 0x6D * 256
#define B1b01101110	(unsigned int) 0x6E * 256
#define B1b01101111	(unsigned int) 0x6F * 256

#define B1b01110000	(unsigned int) 0x70 * 256
#define B1b01110001	(unsigned int) 0x71 * 256
#define B1b01110010	(unsigned int) 0x72 * 256
#define B1b01110011	(unsigned int) 0x73 * 256
#define B1b01110100	(unsigned int) 0x74 * 256
#define B1b01110101	(unsigned int) 0x75 * 256
#define B1b01110110	(unsigned int) 0x76 * 256
#define B1b01110111	(unsigned int) 0x77 * 256
#define B1b01111000	(unsigned int) 0x78 * 256
#define B1b01111001	(unsigned int) 0x79 * 256
#define B1b01111010	(unsigned int) 0x7A * 256
#define B1b01111011	(unsigned int) 0x7B * 256
#define B1b01111100	(unsigned int) 0x7C * 256
#define B1b01111101	(unsigned int) 0x7D * 256
#define B1b01111110	(unsigned int) 0x7E * 256
#define B1b01111111	(unsigned int) 0x7F * 256


#define B1b10000000	(unsigned int) 0x80 * 256
#define B1b10000001	(unsigned int) 0x81 * 256
#define B1b10000010	(unsigned int) 0x82 * 256
#define B1b10000011	(unsigned int) 0x83 * 256
#define B1b10000100	(unsigned int) 0x84 * 256
#define B1b10000101	(unsigned int) 0x85 * 256
#define B1b10000110	(unsigned int) 0x86 * 256
#define B1b10000111	(unsigned int) 0x87 * 256
#define B1b10001000	(unsigned int) 0x88 * 256
#define B1b10001001	(unsigned int) 0x89 * 256
#define B1b10001010	(unsigned int) 0x8A * 256
#define B1b10001011	(unsigned int) 0x8B * 256
#define B1b10001100	(unsigned int) 0x8C * 256
#define B1b10001101	(unsigned int) 0x8D * 256
#define B1b10001110	(unsigned int) 0x8E * 256
#define B1b10001111	(unsigned int) 0x8F * 256

#define B1b10010000	(unsigned int) 0x90 * 256
#define B1b10010001	(unsigned int) 0x91 * 256
#define B1b10010010	(unsigned int) 0x92 * 256
#define B1b10010011	(unsigned int) 0x93 * 256
#define B1b10010100	(unsigned int) 0x94 * 256
#define B1b10010101	(unsigned int) 0x95 * 256
#define B1b10010110	(unsigned int) 0x96 * 256
#define B1b10010111	(unsigned int) 0x97 * 256
#define B1b10011000	(unsigned int) 0x98 * 256
#define B1b10011001	(unsigned int) 0x99 * 256
#define B1b10011010	(unsigned int) 0x9A * 256
#define B1b10011011	(unsigned int) 0x9B * 256
#define B1b10011100	(unsigned int) 0x9C * 256
#define B1b10011101	(unsigned int) 0x9D * 256
#define B1b10011110	(unsigned int) 0x9E * 256
#define B1b10011111	(unsigned int) 0x9F * 256

#define B1b10100000	(unsigned int) 0xA0 * 256
#define B1b10100001	(unsigned int) 0xA1 * 256
#define B1b10100010	(unsigned int) 0xA2 * 256
#define B1b10100011	(unsigned int) 0xA3 * 256
#define B1b10100100	(unsigned int) 0xA4 * 256
#define B1b10100101	(unsigned int) 0xA5 * 256
#define B1b10100110	(unsigned int) 0xA6 * 256
#define B1b10100111	(unsigned int) 0xA7 * 256
#define B1b10101000	(unsigned int) 0xA8 * 256
#define B1b10101001	(unsigned int) 0xA9 * 256
#define B1b10101010	(unsigned int) 0xAA * 256
#define B1b10101011	(unsigned int) 0xAB * 256
#define B1b10101100	(unsigned int) 0xAC * 256
#define B1b10101101	(unsigned int) 0xAD * 256
#define B1b10101110	(unsigned int) 0xAE * 256
#define B1b10101111	(unsigned int) 0xAF * 256

#define B1b10110000	(unsigned int) 0xB0 * 256
#define B1b10110001	(unsigned int) 0xB1 * 256
#define B1b10110010	(unsigned int) 0xB2 * 256
#define B1b10110011	(unsigned int) 0xB3 * 256
#define B1b10110100	(unsigned int) 0xB4 * 256
#define B1b10110101	(unsigned int) 0xB5 * 256
#define B1b10110110	(unsigned int) 0xB6 * 256
#define B1b10110111	(unsigned int) 0xB7 * 256
#define B1b10111000	(unsigned int) 0xB8 * 256
#define B1b10111001	(unsigned int) 0xB9 * 256
#define B1b10111010	(unsigned int) 0xBA * 256
#define B1b10111011	(unsigned int) 0xBB * 256
#define B1b10111100	(unsigned int) 0xBC * 256
#define B1b10111101	(unsigned int) 0xBD * 256
#define B1b10111110	(unsigned int) 0xBE * 256
#define B1b10111111	(unsigned int) 0xBF * 256

#define B1b11000000	(unsigned int) 0xC0 * 256
#define B1b11000001	(unsigned int) 0xC1 * 256
#define B1b11000010	(unsigned int) 0xC2 * 256
#define B1b11000011	(unsigned int) 0xC3 * 256
#define B1b11000100	(unsigned int) 0xC4 * 256
#define B1b11000101	(unsigned int) 0xC5 * 256
#define B1b11000110	(unsigned int) 0xC6 * 256
#define B1b11000111	(unsigned int) 0xC7 * 256
#define B1b11001000	(unsigned int) 0xC8 * 256
#define B1b11001001	(unsigned int) 0xC9 * 256
#define B1b11001010	(unsigned int) 0xCA * 256
#define B1b11001011	(unsigned int) 0xCB * 256
#define B1b11001100	(unsigned int) 0xCC * 256
#define B1b11001101	(unsigned int) 0xCD * 256
#define B1b11001110	(unsigned int) 0xCE * 256
#define B1b11001111	(unsigned int) 0xCF * 256

#define B1b11010000	(unsigned int) 0xD0 * 256
#define B1b11010001	(unsigned int) 0xD1 * 256
#define B1b11010010	(unsigned int) 0xD2 * 256
#define B1b11010011	(unsigned int) 0xD3 * 256
#define B1b11010100	(unsigned int) 0xD4 * 256
#define B1b11010101	(unsigned int) 0xD5 * 256
#define B1b11010110	(unsigned int) 0xD6 * 256
#define B1b11010111	(unsigned int) 0xD7 * 256
#define B1b11011000	(unsigned int) 0xD8 * 256
#define B1b11011001	(unsigned int) 0xD9 * 256
#define B1b11011010	(unsigned int) 0xDA * 256
#define B1b11011011	(unsigned int) 0xDB * 256
#define B1b11011100	(unsigned int) 0xDC * 256
#define B1b11011101	(unsigned int) 0xDD * 256
#define B1b11011110	(unsigned int) 0xDE * 256
#define B1b11011111	(unsigned int) 0xDF * 256

#define B1b11100000	(unsigned int) 0xE0 * 256
#define B1b11100001	(unsigned int) 0xE1 * 256
#define B1b11100010	(unsigned int) 0xE2 * 256
#define B1b11100011	(unsigned int) 0xE3 * 256
#define B1b11100100	(unsigned int) 0xE4 * 256
#define B1b11100101	(unsigned int) 0xE5 * 256
#define B1b11100110	(unsigned int) 0xE6 * 256
#define B1b11100111	(unsigned int) 0xE7 * 256
#define B1b11101000	(unsigned int) 0xE8 * 256
#define B1b11101001	(unsigned int) 0xE9 * 256
#define B1b11101010	(unsigned int) 0xEA * 256
#define B1b11101011	(unsigned int) 0xEB * 256
#define B1b11101100	(unsigned int) 0xEC * 256
#define B1b11101101	(unsigned int) 0xED * 256
#define B1b11101110	(unsigned int) 0xEE * 256
#define B1b11101111	(unsigned int) 0xEF * 256

#define B1b11110000	(unsigned int) 0xF0 * 256
#define B1b11110001	(unsigned int) 0xF1 * 256
#define B1b11110010	(unsigned int) 0xF2 * 256
#define B1b11110011	(unsigned int) 0xF3 * 256
#define B1b11110100	(unsigned int) 0xF4 * 256
#define B1b11110101	(unsigned int) 0xF5 * 256
#define B1b11110110	(unsigned int) 0xF6 * 256
#define B1b11110111	(unsigned int) 0xF7 * 256
#define B1b11111000	(unsigned int) 0xF8 * 256
#define B1b11111001	(unsigned int) 0xF9 * 256
#define B1b11111010	(unsigned int) 0xFA * 256
#define B1b11111011	(unsigned int) 0xFB * 256
#define B1b11111100	(unsigned int) 0xFC * 256
#define B1b11111101	(unsigned int) 0xFD * 256
#define B1b11111110	(unsigned int) 0xFE * 256
#define B1b11111111	(unsigned int) 0xFF * 256


#define B2b00000000	(unsigned int) 0x00 * 65536
#define B2b00000001	(unsigned int) 0x01 * 65536
#define B2b00000010	(unsigned int) 0x02 * 65536
#define B2b00000011	(unsigned int) 0x03 * 65536
#define B2b00000100	(unsigned int) 0x04 * 65536
#define B2b00000101	(unsigned int) 0x05 * 65536
#define B2b00000110	(unsigned int) 0x06 * 65536
#define B2b00000111	(unsigned int) 0x07 * 65536
#define B2b00001000	(unsigned int) 0x08 * 65536
#define B2b00001001	(unsigned int) 0x09 * 65536
#define B2b00001010	(unsigned int) 0x0A * 65536
#define B2b00001011	(unsigned int) 0x0B * 65536
#define B2b00001100	(unsigned int) 0x0C * 65536
#define B2b00001101	(unsigned int) 0x0D * 65536
#define B2b00001110	(unsigned int) 0x0E * 65536
#define B2b00001111	(unsigned int) 0x0F * 65536

#define B2b00010000	(unsigned int) 0x10 * 65536
#define B2b00010001	(unsigned int) 0x11 * 65536
#define B2b00010010	(unsigned int) 0x12 * 65536
#define B2b00010011	(unsigned int) 0x13 * 65536
#define B2b00010100	(unsigned int) 0x14 * 65536
#define B2b00010101	(unsigned int) 0x15 * 65536
#define B2b00010110	(unsigned int) 0x16 * 65536
#define B2b00010111	(unsigned int) 0x17 * 65536
#define B2b00011000	(unsigned int) 0x18 * 65536
#define B2b00011001	(unsigned int) 0x19 * 65536
#define B2b00011010	(unsigned int) 0x1A * 65536
#define B2b00011011	(unsigned int) 0x1B * 65536
#define B2b00011100	(unsigned int) 0x1C * 65536
#define B2b00011101	(unsigned int) 0x1D * 65536
#define B2b00011110	(unsigned int) 0x1E * 65536
#define B2b00011111	(unsigned int) 0x1F * 65536

#define B2b00100000	(unsigned int) 0x20 * 65536
#define B2b00100001	(unsigned int) 0x21 * 65536
#define B2b00100010	(unsigned int) 0x22 * 65536
#define B2b00100011	(unsigned int) 0x23 * 65536
#define B2b00100100	(unsigned int) 0x24 * 65536
#define B2b00100101	(unsigned int) 0x25 * 65536
#define B2b00100110	(unsigned int) 0x26 * 65536
#define B2b00100111	(unsigned int) 0x27 * 65536
#define B2b00101000	(unsigned int) 0x28 * 65536
#define B2b00101001	(unsigned int) 0x29 * 65536
#define B2b00101010	(unsigned int) 0x2A * 65536
#define B2b00101011	(unsigned int) 0x2B * 65536
#define B2b00101100	(unsigned int) 0x2C * 65536
#define B2b00101101	(unsigned int) 0x2D * 65536
#define B2b00101110	(unsigned int) 0x2E * 65536
#define B2b00101111	(unsigned int) 0x2F * 65536

#define B2b00110000	(unsigned int) 0x30 * 65536
#define B2b00110001	(unsigned int) 0x31 * 65536
#define B2b00110010	(unsigned int) 0x32 * 65536
#define B2b00110011	(unsigned int) 0x33 * 65536
#define B2b00110100	(unsigned int) 0x34 * 65536
#define B2b00110101	(unsigned int) 0x35 * 65536
#define B2b00110110	(unsigned int) 0x36 * 65536
#define B2b00110111	(unsigned int) 0x37 * 65536
#define B2b00111000	(unsigned int) 0x38 * 65536
#define B2b00111001	(unsigned int) 0x39 * 65536
#define B2b00111010	(unsigned int) 0x3A * 65536
#define B2b00111011	(unsigned int) 0x3B * 65536
#define B2b00111100	(unsigned int) 0x3C * 65536
#define B2b00111101	(unsigned int) 0x3D * 65536
#define B2b00111110	(unsigned int) 0x3E * 65536
#define B2b00111111	(unsigned int) 0x3F * 65536

#define B2b01000000	(unsigned int) 0x40 * 65536
#define B2b01000001	(unsigned int) 0x41 * 65536
#define B2b01000010	(unsigned int) 0x42 * 65536
#define B2b01000011	(unsigned int) 0x43 * 65536
#define B2b01000100	(unsigned int) 0x44 * 65536
#define B2b01000101	(unsigned int) 0x45 * 65536
#define B2b01000110	(unsigned int) 0x46 * 65536
#define B2b01000111	(unsigned int) 0x47 * 65536
#define B2b01001000	(unsigned int) 0x48 * 65536
#define B2b01001001	(unsigned int) 0x49 * 65536
#define B2b01001010	(unsigned int) 0x4A * 65536
#define B2b01001011	(unsigned int) 0x4B * 65536
#define B2b01001100	(unsigned int) 0x4C * 65536
#define B2b01001101	(unsigned int) 0x4D * 65536
#define B2b01001110	(unsigned int) 0x4E * 65536
#define B2b01001111	(unsigned int) 0x4F * 65536

#define B2b01010000	(unsigned int) 0x50 * 65536
#define B2b01010001	(unsigned int) 0x51 * 65536
#define B2b01010010	(unsigned int) 0x52 * 65536
#define B2b01010011	(unsigned int) 0x53 * 65536
#define B2b01010100	(unsigned int) 0x54 * 65536
#define B2b01010101	(unsigned int) 0x55 * 65536
#define B2b01010110	(unsigned int) 0x56 * 65536
#define B2b01010111	(unsigned int) 0x57 * 65536
#define B2b01011000	(unsigned int) 0x58 * 65536
#define B2b01011001	(unsigned int) 0x59 * 65536
#define B2b01011010	(unsigned int) 0x5A * 65536
#define B2b01011011	(unsigned int) 0x5B * 65536
#define B2b01011100	(unsigned int) 0x5C * 65536
#define B2b01011101	(unsigned int) 0x5D * 65536
#define B2b01011110	(unsigned int) 0x5E * 65536
#define B2b01011111	(unsigned int) 0x5F * 65536

#define B2b01100000	(unsigned int) 0x60 * 65536
#define B2b01100001	(unsigned int) 0x61 * 65536
#define B2b01100010	(unsigned int) 0x62 * 65536
#define B2b01100011	(unsigned int) 0x63 * 65536
#define B2b01100100	(unsigned int) 0x64 * 65536
#define B2b01100101	(unsigned int) 0x65 * 65536
#define B2b01100110	(unsigned int) 0x66 * 65536
#define B2b01100111	(unsigned int) 0x67 * 65536
#define B2b01101000	(unsigned int) 0x68 * 65536
#define B2b01101001	(unsigned int) 0x69 * 65536
#define B2b01101010	(unsigned int) 0x6A * 65536
#define B2b01101011	(unsigned int) 0x6B * 65536
#define B2b01101100	(unsigned int) 0x6C * 65536
#define B2b01101101	(unsigned int) 0x6D * 65536
#define B2b01101110	(unsigned int) 0x6E * 65536
#define B2b01101111	(unsigned int) 0x6F * 65536

#define B2b01110000	(unsigned int) 0x70 * 65536
#define B2b01110001	(unsigned int) 0x71 * 65536
#define B2b01110010	(unsigned int) 0x72 * 65536
#define B2b01110011	(unsigned int) 0x73 * 65536
#define B2b01110100	(unsigned int) 0x74 * 65536
#define B2b01110101	(unsigned int) 0x75 * 65536
#define B2b01110110	(unsigned int) 0x76 * 65536
#define B2b01110111	(unsigned int) 0x77 * 65536
#define B2b01111000	(unsigned int) 0x78 * 65536
#define B2b01111001	(unsigned int) 0x79 * 65536
#define B2b01111010	(unsigned int) 0x7A * 65536
#define B2b01111011	(unsigned int) 0x7B * 65536
#define B2b01111100	(unsigned int) 0x7C * 65536
#define B2b01111101	(unsigned int) 0x7D * 65536
#define B2b01111110	(unsigned int) 0x7E * 65536
#define B2b01111111	(unsigned int) 0x7F * 65536


#define B2b10000000	(unsigned int) 0x80 * 65536
#define B2b10000001	(unsigned int) 0x81 * 65536
#define B2b10000010	(unsigned int) 0x82 * 65536
#define B2b10000011	(unsigned int) 0x83 * 65536
#define B2b10000100	(unsigned int) 0x84 * 65536
#define B2b10000101	(unsigned int) 0x85 * 65536
#define B2b10000110	(unsigned int) 0x86 * 65536
#define B2b10000111	(unsigned int) 0x87 * 65536
#define B2b10001000	(unsigned int) 0x88 * 65536
#define B2b10001001	(unsigned int) 0x89 * 65536
#define B2b10001010	(unsigned int) 0x8A * 65536
#define B2b10001011	(unsigned int) 0x8B * 65536
#define B2b10001100	(unsigned int) 0x8C * 65536
#define B2b10001101	(unsigned int) 0x8D * 65536
#define B2b10001110	(unsigned int) 0x8E * 65536
#define B2b10001111	(unsigned int) 0x8F * 65536

#define B2b10010000	(unsigned int) 0x90 * 65536
#define B2b10010001	(unsigned int) 0x91 * 65536
#define B2b10010010	(unsigned int) 0x92 * 65536
#define B2b10010011	(unsigned int) 0x93 * 65536
#define B2b10010100	(unsigned int) 0x94 * 65536
#define B2b10010101	(unsigned int) 0x95 * 65536
#define B2b10010110	(unsigned int) 0x96 * 65536
#define B2b10010111	(unsigned int) 0x97 * 65536
#define B2b10011000	(unsigned int) 0x98 * 65536
#define B2b10011001	(unsigned int) 0x99 * 65536
#define B2b10011010	(unsigned int) 0x9A * 65536
#define B2b10011011	(unsigned int) 0x9B * 65536
#define B2b10011100	(unsigned int) 0x9C * 65536
#define B2b10011101	(unsigned int) 0x9D * 65536
#define B2b10011110	(unsigned int) 0x9E * 65536
#define B2b10011111	(unsigned int) 0x9F * 65536

#define B2b10100000	(unsigned int) 0xA0 * 65536
#define B2b10100001	(unsigned int) 0xA1 * 65536
#define B2b10100010	(unsigned int) 0xA2 * 65536
#define B2b10100011	(unsigned int) 0xA3 * 65536
#define B2b10100100	(unsigned int) 0xA4 * 65536
#define B2b10100101	(unsigned int) 0xA5 * 65536
#define B2b10100110	(unsigned int) 0xA6 * 65536
#define B2b10100111	(unsigned int) 0xA7 * 65536
#define B2b10101000	(unsigned int) 0xA8 * 65536
#define B2b10101001	(unsigned int) 0xA9 * 65536
#define B2b10101010	(unsigned int) 0xAA * 65536
#define B2b10101011	(unsigned int) 0xAB * 65536
#define B2b10101100	(unsigned int) 0xAC * 65536
#define B2b10101101	(unsigned int) 0xAD * 65536
#define B2b10101110	(unsigned int) 0xAE * 65536
#define B2b10101111	(unsigned int) 0xAF * 65536

#define B2b10110000	(unsigned int) 0xB0 * 65536
#define B2b10110001	(unsigned int) 0xB1 * 65536
#define B2b10110010	(unsigned int) 0xB2 * 65536
#define B2b10110011	(unsigned int) 0xB3 * 65536
#define B2b10110100	(unsigned int) 0xB4 * 65536
#define B2b10110101	(unsigned int) 0xB5 * 65536
#define B2b10110110	(unsigned int) 0xB6 * 65536
#define B2b10110111	(unsigned int) 0xB7 * 65536
#define B2b10111000	(unsigned int) 0xB8 * 65536
#define B2b10111001	(unsigned int) 0xB9 * 65536
#define B2b10111010	(unsigned int) 0xBA * 65536
#define B2b10111011	(unsigned int) 0xBB * 65536
#define B2b10111100	(unsigned int) 0xBC * 65536
#define B2b10111101	(unsigned int) 0xBD * 65536
#define B2b10111110	(unsigned int) 0xBE * 65536
#define B2b10111111	(unsigned int) 0xBF * 65536

#define B2b11000000	(unsigned int) 0xC0 * 65536
#define B2b11000001	(unsigned int) 0xC1 * 65536
#define B2b11000010	(unsigned int) 0xC2 * 65536
#define B2b11000011	(unsigned int) 0xC3 * 65536
#define B2b11000100	(unsigned int) 0xC4 * 65536
#define B2b11000101	(unsigned int) 0xC5 * 65536
#define B2b11000110	(unsigned int) 0xC6 * 65536
#define B2b11000111	(unsigned int) 0xC7 * 65536
#define B2b11001000	(unsigned int) 0xC8 * 65536
#define B2b11001001	(unsigned int) 0xC9 * 65536
#define B2b11001010	(unsigned int) 0xCA * 65536
#define B2b11001011	(unsigned int) 0xCB * 65536
#define B2b11001100	(unsigned int) 0xCC * 65536
#define B2b11001101	(unsigned int) 0xCD * 65536
#define B2b11001110	(unsigned int) 0xCE * 65536
#define B2b11001111	(unsigned int) 0xCF * 65536

#define B2b11010000	(unsigned int) 0xD0 * 65536
#define B2b11010001	(unsigned int) 0xD1 * 65536
#define B2b11010010	(unsigned int) 0xD2 * 65536
#define B2b11010011	(unsigned int) 0xD3 * 65536
#define B2b11010100	(unsigned int) 0xD4 * 65536
#define B2b11010101	(unsigned int) 0xD5 * 65536
#define B2b11010110	(unsigned int) 0xD6 * 65536
#define B2b11010111	(unsigned int) 0xD7 * 65536
#define B2b11011000	(unsigned int) 0xD8 * 65536
#define B2b11011001	(unsigned int) 0xD9 * 65536
#define B2b11011010	(unsigned int) 0xDA * 65536
#define B2b11011011	(unsigned int) 0xDB * 65536
#define B2b11011100	(unsigned int) 0xDC * 65536
#define B2b11011101	(unsigned int) 0xDD * 65536
#define B2b11011110	(unsigned int) 0xDE * 65536
#define B2b11011111	(unsigned int) 0xDF * 65536

#define B2b11100000	(unsigned int) 0xE0 * 65536
#define B2b11100001	(unsigned int) 0xE1 * 65536
#define B2b11100010	(unsigned int) 0xE2 * 65536
#define B2b11100011	(unsigned int) 0xE3 * 65536
#define B2b11100100	(unsigned int) 0xE4 * 65536
#define B2b11100101	(unsigned int) 0xE5 * 65536
#define B2b11100110	(unsigned int) 0xE6 * 65536
#define B2b11100111	(unsigned int) 0xE7 * 65536
#define B2b11101000	(unsigned int) 0xE8 * 65536
#define B2b11101001	(unsigned int) 0xE9 * 65536
#define B2b11101010	(unsigned int) 0xEA * 65536
#define B2b11101011	(unsigned int) 0xEB * 65536
#define B2b11101100	(unsigned int) 0xEC * 65536
#define B2b11101101	(unsigned int) 0xED * 65536
#define B2b11101110	(unsigned int) 0xEE * 65536
#define B2b11101111	(unsigned int) 0xEF * 65536

#define B2b11110000	(unsigned int) 0xF0 * 65536
#define B2b11110001	(unsigned int) 0xF1 * 65536
#define B2b11110010	(unsigned int) 0xF2 * 65536
#define B2b11110011	(unsigned int) 0xF3 * 65536
#define B2b11110100	(unsigned int) 0xF4 * 65536
#define B2b11110101	(unsigned int) 0xF5 * 65536
#define B2b11110110	(unsigned int) 0xF6 * 65536
#define B2b11110111	(unsigned int) 0xF7 * 65536
#define B2b11111000	(unsigned int) 0xF8 * 65536
#define B2b11111001	(unsigned int) 0xF9 * 65536
#define B2b11111010	(unsigned int) 0xFA * 65536
#define B2b11111011	(unsigned int) 0xFB * 65536
#define B2b11111100	(unsigned int) 0xFC * 65536
#define B2b11111101	(unsigned int) 0xFD * 65536
#define B2b11111110	(unsigned int) 0xFE * 65536
#define B2b11111111	(unsigned int) 0xFF * 65536


#define B3b00000000	(unsigned int) 0x00 * 16777216
#define B3b00000001	(unsigned int) 0x01 * 16777216
#define B3b00000010	(unsigned int) 0x02 * 16777216
#define B3b00000011	(unsigned int) 0x03 * 16777216
#define B3b00000100	(unsigned int) 0x04 * 16777216
#define B3b00000101	(unsigned int) 0x05 * 16777216
#define B3b00000110	(unsigned int) 0x06 * 16777216
#define B3b00000111	(unsigned int) 0x07 * 16777216
#define B3b00001000	(unsigned int) 0x08 * 16777216
#define B3b00001001	(unsigned int) 0x09 * 16777216
#define B3b00001010	(unsigned int) 0x0A * 16777216
#define B3b00001011	(unsigned int) 0x0B * 16777216
#define B3b00001100	(unsigned int) 0x0C * 16777216
#define B3b00001101	(unsigned int) 0x0D * 16777216
#define B3b00001110	(unsigned int) 0x0E * 16777216
#define B3b00001111	(unsigned int) 0x0F * 16777216

#define B3b00010000	(unsigned int) 0x10 * 16777216
#define B3b00010001	(unsigned int) 0x11 * 16777216
#define B3b00010010	(unsigned int) 0x12 * 16777216
#define B3b00010011	(unsigned int) 0x13 * 16777216
#define B3b00010100	(unsigned int) 0x14 * 16777216
#define B3b00010101	(unsigned int) 0x15 * 16777216
#define B3b00010110	(unsigned int) 0x16 * 16777216
#define B3b00010111	(unsigned int) 0x17 * 16777216
#define B3b00011000	(unsigned int) 0x18 * 16777216
#define B3b00011001	(unsigned int) 0x19 * 16777216
#define B3b00011010	(unsigned int) 0x1A * 16777216
#define B3b00011011	(unsigned int) 0x1B * 16777216
#define B3b00011100	(unsigned int) 0x1C * 16777216
#define B3b00011101	(unsigned int) 0x1D * 16777216
#define B3b00011110	(unsigned int) 0x1E * 16777216
#define B3b00011111	(unsigned int) 0x1F * 16777216

#define B3b00100000	(unsigned int) 0x20 * 16777216
#define B3b00100001	(unsigned int) 0x21 * 16777216
#define B3b00100010	(unsigned int) 0x22 * 16777216
#define B3b00100011	(unsigned int) 0x23 * 16777216
#define B3b00100100	(unsigned int) 0x24 * 16777216
#define B3b00100101	(unsigned int) 0x25 * 16777216
#define B3b00100110	(unsigned int) 0x26 * 16777216
#define B3b00100111	(unsigned int) 0x27 * 16777216
#define B3b00101000	(unsigned int) 0x28 * 16777216
#define B3b00101001	(unsigned int) 0x29 * 16777216
#define B3b00101010	(unsigned int) 0x2A * 16777216
#define B3b00101011	(unsigned int) 0x2B * 16777216
#define B3b00101100	(unsigned int) 0x2C * 16777216
#define B3b00101101	(unsigned int) 0x2D * 16777216
#define B3b00101110	(unsigned int) 0x2E * 16777216
#define B3b00101111	(unsigned int) 0x2F * 16777216

#define B3b00110000	(unsigned int) 0x30 * 16777216
#define B3b00110001	(unsigned int) 0x31 * 16777216
#define B3b00110010	(unsigned int) 0x32 * 16777216
#define B3b00110011	(unsigned int) 0x33 * 16777216
#define B3b00110100	(unsigned int) 0x34 * 16777216
#define B3b00110101	(unsigned int) 0x35 * 16777216
#define B3b00110110	(unsigned int) 0x36 * 16777216
#define B3b00110111	(unsigned int) 0x37 * 16777216
#define B3b00111000	(unsigned int) 0x38 * 16777216
#define B3b00111001	(unsigned int) 0x39 * 16777216
#define B3b00111010	(unsigned int) 0x3A * 16777216
#define B3b00111011	(unsigned int) 0x3B * 16777216
#define B3b00111100	(unsigned int) 0x3C * 16777216
#define B3b00111101	(unsigned int) 0x3D * 16777216
#define B3b00111110	(unsigned int) 0x3E * 16777216
#define B3b00111111	(unsigned int) 0x3F * 16777216

#define B3b01000000	(unsigned int) 0x40 * 16777216
#define B3b01000001	(unsigned int) 0x41 * 16777216
#define B3b01000010	(unsigned int) 0x42 * 16777216
#define B3b01000011	(unsigned int) 0x43 * 16777216
#define B3b01000100	(unsigned int) 0x44 * 16777216
#define B3b01000101	(unsigned int) 0x45 * 16777216
#define B3b01000110	(unsigned int) 0x46 * 16777216
#define B3b01000111	(unsigned int) 0x47 * 16777216
#define B3b01001000	(unsigned int) 0x48 * 16777216
#define B3b01001001	(unsigned int) 0x49 * 16777216
#define B3b01001010	(unsigned int) 0x4A * 16777216
#define B3b01001011	(unsigned int) 0x4B * 16777216
#define B3b01001100	(unsigned int) 0x4C * 16777216
#define B3b01001101	(unsigned int) 0x4D * 16777216
#define B3b01001110	(unsigned int) 0x4E * 16777216
#define B3b01001111	(unsigned int) 0x4F * 16777216

#define B3b01010000	(unsigned int) 0x50 * 16777216
#define B3b01010001	(unsigned int) 0x51 * 16777216
#define B3b01010010	(unsigned int) 0x52 * 16777216
#define B3b01010011	(unsigned int) 0x53 * 16777216
#define B3b01010100	(unsigned int) 0x54 * 16777216
#define B3b01010101	(unsigned int) 0x55 * 16777216
#define B3b01010110	(unsigned int) 0x56 * 16777216
#define B3b01010111	(unsigned int) 0x57 * 16777216
#define B3b01011000	(unsigned int) 0x58 * 16777216
#define B3b01011001	(unsigned int) 0x59 * 16777216
#define B3b01011010	(unsigned int) 0x5A * 16777216
#define B3b01011011	(unsigned int) 0x5B * 16777216
#define B3b01011100	(unsigned int) 0x5C * 16777216
#define B3b01011101	(unsigned int) 0x5D * 16777216
#define B3b01011110	(unsigned int) 0x5E * 16777216
#define B3b01011111	(unsigned int) 0x5F * 16777216

#define B3b01100000	(unsigned int) 0x60 * 16777216
#define B3b01100001	(unsigned int) 0x61 * 16777216
#define B3b01100010	(unsigned int) 0x62 * 16777216
#define B3b01100011	(unsigned int) 0x63 * 16777216
#define B3b01100100	(unsigned int) 0x64 * 16777216
#define B3b01100101	(unsigned int) 0x65 * 16777216
#define B3b01100110	(unsigned int) 0x66 * 16777216
#define B3b01100111	(unsigned int) 0x67 * 16777216
#define B3b01101000	(unsigned int) 0x68 * 16777216
#define B3b01101001	(unsigned int) 0x69 * 16777216
#define B3b01101010	(unsigned int) 0x6A * 16777216
#define B3b01101011	(unsigned int) 0x6B * 16777216
#define B3b01101100	(unsigned int) 0x6C * 16777216
#define B3b01101101	(unsigned int) 0x6D * 16777216
#define B3b01101110	(unsigned int) 0x6E * 16777216
#define B3b01101111	(unsigned int) 0x6F * 16777216

#define B3b01110000	(unsigned int) 0x70 * 16777216
#define B3b01110001	(unsigned int) 0x71 * 16777216
#define B3b01110010	(unsigned int) 0x72 * 16777216
#define B3b01110011	(unsigned int) 0x73 * 16777216
#define B3b01110100	(unsigned int) 0x74 * 16777216
#define B3b01110101	(unsigned int) 0x75 * 16777216
#define B3b01110110	(unsigned int) 0x76 * 16777216
#define B3b01110111	(unsigned int) 0x77 * 16777216
#define B3b01111000	(unsigned int) 0x78 * 16777216
#define B3b01111001	(unsigned int) 0x79 * 16777216
#define B3b01111010	(unsigned int) 0x7A * 16777216
#define B3b01111011	(unsigned int) 0x7B * 16777216
#define B3b01111100	(unsigned int) 0x7C * 16777216
#define B3b01111101	(unsigned int) 0x7D * 16777216
#define B3b01111110	(unsigned int) 0x7E * 16777216
#define B3b01111111	(unsigned int) 0x7F * 16777216


#define B3b10000000	(unsigned int) 0x80 * 16777216
#define B3b10000001	(unsigned int) 0x81 * 16777216
#define B3b10000010	(unsigned int) 0x82 * 16777216
#define B3b10000011	(unsigned int) 0x83 * 16777216
#define B3b10000100	(unsigned int) 0x84 * 16777216
#define B3b10000101	(unsigned int) 0x85 * 16777216
#define B3b10000110	(unsigned int) 0x86 * 16777216
#define B3b10000111	(unsigned int) 0x87 * 16777216
#define B3b10001000	(unsigned int) 0x88 * 16777216
#define B3b10001001	(unsigned int) 0x89 * 16777216
#define B3b10001010	(unsigned int) 0x8A * 16777216
#define B3b10001011	(unsigned int) 0x8B * 16777216
#define B3b10001100	(unsigned int) 0x8C * 16777216
#define B3b10001101	(unsigned int) 0x8D * 16777216
#define B3b10001110	(unsigned int) 0x8E * 16777216
#define B3b10001111	(unsigned int) 0x8F * 16777216

#define B3b10010000	(unsigned int) 0x90 * 16777216
#define B3b10010001	(unsigned int) 0x91 * 16777216
#define B3b10010010	(unsigned int) 0x92 * 16777216
#define B3b10010011	(unsigned int) 0x93 * 16777216
#define B3b10010100	(unsigned int) 0x94 * 16777216
#define B3b10010101	(unsigned int) 0x95 * 16777216
#define B3b10010110	(unsigned int) 0x96 * 16777216
#define B3b10010111	(unsigned int) 0x97 * 16777216
#define B3b10011000	(unsigned int) 0x98 * 16777216
#define B3b10011001	(unsigned int) 0x99 * 16777216
#define B3b10011010	(unsigned int) 0x9A * 16777216
#define B3b10011011	(unsigned int) 0x9B * 16777216
#define B3b10011100	(unsigned int) 0x9C * 16777216
#define B3b10011101	(unsigned int) 0x9D * 16777216
#define B3b10011110	(unsigned int) 0x9E * 16777216
#define B3b10011111	(unsigned int) 0x9F * 16777216

#define B3b10100000	(unsigned int) 0xA0 * 16777216
#define B3b10100001	(unsigned int) 0xA1 * 16777216
#define B3b10100010	(unsigned int) 0xA2 * 16777216
#define B3b10100011	(unsigned int) 0xA3 * 16777216
#define B3b10100100	(unsigned int) 0xA4 * 16777216
#define B3b10100101	(unsigned int) 0xA5 * 16777216
#define B3b10100110	(unsigned int) 0xA6 * 16777216
#define B3b10100111	(unsigned int) 0xA7 * 16777216
#define B3b10101000	(unsigned int) 0xA8 * 16777216
#define B3b10101001	(unsigned int) 0xA9 * 16777216
#define B3b10101010	(unsigned int) 0xAA * 16777216
#define B3b10101011	(unsigned int) 0xAB * 16777216
#define B3b10101100	(unsigned int) 0xAC * 16777216
#define B3b10101101	(unsigned int) 0xAD * 16777216
#define B3b10101110	(unsigned int) 0xAE * 16777216
#define B3b10101111	(unsigned int) 0xAF * 16777216

#define B3b10110000	(unsigned int) 0xB0 * 16777216
#define B3b10110001	(unsigned int) 0xB1 * 16777216
#define B3b10110010	(unsigned int) 0xB2 * 16777216
#define B3b10110011	(unsigned int) 0xB3 * 16777216
#define B3b10110100	(unsigned int) 0xB4 * 16777216
#define B3b10110101	(unsigned int) 0xB5 * 16777216
#define B3b10110110	(unsigned int) 0xB6 * 16777216
#define B3b10110111	(unsigned int) 0xB7 * 16777216
#define B3b10111000	(unsigned int) 0xB8 * 16777216
#define B3b10111001	(unsigned int) 0xB9 * 16777216
#define B3b10111010	(unsigned int) 0xBA * 16777216
#define B3b10111011	(unsigned int) 0xBB * 16777216
#define B3b10111100	(unsigned int) 0xBC * 16777216
#define B3b10111101	(unsigned int) 0xBD * 16777216
#define B3b10111110	(unsigned int) 0xBE * 16777216
#define B3b10111111	(unsigned int) 0xBF * 16777216

#define B3b11000000	(unsigned int) 0xC0 * 16777216
#define B3b11000001	(unsigned int) 0xC1 * 16777216
#define B3b11000010	(unsigned int) 0xC2 * 16777216
#define B3b11000011	(unsigned int) 0xC3 * 16777216
#define B3b11000100	(unsigned int) 0xC4 * 16777216
#define B3b11000101	(unsigned int) 0xC5 * 16777216
#define B3b11000110	(unsigned int) 0xC6 * 16777216
#define B3b11000111	(unsigned int) 0xC7 * 16777216
#define B3b11001000	(unsigned int) 0xC8 * 16777216
#define B3b11001001	(unsigned int) 0xC9 * 16777216
#define B3b11001010	(unsigned int) 0xCA * 16777216
#define B3b11001011	(unsigned int) 0xCB * 16777216
#define B3b11001100	(unsigned int) 0xCC * 16777216
#define B3b11001101	(unsigned int) 0xCD * 16777216
#define B3b11001110	(unsigned int) 0xCE * 16777216
#define B3b11001111	(unsigned int) 0xCF * 16777216

#define B3b11010000	(unsigned int) 0xD0 * 16777216
#define B3b11010001	(unsigned int) 0xD1 * 16777216
#define B3b11010010	(unsigned int) 0xD2 * 16777216
#define B3b11010011	(unsigned int) 0xD3 * 16777216
#define B3b11010100	(unsigned int) 0xD4 * 16777216
#define B3b11010101	(unsigned int) 0xD5 * 16777216
#define B3b11010110	(unsigned int) 0xD6 * 16777216
#define B3b11010111	(unsigned int) 0xD7 * 16777216
#define B3b11011000	(unsigned int) 0xD8 * 16777216
#define B3b11011001	(unsigned int) 0xD9 * 16777216
#define B3b11011010	(unsigned int) 0xDA * 16777216
#define B3b11011011	(unsigned int) 0xDB * 16777216
#define B3b11011100	(unsigned int) 0xDC * 16777216
#define B3b11011101	(unsigned int) 0xDD * 16777216
#define B3b11011110	(unsigned int) 0xDE * 16777216
#define B3b11011111	(unsigned int) 0xDF * 16777216

#define B3b11100000	(unsigned int) 0xE0 * 16777216
#define B3b11100001	(unsigned int) 0xE1 * 16777216
#define B3b11100010	(unsigned int) 0xE2 * 16777216
#define B3b11100011	(unsigned int) 0xE3 * 16777216
#define B3b11100100	(unsigned int) 0xE4 * 16777216
#define B3b11100101	(unsigned int) 0xE5 * 16777216
#define B3b11100110	(unsigned int) 0xE6 * 16777216
#define B3b11100111	(unsigned int) 0xE7 * 16777216
#define B3b11101000	(unsigned int) 0xE8 * 16777216
#define B3b11101001	(unsigned int) 0xE9 * 16777216
#define B3b11101010	(unsigned int) 0xEA * 16777216
#define B3b11101011	(unsigned int) 0xEB * 16777216
#define B3b11101100	(unsigned int) 0xEC * 16777216
#define B3b11101101	(unsigned int) 0xED * 16777216
#define B3b11101110	(unsigned int) 0xEE * 16777216
#define B3b11101111	(unsigned int) 0xEF * 16777216

#define B3b11110000	(unsigned int) 0xF0 * 16777216
#define B3b11110001	(unsigned int) 0xF1 * 16777216
#define B3b11110010	(unsigned int) 0xF2 * 16777216
#define B3b11110011	(unsigned int) 0xF3 * 16777216
#define B3b11110100	(unsigned int) 0xF4 * 16777216
#define B3b11110101	(unsigned int) 0xF5 * 16777216
#define B3b11110110	(unsigned int) 0xF6 * 16777216
#define B3b11110111	(unsigned int) 0xF7 * 16777216
#define B3b11111000	(unsigned int) 0xF8 * 16777216
#define B3b11111001	(unsigned int) 0xF9 * 16777216
#define B3b11111010	(unsigned int) 0xFA * 16777216
#define B3b11111011	(unsigned int) 0xFB * 16777216
#define B3b11111100	(unsigned int) 0xFC * 16777216
#define B3b11111101	(unsigned int) 0xFD * 16777216
#define B3b11111110	(unsigned int) 0xFE * 16777216
#define B3b11111111	(unsigned int) 0xFF * 16777216





#endif /* ifndef BIT_H */