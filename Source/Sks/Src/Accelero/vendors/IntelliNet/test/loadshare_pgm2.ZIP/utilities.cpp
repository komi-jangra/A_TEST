//
// Current Utilities
//
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <mbstring.h>

#include <time.h>
#include <sys/types.h>
#include <sys/timeb.h>
#include <string.h>

#include "bit.h"
#include "TBLmacros.h"

#define ParmBuf 5000
#define NumOfParms 4

List1Parm(IPadr, ip, IPadrTbl);
List2Parm(IPadr, Port, iport, IPortAdrTbl);

//extern IPadrTbl *pAnyIPadrTbl, *pSrcIPadrTbl, *pDesIPadrTbl;
extern IPortAdrTbl *pClientIPortAdrTbl, *pServerIPortAdrTbl;
extern char OutputFile[64]; 
extern char *pOutputFile;
extern char RawFile[64];
extern char *pRawFile;



	KeyWordTbl (Parms, NumOfParms)
		KeyWordElm ("Client", KWiport+KWTable, pClientIPortAdrTbl)
		KeyWordElm ("Server", KWiport+KWTable, pServerIPortAdrTbl)
		KeyWordElm ("OUTPUT", KWString, OutputFile)
		KeyWordElm ("RAWFILE", KWString, RawFile)
	KeyWordEnd;

	struct KWParms *pParms = &Parms[0];
/* #include "PrtTCPerr.h" */

void GetParms( void );
int compstr (char *pS, char *pBuf);
int getvar(char * pL, int i, int *pV, int T);
int gettblvar(char * pL, int i, int *pV, int T);
char *ReadRecord( char *file_name, int record_size );
void PrtTCPerr (char *pstr, int errcode);
void WriteRawData( unsigned char * precord, int length);
int translateIP(char *pX);
short int translatePort(char *pX);
int lowerCaseCopy (char *pLstr, char *pUstr, int max);
char lowerCaseChar (char c1);

void
iTOa(int n, char s[]);
void
reverseString(char s[]);
int
strLen(char s[]);
int 
Convert_To_Hex (char *pbuf, int length);
void 
prtCharOnly (char *pbuf, int length);


/********************************************************************************************/
/*																							*/
/*	Read Configuration File and obtain parameters.											*/
/*																							*/
/********************************************************************************************/

void GetParms( void )
{

   FILE *stream;
/*   char list[ParmBuf];*/
   char *plist, c1, c2;
   int  i, i2, numread;

	// Allocate Memory for Tables

   pClientIPortAdrTbl = (IPortAdrTbl *) GlobalAlloc(GMEM_ZEROINIT, 10*sizeof(pClientIPortAdrTbl->iport));
   pServerIPortAdrTbl = (IPortAdrTbl *) GlobalAlloc(GMEM_ZEROINIT, 10*sizeof(pServerIPortAdrTbl->iport));


  
   plist = (char *) GlobalAlloc(GMEM_ZEROINIT, ParmBuf);

   if( (stream = fopen( "C:/LoadShare.cfg", "r+t" )) != NULL )
   {
      /* Attempt to read in 1000 characters */
      numread = fread( plist, sizeof( char ), ParmBuf, stream );
	  *(plist+numread) = (char) 0;
      printf( "Number of characters read = %d\n", numread );
	  if (numread < 1000)printf( "Contents of buffer =\n %s\n", plist );
	  else printf( "Contents of buffer =\n %.500s\n", plist );
      fclose( stream );
   } /* if */
   else
   {
      printf( "File could not be opened\n" );
	  exit(0);
   } /* else */

   for (i=0;i < numread;i++)
   {
	   for (i2=0;i2 < NumOfParms;i2++)
	   {
		   if (-1 == (int) ((pParms+i2)->pS))
		   {
			   printf("Invalid Command <%s>\n>", (plist+i));
			   exit (0);
		   } /* if */

		   c1 = lowerCaseChar(*(plist+i));
		   c2 = lowerCaseChar((char) *((pParms+i2)->pS));
		   if (c1 == (char) c2)
		   {
			   if (compstr ((pParms+i2)->pS, plist+i))
			   {
				   i = getvar(plist, i+strlen((pParms+i2)->pS), (pParms+i2)->pV, (pParms+i2)->T);
				   i2 = NumOfParms;
			   } /* if compstr */
		   } /* if first char eq */
	    } /* for i2 */
   } /* for i*/

   if (pClientIPortAdrTbl->cnt == 0 ||
	   pServerIPortAdrTbl->cnt < 2)
   {
	   printf("Insuffient Configuration information\n");
	   exit (0);
   } /* if */




} /* GetParms */

/********************************************************************************************/
/*																							*/
/*	Open a File and Write a specified number of bytes of data to it.						*/
/*																							*/
/********************************************************************************************/

void WriteData( char * precord, int length)
{
extern char OutputFile[64]; 
extern char *pOutputFile;

static FILE *pstream = 0;
static char file_name[64];
   unsigned int  i=0, i2=0, i3=0;
   if (precord == (char *) 0)
   {
	   if (pstream != 0) fclose( pstream );
	   pstream = 0;
	   return;
   } /* if */
   if (pstream == 0)
   {
	   if (precord != (char *) 0 && length == 0) strcpy((char *) &file_name,precord);
	   else strcpy((char *) &file_name,pOutputFile);
	   //
	   //Convert to UNIX style file name
	   //
	   for(i=0;i<strlen(file_name);i++)
	   {
		   if (file_name[i] == '\\') file_name[i] = '/';
	   } /* for */
	   //
	   // Open file in text mode:
	   //
	   if( (pstream = fopen( file_name, "w+t" )) == NULL )
	   {
		   printf( "OutPut File could not be opened\n" );
		   exit(0);
	   } /* if stream == NULL */
	   if (length == 0) return;
   } /* if stream == 0 */
	
   i3 = length;

   while (i3>0)
   {
	   /* Write characters to stream */
/*		precord +=i; */

	   i2 = fwrite( precord+i, sizeof( char ), i3, pstream );
	   i3=i3-i2;
	   i=i+i2;
   } /* while */
   
   fflush( pstream );
   
	return;

} /* WriteData */

/********************************************************************************************/
/*																							*/
/*	Compare two strings after converting them to lower case.								*/
/*																							*/
/********************************************************************************************/

int compstr (char *pS, char * pBuf)
{
	char buf1[100], buf2[100];
	int l1, l2;

	l1 = lowerCaseCopy (&buf1[0], pS, 100);
	l2 = lowerCaseCopy (&buf2[0], pBuf, 100);

	if (l1 != l2) return (0);

	if (0 == strncmp(&buf1[0], &buf2[0],l1))
	{
		return(1);
	} /* if 0 */
	return(0);

} /* compstr */

/********************************************************************************************/
/*																							*/
/*	Get Parameter value that follows KEYWORD and place into a Variable.						*/
/*																							*/
/********************************************************************************************/
int getvar(char * pL, int i, int *pV, int T)
{
	int i2;
	char X[100];
	char *pX;

	if (KWTable == (KWTable & T)) 
	{
		i = gettblvar(pL, i, pV, T ^ KWTable);
		return (i);
	} /* if */

	if (T == KWString) pX = (char *) pV;
	if (T != KWString) pX = &X[0];

	for (;*(pL+i) == ' '; i++);

	for (i2=0;*(pL+i) != ' '; i++, i2++)
	{
		if (*(pL+i) == (char) 0) break;
		if (*(pL+i) == '\n') break;
		if (*(pL+i) == '\r') break;
		*(pX+i2) = *(pL+i);
	} /* for i */

	*(pX+i2) = (char ) 0;

	if (i2 != 0)
	{
		if (T == KWInt) *pV = atoi(pX);
		if (T == KWDword) *pV = atoi(pX);
	} /* if */
	return (i);


} /* getvar */


/********************************************************************************************/
/*																							*/
/*	Open a file and Read a specified number of bytes.										*/
/*																							*/
/********************************************************************************************/

char *ReadRecord( char *file_name, int record_size )
{

static   FILE *stream = 0;
static   char list[5000];
   int	numread;

   if (stream == 0)
   {
	   ZeroMemory(&list[0], sizeof(list));
	   if( (stream = fopen( file_name, "r+t" )) == NULL )
	   {
		   printf( "File could not be opened\n" );
		   exit(0);
	   } /* if stream == NULL */
   } /* if stream == 0 */
   
   /* Attempt to read in 1000 characters */
   numread = fread( list, sizeof( char ), record_size, stream );
   if (numread <= 0)
   {
	   fclose( stream );
	   stream = 0;
	   return (ReadRecord(file_name, record_size));
   } /* if numread <= 0) */
   list[numread] = (char) 0;
   printf( "Size of Record read = %d\n", numread ); 
   printf( "Record buffer = %.100s\n", list ); 
   
   return (&list[0]);

} /* ReadRecord */

/********************************************************************************************/
/*																							*/
/*	Get Parameter value(s) that follow KEYWORD and place into a Table.						*/
/*																							*/
/********************************************************************************************/

int gettblvar(char * pL, int i, int *pV, int T)
{
	int i2;
	BOOL EOT=FALSE;
	char X[100], X2[100];
	Parm1Tbl *pTbl1;
	Parm2Tbl *pTbl2;
	char *pX, *pX2;
	pTbl1 = (Parm1Tbl *) *pV;
	pTbl2 = (Parm2Tbl *) *pV;



	while (!EOT)
	{
		if (T == KWString) 
		{
			pX = (char *) &(pTbl1)->parms[(pTbl1)->cnt].parm1;
		} /* if string */

		if (T != KWString) 
		{
			pX = &X[0];
			pX2 = &X2[0];
		} /* if not string */

		// Get first Parameter
		//
		for (;*(pL+i) == ' '; i++);

		for (i2=0;*(pL+i) != ' '; i++, i2++)
		{
			if (*(pL+i) == (char) 0) break;
			if (*(pL+i) == '\n') break;
			if (*(pL+i) == '\r') break;
			if (*(pL+i) == ',') break;
			if (*(pL+i) == ':') break;
			*(pX+i2) = *(pL+i);
		} /* for i */

		*(pX+i2) = (char ) 0;

		if (i2 != 0)
		{
			if (T == KWInt) (pTbl1)->parms[(pTbl1)->cnt].parm1 = atoi(pX);
			if (T == KWDword) (pTbl1)->parms[(pTbl1)->cnt].parm1 = atoi(pX);
			if (T == KWipadr) (pTbl1)->parms[(pTbl1)->cnt].parm1 = inet_addr(pX);
			if (T == KWiport) (pTbl2)->parms[(pTbl2)->cnt].parm1 = inet_addr(pX);
			pTbl1->cnt++;
		} /* if i2!=0 (any Parm?) */

		
		// if second parameter then get it
		//
		if (*(pL+i) == ':')
		{
			i++; /* get pass : */
			for (;*(pL+i) == ' '; i++);
			
			for (i2=0;*(pL+i) != ' '; i++, i2++)
			{
				if (*(pL+i) == (char) 0) break;
				if (*(pL+i) == '\n') break;
				if (*(pL+i) == '\r') break;
				if (*(pL+i) == ',') break;
				*(pX2+i2) = *(pL+i);
			} /* for i */
			
			*(pX2+i2) = (char ) 0;
			
			if (T == KWiport  && i2!=0)
			{
				(pTbl2)->parms[((pTbl2)->cnt)-1].parm2 = (int) atoi(pX2);
			} /* if ip adr */

		} /* if : (second parm) */

		if (*(pL+i) == (char) 0) EOT=TRUE;
		if (*(pL+i) == '\n') EOT=TRUE;
		if (*(pL+i) == '\r') EOT=TRUE;


	} /* while */
	return (i);


} /* gettblvar */


/********************************************************************************************/
/*																							*/
/*	Write RAW data into a RAWRECORD in a file												*/
/*																							*/
/********************************************************************************************/

void WriteRawData( unsigned char * precord, int length)
{

extern char RawFile[64];
extern char *pRawFile;

static FILE *pstream = 0;
static char file_name[64];
   unsigned int  len, i=0, i2=0, i3=0;
   RAWRECORD *pbuf;


   if (precord == (unsigned char *) 0)
   {
	   if (pstream != 0) fclose( pstream );
	   pstream = 0;
	   return;
   } /* if */
   if (pstream == 0)
   {
	   if (precord != (unsigned char *) 0 && length == 0) strcpy((char *) &file_name, (char *) precord);
	   else strcpy((char *) &file_name, (char *) pRawFile);
	   //
	   //Convert to UNIX style file name
	   //
	   for(i=0;i<strlen(file_name);i++)
	   {
		   if (file_name[i] == '\\') file_name[i] = '/';
	   } /* for */
	   //
	   // Open file in text mode:
	   //
	   if( (pstream = fopen( file_name, "wb" )) == NULL )
	   {
		   printf( "OutPut File could not be opened\n" );
		   exit(0);
	   } /* if stream == NULL */
	   if (length == 0) return;
   } /* if stream == 0 */

   len = length + sizeof(RAWRECORD)-sizeof(pbuf->data);
   
   pbuf = (RAWRECORD *) GlobalAlloc(GMEM_ZEROINIT, len+12);
   memcpy(&pbuf->data, precord, length);


	for (i=0;i<9;i++) pbuf->tmpbuf1[i] = ' ';
	for (i=0;i<9;i++) pbuf->tmpbuf2[i] = ' ';
    /* Display operating system-style date and time. */
    _strtime( pbuf->tmpbuf2 );
    _strdate( pbuf->tmpbuf1 );
	pbuf->length = length;
	pbuf->recordmarker = 0xFDFD;

	
   i3 = len;
   i = 0;

   while (i3>0)
   {
	   /* Write characters to stream */
/*		precord +=i; */

	   i2 = fwrite(((char *)pbuf)+i, sizeof( char ), i3, pstream );
	   i3=i3-i2;
	   i=i+i2;
   } /* while */
   
   fflush( pstream );
   GlobalFree(pbuf);
   
	return;

} /* WriteRawData */

/********************************************************************************************/
/*																							*/
/* Convert a IP Address in the form of a Text String (I.E. 192.68.20.116) to an 4 byte		*/
/*		binary address.																		*/
/*																							*/
/*	Could use the following two functions to convert between string and int versions of adr	*/
/*	(in_addr) ipadr = inet_addr(dotted_string_ip_adr);										*/
/*	dotted_string_ip_adr = inet_ntoa ((in_addr) ipadr);										*/
/*																							*/
/*																							*/
/********************************************************************************************/

int translateIP(char *pX)
{
	int i, i2=0, *pI;
	unsigned char buf[16];
	unsigned char ipadr[4];
	unsigned char n=0;
	unsigned char *pY;

	pY = (unsigned char *) pX;
	
	for (i=0;*(pY+i)!=' ' && *(pY+i)!='\n' && *(pY+i)!='\r' && *(pY+i)!='\t' && *(pY+i)!= (char) 0;i++)
	{
		if (i>16)
		{
			printf ("Invalid IP address <%.16s>\n", pY);
			exit (0);
		} /* if */
		if (*(pY+i)== '.') buf[i2++] = (char) 0;
		 else if (*(pY+i) >= '0' && *(pY+i) <= '9') buf[i2++] = *(pY+i);
		 else 
		 {
			 printf ("Invalid IP address <%.16s>\n", pY);
			 exit (0);
		 } /* else */
	} /* for */
	buf[i2++] = (char) 0;
	pY = (unsigned char *) &buf[0];
	for (n=0,i=0; buf[i] != (unsigned char) 0;i++)
		n = 10* n + buf[i] - '0';
	ipadr[3] = n;

	for (n=0,i++; buf[i] != (unsigned char) 0;i++)
		n = 10* n + buf[i] - '0';
	ipadr[2] = n;

	for (n=0,i++; buf[i] != (unsigned char) 0;i++)
		n = 10* n + buf[i] - '0';
	ipadr[1] = n;

	for (n=0,i++; buf[i] != (unsigned char) 0;i++)
		n = 10* n + buf[i] - '0';
	ipadr[0] = n;

	pI = (int *) &ipadr[0];
	i = *(pI);

	return (i);

} /* translateIP */



/********************************************************************************************/
/*																							*/
/*	Convert a IP Port Number from a text string to a short integer.							*/
/*																							*/
/********************************************************************************************/

short int translatePort(char *pX)
{
	int i, i2=0;
	short int n=0;
	unsigned char buf[6];
	unsigned char *pY;

	pY = (unsigned char *) pX;
	
	for (i=0;*(pY+i)!=' ' && *(pY+i)!='\n' && *(pY+i)!='\r' && *(pY+i)!='\t' && *(pY+i)!= (char) 0;i++)
	{
		if (i>5)
		{
			printf ("Invalid Port Number <%.5s>\n", pY);
			exit (0);
		} /* if */
		if (*(pY+i) >= '0' && *(pY+i) <= '9') buf[i2++] = *(pY+i);
		 else 
		 {
			 printf ("Invalid Port Number <%.6s>\n", pY);
			 exit (0);
		 } /* else */
	} /* for */
	buf[i2++] = (char) 0;

	for (n=0,i=0; buf[i] != (char) 0;i++)
		n = 10* n + buf[i] - '0';

	return (n);

} /* translatePort */

/********************************************************************************************/
/*																							*/
/*	Convert a text parameter in a string to a lower case NULL terminated string.			*/
/*																							*/
/********************************************************************************************/
int lowerCaseCopy (char *pLstr, char *pUstr, int max)
{
	char *ptbl ="abcdefghijklmnopqrstuvwxyz";
	int i;

	for (i=0;i<max;i++)
	{
		if (*(pUstr+i) == (char) 0) break;
		if (*(pUstr+i) == ' ') break;
		if (*(pUstr+i) == '\n') break;
		if (*(pUstr+i) == '\r') break;
		if (*(pUstr+i) == '\t') break;
		if (*(pUstr+i) < ' ') break;
		if (*(pUstr+i) > '~') break;
		if (*(pUstr+i) >= 'A'  && *(pUstr+i) <= 'Z')
			*(pLstr+i) = *(ptbl) + (*(pUstr+i) - 'A');
		else *(pLstr+i) = *(pUstr+i);
	} /* for */
	*(pLstr+i) = (char) 0;
	return (i);
} /* lowerCaseCopy */


/********************************************************************************************/
/*																							*/
/*	Convert Upper Case character to Lower Case												*/
/*																							*/
/********************************************************************************************/
char lowerCaseChar (char c1)
{
	char *ptbl ="abcdefghijklmnopqrstuvwxyz";
	char c2;

	if (c1 >= 'A'  && c1 <= 'Z')
		c2 = *(ptbl) + (c1 - 'A');
	else c2 = c1;

	return (c2);
} /* lowerCaseChar */


/********************************************************************************************/
/*																							*/
/*	Convert an Integer to a NULL terminated string											*/
/*																							*/
/********************************************************************************************/
void
iTOa(int n, char s[])
{
	int i, sign;

	if ((sign = n) < 0)	/* record sign */
	{
		n = -n;			/* Make Positive */
	} /* if */
	i = 0;
	do 
	{				/* generate digits in reverse order */
		s[i++] = n % 10 + '0';	/* get next digit */
	}
	while ((n /= 10) > 0);	/* delete it */
	if (sign < 0)
	{
		s[i++] = '-';
	} /* if */
	s[i] = '\0';
	reverseString(s);
} /* iTOa */

/********************************************************************************************/
/*																							*/
/*	Reverse the order of the bytes in a string												*/
/*																							*/
/********************************************************************************************/
void
reverseString(char s[])
{
	int c, i, j;
	for (i = 0, j = strLen(s) -1; i < j; i++, j--)
	{
		c = s[i];
		s[i] = s[j];
		s[j] = c;
	} /* for */
} /* reverseString */

/********************************************************************************************/
/*																							*/
/*	Return the length of a NULL terminated string											*/
/*																							*/
/********************************************************************************************/
int
strLen(char s[])
{
	int i = 0;

	while (s[i] != '\0')
	{
		++i;
	} /* while */

	return(i);
} /* strLen */

//
// Function: prtCharOnly
//
// Description:
//    This function simply prints out a text only characters 
//    of a series of bytes.
//
void prtCharOnly (char *pbuf, int length)
{
	int i, i2, i3, len;
	char *pbuf2, *pbuf3;
	char retChar = '\n', *pretChar;
	pretChar = &retChar;

	pbuf3 = pbuf2 = (char *) GlobalAlloc (GMEM_ZEROINIT, length);

	for (i=0;i<length;i++)
	{
		if (*(pbuf+i) < (char) 32) *(pbuf2+i) = (char) 32;
		else if (*(pbuf+i) > (char) 126) *(pbuf2+i) = (char) 32;
		else *(pbuf2+i) = *(pbuf+i);
	} /* for */

	i = 0;
	len = length;
	 while (i<length)
	{
		if (len >= 80) i3 = 80;
		else i3 = len;
		for (i2=0;i2<len;i2++)
		{
			if (*(pbuf2+i2+i) == ' ') i3 = i2;
		} /* for */
		WriteData(pbuf3, i3);
		WriteData(pretChar, 1);
		pbuf3 += (i3+1);
		i += (i3+1);
		if (length-i < len) len = length-i;
	} /* while */

	 GlobalFree(pbuf2);

	return;

} /* prtCharOnly */



//
// Function: Convert_To_Hex
//
// Description:
//    This function simply prints out a series of bytes
//    as hexadecimal digits.
//
int 
Convert_To_Hex (char *pbuf, int length)
{
	int i, i2, i3;
	unsigned char HexTbl[18] = {"0123456789ABCDEF"};
	char *phex_out = 0;

	unsigned char byte, lownibble, lowbits, highnibble, highbits;
	phex_out = (char *) GlobalAlloc (GMEM_ZEROINIT, (5+length)*2);

	lowbits = (unsigned char) 15;

	highbits = (unsigned char) 240;
	for (i3=0;i3<length;i3+=32)
	{
	
		for (i=0,i2=0;i< 32;i++,i2=i2+2)
		{
			if ((i+i3)>=length) continue;
			byte = (unsigned char) *(pbuf+i+i3);
			highnibble = byte & highbits;
			highnibble = highnibble >> 4;
			lownibble  = byte & lowbits;
			*(phex_out+i2) = HexTbl[highnibble];
			*(phex_out+i2+1) = HexTbl[lownibble];
			if (((1+i)/4)*4 == (1+i)) 
			{
				*(phex_out+i2+2) = (unsigned char) ' ';
				i2++;
			} /* if */

		} /* for i */

		if (i3==0)	WriteData("Hex Output:\n", strlen("Hex Output:\n"));
		
		WriteData( phex_out, strlen(phex_out));
		WriteData( "\n", strlen("\n"));


	} /* for i3 */

	 GlobalFree(phex_out);

	return (0);
} /* Convert_To_Hex */
