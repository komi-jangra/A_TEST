// Module Name: Current LoadShare.cpp
//
// Description:
//
//	This program accepts a connection from a Client and load shares the traffic 
//	with two Servers that it has connected to as a Client.
//
//    This sample illustrates how to develop a simple echo server Winsock
//    application using the completeion port I/O model. This 
//    sample is implemented as a console-style application and simply prints
//    messages when connections are established and removed from the server.
//    The application listens for TCP connections on port 5150 and accepts them
//    as they arrive. When this application receives data from a client, it
//    simply echos (this is why we call it an echo server) the data back in
//    it's original form until the client closes the connection.
//
// Compile:
//
//    cl -o LoadShare LoadShare.cpp ws2_32.lib
//
// Command Line Options:
//
//    LoadShare.exe 
//

#include <winsock2.h>
#include <windows.h>
#include <stdio.h>

#include <stdlib.h>
#include "bit.h"
#include "TBLmacros.h"


#define PORT 35338
#define DATA_BUFSIZE 8192

typedef struct
{
   OVERLAPPED Overlapped;
   WSABUF DataBuf;
   CHAR Buffer[DATA_BUFSIZE];
   DWORD BytesSEND;
   DWORD BytesRECV;
   SOCKET SendSocket;
   SOCKET RecvSocket;
} PER_IO_OPERATION_DATA;

typedef struct 
{
   SOCKET Socket;
} PER_HANDLE_DATA;

typedef struct 
{
   int nextServer;
   SOCKET ClientSocket;
   SOCKET Server1Socket;
   SOCKET Server2Socket;
} SOCKET_TBL;

typedef struct
{
    SOCKET      sServer;
	char		ipAdr[4];	        // Server to connect to
	int			iPort;				// Port on server to connect to
    struct		sockaddr_in server;
	PER_HANDLE_DATA *pPerHandleData;
	HANDLE		pCompletionPort;
	WSABUF		CalleeData;

}
SERVER_CB;

List2Parm(IPadr, Port, iport, IPortAdrTbl);


IPortAdrTbl *pClientIPortAdrTbl, *pServerIPortAdrTbl;
char OutputFile[64]="C:/OutFile.txt", *pOutputFile=&OutputFile[0];
char RawFile[64]="C:/RawOutFile.txt", *pRawFile=&RawFile[0];

#include "PrtTCPerr.h"

int 
ConnectServer(SERVER_CB *pSCB);
void
DisConnectServer(SERVER_CB *pSCB);
void
AssociateSocket(SERVER_CB *pSCB);
void
ReceiveSocket(SERVER_CB *pSCB);
void
buildSCB(void *pTbl, int index, SERVER_CB *pSCB, HANDLE pCompletionPortID);
void
ReceiveSocket();
void
GetParms();
SOCKET
SelectSocket(SOCKET receivedSocket, char *pstr);
void 
WriteRawData( unsigned char * precord, int length);
int 
Convert_To_Hex (char *pbuf, int length);
void 
prtCharOnly (char *pbuf, int length);
void 
PrtTCPerr (char *pstr, int errcode);
char *
IdentifySocket(SOCKET theSocket);

DWORD WINAPI 
ServerWorkerThread(LPVOID pCompletionPortID);
char 
lowerCaseChar (char c1);
int 
compstr (char *pS, char *pBuf);
void 
WriteData( char * precord, int length);


#define SHUTD_SW		b00000001
#define BYE_SW			b00000001
#define EXIT_SW			b00000001
#define STOP_SW			b00000010
#define LOADSHARE_SW	b00000100
#define FLIP_SW			b00001000


SOCKET_TBL Socket_tbl, *pSocket_tbl = &Socket_tbl;

int AllSocketsCnts=0;
SOCKET AllSockets[100];
char  prtbuf[101], *pbuf;
int Record_Count=0;
unsigned char Command_SW = LOADSHARE_SW;

#define AddSocket(S) AllSockets[AllSocketsCnts++] = S;



//
// Accepts Commands while processing
//
DWORD WINAPI CommandThread(LPVOID Command_SW)
{
	unsigned char *pSW, *pV, stopbit=STOP_SW, exitbit=EXIT_SW;
	unsigned char lsbit=LOADSHARE_SW, flipbit=FLIP_SW;
	int i, i2;
	char c1, c2;
#define NumOfCmds 9
	


	char buf[90];
	KeyWordTbl (Parms, NumOfCmds)
		KeyWordElm ("STOP", KWBool, stopbit)
		KeyWordElm ("GO", KWinvert+KWBool, stopbit)
		KeyWordElm ("BYE", KWBool, exitbit)
		KeyWordElm ("EXIT", KWBool, exitbit)
		KeyWordElm ("LOADSHARE", KWBool, lsbit)
		KeyWordElm ("LS", KWBool, lsbit)
		KeyWordElm ("NOLOADSHARE", KWinvert+KWBool, lsbit)
		KeyWordElm ("NLS", KWBool+KWinvert, lsbit)
		KeyWordElm ("FLIP", KWBool, flipbit)
	KeyWordEnd;

	struct KWParms *pParms = &Parms[0];

	pSW = (unsigned char *) Command_SW;
	printf ("Command Processor Started\n");
	printf ("Following Commands accepted:\nSTOP\nGO\nLS\nNLS\nFLIP\nBYE\nEXIT\n> ");
	while (EXIT_SW !=(*pSW & EXIT_SW))
	{
		for(i=0;i<90;i++)buf[i] = ' ';
		for(i=0;buf[i]!= (char) 0;i++)
		{
			buf[i] = getchar();
			if (buf[i] == '\n' || buf[i] == '\r') break;
			if (i >= 80)
			{
				printf("Too Many characters\n>");
				i = 0;
			} /* if */
		} /* for */
		buf[i] = (char) 0;
/*		i = compstr (&"EXIT", &buf[0]);
		if (i == 1) *pSW = (unsigned char) EXIT_SW;
		else printf("Try Again <%s>\n> ", buf); */
		for (i2=0;i2 < NumOfCmds;i2++)
		{
			if (-1 == (int) ((pParms+i2)->pS))
			{
				printf("Invalid Command\n>");
				i = 0;
				break;
			} /* if */

			c1 = lowerCaseChar(buf[0]);
			c2 = lowerCaseChar((char) *((pParms+i2)->pS));

			if (c1 == c2)
			{
				if (compstr ((pParms+i2)->pS, &buf[0]))
				{
					pV = (unsigned char *) (pParms+i2)->pV;

					if ((KWBool+KWinvert) == ((KWBool+KWinvert) & (pParms+i2)->T ))
					{
						*(pSW) = *(pSW) ^ *(pV);
						i = 0;
						printf("Command Executed\n>");
						break;
					} /* if */

					if ((KWBool) == ((KWBool) & (pParms+i2)->T ))
					{
						*(pSW) = *(pSW) | *(pV);
						i = 0;
						printf("Command Executed\n>");
						break;
					} /* if */
			   
				} /* if compstr */
			} /* if first char */
		} /* for i2 */


	} /* while */


	for (i=0;i<=10;i++)
	{
		if (EXIT_SW !=(*pSW & EXIT_SW)) break;
/*		sleep (1000); */
	} /* for */
	printf ("Close Window to Terminate\n");
	return (0);

} /* CommandThread */


void main(void)
{
   SOCKADDR_IN InternetAddr;
   SOCKET Listen;
   SOCKET Accept;
   HANDLE pCompletionPort;
   SYSTEM_INFO SystemInfo;
   PER_HANDLE_DATA *pPerHandleData;
   PER_IO_OPERATION_DATA *pPerIoData;
   int i;
   DWORD RecvBytes;
   DWORD Flags;
   DWORD ThreadID;
   WSADATA wsaData;
   DWORD Ret;
   HANDLE		  hThread;
   DWORD		  dwThreadID;

   SERVER_CB ServerCB1, ServerCB2, *pServerCB1 = &ServerCB1, *pServerCB2 = &ServerCB2;

   GetParms();	// Read Parameters in from Configuration File

	// Open Trace OutPut file
	//
	WriteData( OutputFile, 0);
	strcpy(prtbuf,"This Utility provided by Patrick J. Kelly III @ pjk3@lcc.net\n");
	WriteData( prtbuf, strlen(prtbuf));

   if ((Ret = WSAStartup(0x0202, &wsaData)) != 0)
   {
      printf("WSAStartup failed with error %d\n", Ret);
      return;
   } /* if */


   // Setup an I/O completion port.

   if ((pCompletionPort = CreateIoCompletionPort(INVALID_HANDLE_VALUE, NULL, 0, 0)) == NULL)
   {
      WSACleanup();
      printf( "CreateIoCompletionPort failed with error: %d\n", GetLastError());
      return;
   } /* if */


   buildSCB(pServerIPortAdrTbl, 0, pServerCB1, pCompletionPort);
   buildSCB(pServerIPortAdrTbl, 1, pServerCB2, pCompletionPort);


   if ((Ret = ConnectServer(pServerCB1)) != 0)
   {
      WSACleanup();
      printf("ConnectServer failed while connecting to Server 1 with error %d\n", Ret);
      return;
   } /* if */

   if ((Ret = ConnectServer(pServerCB2)) != 0)
   {
	  DisConnectServer(&ServerCB1);
      WSACleanup();
      printf("ConnectServer failed while connecting to Server 2 with error %d\n", Ret);
      return;
   } /* if */

	pSocket_tbl->nextServer = 1;
	pSocket_tbl->Server1Socket = pServerCB1->sServer;
	pSocket_tbl->Server2Socket = pServerCB2->sServer;

	AssociateSocket(pServerCB1);
	AssociateSocket(pServerCB2);

	ReceiveSocket(pServerCB1);
	ReceiveSocket(pServerCB2);

   // Determine how many processors are on the system.

   GetSystemInfo(&SystemInfo);

   // Create worker threads based on the number of processors available on the
   // system. Create six worker threads for each processor.

   for(i = 0; i < (int) SystemInfo.dwNumberOfProcessors * 6; i++)
   {
      HANDLE ThreadHandle;

      // Create a server worker thread and pass the completion port to the thread.

      if ((ThreadHandle = CreateThread(NULL, 0, ServerWorkerThread, pCompletionPort,
         0, &ThreadID)) == NULL)
      {
		 DisConnectServer(&ServerCB1);
		 DisConnectServer(&ServerCB2);
		 WSACleanup();
         printf("CreateThread() failed with error %d\n", GetLastError());
         return;
      } /* if */

      // Close the thread handle
      CloseHandle(ThreadHandle);
   } /* for */

   // Create a listening socket

   if ((Listen = WSASocket(AF_INET, SOCK_STREAM, 0, NULL, 0,
      WSA_FLAG_OVERLAPPED)) == INVALID_SOCKET)
   {
//      printf("WSASocket() failed with error %d\n", WSAGetLastError());
   		PrtTCPerr ("WSASocket", WSAGetLastError());

      return;
   }  /* if */

   AddSocket(Listen);

   InternetAddr.sin_family = AF_INET;
   InternetAddr.sin_addr.s_addr = htonl(INADDR_ANY);
   InternetAddr.sin_port = htons(PORT);

   if (bind(Listen, (PSOCKADDR) &InternetAddr, sizeof(InternetAddr)) == SOCKET_ERROR)
   {
//      printf("bind() failed with error %d\n", WSAGetLastError());
   		PrtTCPerr ("WSASocket", WSAGetLastError());

      return;
   } /* if */

   // Prepare socket for listening

   if (listen(Listen, 5) == SOCKET_ERROR)
   {
//      printf("listen() failed with error %d\n", WSAGetLastError());
   		PrtTCPerr ("Listen", WSAGetLastError());
      return;
   } /* if */

	//
	// Start Command Thread
	//
	hThread = CreateThread(NULL, 0,CommandThread, 
		(LPVOID) &Command_SW, 0, &dwThreadID);
	if (hThread == NULL)
	{
		printf("CreatThread() failed %d\n", GetLastError());
		exit (0);
	} /* if */


   // Accept connections and assign to the completion port.


   while (EXIT_SW != (Command_SW & EXIT_SW))
   {
      if ((Accept = WSAAccept(Listen, NULL, NULL, NULL, 0)) == SOCKET_ERROR)
      {
//         printf("WSAAccept() failed with error %d\n", WSAGetLastError());
   		PrtTCPerr ("WSAAccept", WSAGetLastError());
         return;
      } /* if */

      // Create a socket information structure to associate with the socket
      if ((pPerHandleData = (PER_HANDLE_DATA *) GlobalAlloc(GPTR, 
         sizeof(PER_HANDLE_DATA))) == NULL)
      {
         printf("GlobalAlloc() failed with error %d\n", GetLastError());
         return;
      } /* if */

      // Associate the accepted socket with the original completion port.

      printf("Socket number %d connected\n", Accept);
      pPerHandleData->Socket = Accept;
	  pSocket_tbl->ClientSocket = Accept;

      if (CreateIoCompletionPort((HANDLE) Accept, pCompletionPort, (DWORD) pPerHandleData,
         0) == NULL)
      {
         printf("CreateIoCompletionPort failed with error %d\n", GetLastError());
         return;
      } /* if */

	   AddSocket(Accept);

      // Create per I/O socket information structure to associate with the 
      // WSARecv call below.

      if ((pPerIoData = (PER_IO_OPERATION_DATA *) GlobalAlloc(GPTR,
          sizeof(PER_IO_OPERATION_DATA))) == NULL)
      {
         printf("GlobalAlloc() failed with error %d\n", GetLastError());
         return;
      } /* if */

      ZeroMemory(&(pPerIoData->Overlapped), sizeof(OVERLAPPED));
      pPerIoData->BytesSEND = 0;
      pPerIoData->BytesRECV = 0;
      pPerIoData->DataBuf.len = DATA_BUFSIZE;
      pPerIoData->DataBuf.buf = pPerIoData->Buffer;
	  pPerIoData->SendSocket = NULL;
	  pPerIoData->RecvSocket = NULL;

      Flags = 0;

      if (WSARecv(Accept, &(pPerIoData->DataBuf), 1, &RecvBytes, &Flags,
         &(pPerIoData->Overlapped), NULL) == SOCKET_ERROR)
      {
         if (WSAGetLastError() != ERROR_IO_PENDING)
         {
//            printf("WSARecv() failed with error %d\n", WSAGetLastError());
	   		PrtTCPerr ("WSARecv", WSAGetLastError());

            return;
         } /* if */
      } /* if */
   } /* while */\

    // Cleanup
    //
	for (i = 0; i < AllSocketsCnts; i++)
	{
		closesocket(AllSockets[i]);
	} /* for */

	WriteRawData(0,0);	// Closefile
	WriteData(0,0);	// Close File

    WSACleanup();
    return;
} /* main */

DWORD WINAPI ServerWorkerThread(LPVOID pCompletionPortID)
{
   HANDLE pCompletionPort = (HANDLE) pCompletionPortID;
   DWORD BytesTransferred;
//   OVERLAPPED *pOverlapped;
   PER_HANDLE_DATA *pPerHandleData;
   PER_IO_OPERATION_DATA *pPerIoData;
   DWORD SendBytes, RecvBytes;
   DWORD Flags;
   SOCKET SendSocket;
   SOCKET RecvSocket;
   char *psrc, *pdest;
   bool recFlag = false;

   while(TRUE)
   {
		
      if (GetQueuedCompletionStatus(pCompletionPort, &BytesTransferred,
         (LPDWORD)&pPerHandleData, (OVERLAPPED **) &pPerIoData, INFINITE) == 0)
      {
         printf("GetQueuedCompletionStatus failed with error %d\n", GetLastError());
         return 0;
      } /* if */


      // First check to see if an error has occured on the socket and if so
      // then close the socket and cleanup the SOCKET_INFORMATION structure
      // associated with the socket.

      if (BytesTransferred == 0)
      {
         printf("Closing socket %d\n", pPerHandleData->Socket);

         if (closesocket(pPerHandleData->Socket) == SOCKET_ERROR)
         {
//            printf("closesocket() failed with error %d\n", WSAGetLastError());
	   		PrtTCPerr ("closesocket", WSAGetLastError());

            return 0;
         } /* if */

         GlobalFree(pPerHandleData);
         GlobalFree(pPerIoData);
         continue;
      } /* if */

      // Check to see if the BytesRECV field equals zero. If this is so, then
      // this means a WSARecv call just completed so update the BytesRECV field
      // with the BytesTransferred value from the completed WSARecv() call.

      if (pPerIoData->BytesRECV == 0)
      {
		 Record_Count++;
         pPerIoData->BytesRECV = BytesTransferred;
         pPerIoData->BytesSEND = 0;
		 pPerIoData->RecvSocket = RecvSocket = pPerHandleData->Socket;
		 pPerIoData->SendSocket = SendSocket = SelectSocket(pPerHandleData->Socket, pPerIoData->Buffer);
		 recFlag = true;
		 //Dump the Data to File
		 WriteRawData((unsigned char *)&(pPerIoData->Buffer[0]), BytesTransferred);

		 psrc = IdentifySocket(RecvSocket);
		 pdest = IdentifySocket(SendSocket);

		 sprintf(prtbuf, "Record Count = %d Src %s - Dest %s \n", Record_Count, psrc, pdest);
		 WriteData( prtbuf, strlen(prtbuf));
		 Convert_To_Hex (pPerIoData->Buffer, BytesTransferred);
		 WriteData( "Character Data:\n", strlen("Character Data:\n"));
		 prtCharOnly ((char *) pPerIoData->Buffer, BytesTransferred);
      } /* if */
      else
      {
         pPerIoData->BytesSEND += BytesTransferred;

      } /* else */

      if (pPerIoData->BytesRECV > pPerIoData->BytesSEND)
      {
		  if (!recFlag)
		  {
			  SendSocket = pPerIoData->SendSocket;
		  } /* if */

         // Post another WSASend() request.
         // Since WSASend() is not gauranteed to send all of the bytes requested,
         // continue posting WSASend() calls until all received bytes are sent.

         ZeroMemory(&(pPerIoData->Overlapped), sizeof(OVERLAPPED));

         pPerIoData->DataBuf.buf = pPerIoData->Buffer + pPerIoData->BytesSEND;
         pPerIoData->DataBuf.len = pPerIoData->BytesRECV - pPerIoData->BytesSEND;

         if (WSASend(SendSocket, &(pPerIoData->DataBuf), 1, &SendBytes, 0,
            &(pPerIoData->Overlapped), NULL) == SOCKET_ERROR)
         {
            if (WSAGetLastError() != ERROR_IO_PENDING)
            {
//               printf("WSASend() failed with error %d\n", WSAGetLastError());
		   		PrtTCPerr ("WSASend", WSAGetLastError());
               return 0;
            } /* if */
         } /* if */
      } /* if */
      else
      {

         pPerIoData->BytesRECV = 0;
		 RecvSocket = pPerIoData->RecvSocket;
         // Now that there are no more bytes to send post another WSARecv() request.

         Flags = 0;
         ZeroMemory(&(pPerIoData->Overlapped), sizeof(OVERLAPPED));

         pPerIoData->DataBuf.len = DATA_BUFSIZE;
         pPerIoData->DataBuf.buf = pPerIoData->Buffer;
		 pPerIoData->SendSocket = NULL;
		 pPerIoData->RecvSocket = NULL;

         if (WSARecv(RecvSocket, &(pPerIoData->DataBuf), 1, &RecvBytes, &Flags,
            &(pPerIoData->Overlapped), NULL) == SOCKET_ERROR)
         {
            if (WSAGetLastError() != ERROR_IO_PENDING)
            {
//               printf("WSARecv() failed with error %d\n", WSAGetLastError());
		   		PrtTCPerr ("WSARecv", WSAGetLastError());
               return 0;
            } /* if */
         } /* if */
      } /* else */
   } /* while */
} /* ServerWorkerThread */


// 
// Function: ConnectServer
//
// Description:
//    ConnectServer thread of execution. Initialize Winsock, parse the 
//    command line arguments, create a socket, connect to the 
//    server, and then send and receive data.
//
int ConnectServer(SERVER_CB *pSCB)
{

    //
    // Create the socket, and attempt to connect to the server
    //
    pSCB->sServer = WSASocket(AF_INET, SOCK_STREAM, IPPROTO_TCP, NULL, 0, WSA_FLAG_OVERLAPPED);
    if (pSCB->sServer == INVALID_SOCKET)
    {
//        printf("socket() failed: %d\n", WSAGetLastError());
   		PrtTCPerr ("WSASocket", WSAGetLastError());
        return 1;
    } /* if */

   AddSocket(pSCB->sServer);
	
//    if (WSAConnect(pSCB->sServer, (struct sockaddr *)&(pSCB->server), 
//        sizeof(pSCB->server), NULL, &(pSCB->CalleeData), NULL, NULL) == SOCKET_ERROR)

    if (connect(pSCB->sServer, (struct sockaddr *)&(pSCB->server), 
        sizeof(pSCB->server)) == SOCKET_ERROR)
    {
//        printf("connect() failed: %d\n", WSAGetLastError());
   		PrtTCPerr ("WSAConnect", WSAGetLastError());
        return 1;
    } /* if */
    return 0;
} /* ConnectServer */

void
DisConnectServer(SERVER_CB *pSCB)
{
    closesocket(pSCB->sServer);

} /* DisConnectServer */

void
AssociateSocket(SERVER_CB *pSCB)
{

	// Associate the accepted socket with the original completion port.

	printf("Socket number %d connected\n", pSCB->sServer);
	pSCB->pPerHandleData->Socket = pSCB->sServer;

	if (CreateIoCompletionPort((HANDLE) pSCB->sServer, pSCB->pCompletionPort, (DWORD) pSCB->pPerHandleData,
		0) == NULL)
	{
		printf("CreateIoCompletionPort failed with error %d\n", GetLastError());
		return;
	} /* if */

} /* AssociateSocket */

void
ReceiveSocket(SERVER_CB *pSCB)
{
	int ret = 0;
	DWORD Flags = 0;
	DWORD RecvBytes = 0;
	PER_IO_OPERATION_DATA *pPerIoData = NULL;

    // receive data 
    //
    // Create per I/O socket information structure to associate with the 
    // WSARecv call below.

	if ((pPerIoData = (PER_IO_OPERATION_DATA *) GlobalAlloc(GPTR,
		sizeof(PER_IO_OPERATION_DATA))) == NULL)
	{
		printf("GlobalAlloc() failed with error %d\n", GetLastError());
		return;
	} /* if */

	ZeroMemory(&(pPerIoData->Overlapped), sizeof(OVERLAPPED));
	pPerIoData->BytesSEND = 0;
	pPerIoData->BytesRECV = 0;
	pPerIoData->DataBuf.len = DATA_BUFSIZE;
	pPerIoData->DataBuf.buf = pPerIoData->Buffer;
	pPerIoData->SendSocket = NULL;
	pPerIoData->RecvSocket = NULL;

	Flags = 0;

	if (WSARecv(pSCB->sServer, &(pPerIoData->DataBuf), 1, &RecvBytes, &Flags,
		&(pPerIoData->Overlapped), NULL) == SOCKET_ERROR)
	{
		if (WSAGetLastError() != ERROR_IO_PENDING)
		{
//			printf("WSARecv() failed with error %d\n", WSAGetLastError());
	   		PrtTCPerr ("WSARecv", WSAGetLastError());
			return;
		} /* if */
	} /* if */

    return;
} /* ReceiveSocket */
/*
 * Socket address, internet style.
 *
struct sockaddr_in {
        short   sin_family;
        u_short sin_port;
        struct  in_addr sin_addr; // 4 bytes
        char    sin_zero[8];
};
 */

void
buildSCB(void *pV, int index, SERVER_CB *pSCB, HANDLE pCompletionPortID)
{

	Parm2Tbl *pTbl;
	pTbl = (Parm2Tbl *) pV;

	memcpy(&(pSCB->ipAdr),&(pTbl->parms[index].parm1), sizeof(pSCB->ipAdr));
	pSCB->iPort =pTbl->parms[index].parm2;
	pSCB->pCompletionPort = pCompletionPortID;

    pSCB->server.sin_family = AF_INET;
    pSCB->server.sin_port = htons(pSCB->iPort);
    memcpy(&(pSCB->server.sin_addr.s_addr), &(pSCB->ipAdr), sizeof(pSCB->server.sin_addr.s_addr));
	ZeroMemory(&(pSCB->server.sin_zero), sizeof(pSCB->server.sin_zero));

	// Create a socket information structure to associate with the socket
	if ((pSCB->pPerHandleData = (PER_HANDLE_DATA *) GlobalAlloc(GPTR, 
		sizeof(PER_HANDLE_DATA))) == NULL)
	{
		printf("GlobalAlloc() failed with error %d\n", GetLastError());
		return;
	} /* if */


} /* buildSCB */


SOCKET
SelectSocket(SOCKET receivedSocket, char *pstr)
{
	SOCKET SendSocket;
	char xstr[]="ISS7SSI", *pxstr=&xstr[0];

	printf("@ Entry: rec %d, srv1 %d, srv2 %d, nxt %d \n",
		receivedSocket,
		pSocket_tbl->Server1Socket,
		pSocket_tbl->Server2Socket,
		pSocket_tbl->nextServer); 

	if (receivedSocket == pSocket_tbl->Server1Socket  ||
		 receivedSocket == pSocket_tbl->Server2Socket)
	{
		SendSocket = pSocket_tbl->ClientSocket;
		return(SendSocket);
	} /* if */

	if(0 == strncmp (pstr, pxstr, strlen(pxstr)))
	{

		if(LOADSHARE_SW == (Command_SW & LOADSHARE_SW))
		{
			if (pSocket_tbl->nextServer == 1)
			{
				pSocket_tbl->nextServer = 2;
			} /* if */
			else
			{
				pSocket_tbl->nextServer = 1;
			} /* else */
		} /* if - load share */
		else
		{
			if(FLIP_SW == (Command_SW & FLIP_SW))
			{
				if (pSocket_tbl->nextServer == 1)
				{
					pSocket_tbl->nextServer = 2;
				} /* if */
				else
				{
					pSocket_tbl->nextServer = 1;
				} /* else */
				SETOFF(Command_SW, FLIP_SW);
			} /* if - flip */
		} /* else - not load share*/

	} /* if */

	if (pSocket_tbl->nextServer == 1)
	{
		SendSocket = pSocket_tbl->Server1Socket;
	} /* if */
	else
	{
		SendSocket = pSocket_tbl->Server2Socket;
	} /* else */

	printf("@ Exit: rec %d, srv1 %d, srv2 %d, SND %d, nxt %d \n",
		receivedSocket,
		pSocket_tbl->Server1Socket,
		pSocket_tbl->Server2Socket,
		SendSocket,
		pSocket_tbl->nextServer); 

	return(SendSocket);

} /* SelectSocket */

char *
IdentifySocket(SOCKET theSocket)
{
	static char s1[]="Server # 1 ", s2[]="Server # 2 ", c1[]="Client ";
	static char *pret, *ps1=&s1[0], *ps2=&s2[0], *pc1=&c1[0];
	if (theSocket == pSocket_tbl->Server1Socket)
	{
		pret = ps1;
	} /* if */
	else if (theSocket == pSocket_tbl->Server2Socket)
	{
		pret = ps2;
	} /* else if */
	else
	{
		pret = pc1;
	} /* else */

	return(pret);

} /* IdentifySocket */