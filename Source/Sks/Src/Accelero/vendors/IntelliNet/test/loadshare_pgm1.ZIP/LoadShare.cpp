// Module Name: OLD LoadShare.cpp
//
// Description:
//
//	This program accepts a connection from a Client and load shares the traffic 
//	with two Servers that it has connected to as a Client.
//
//    This sample illustrates how to develop a simple echo server Winsock
//    application using the completeion port I/O model. This 
//    sample is implemented as a console-style application and simply prints
//    messages when connections are established and removed from the server.
//    The application listens for TCP connections on port 5150 and accepts them
//    as they arrive. When this application receives data from a client, it
//    simply echos (this is why we call it an echo server) the data back in
//    it's original form until the client closes the connection.
//
// Compile:
//
//    cl -o LoadShare LoadShare.cpp ws2_32.lib
//
// Command Line Options:
//
//    LoadShare.exe 
//

#include <winsock2.h>
#include <windows.h>
#include <stdio.h>

#include <stdlib.h>
#include "bit.h"
#include "TBLmacros.h"


#define PORT 35338
#define DATA_BUFSIZE 8192

typedef struct
{
   OVERLAPPED Overlapped;
   WSABUF DataBuf;
   CHAR Buffer[DATA_BUFSIZE];
   DWORD BytesSEND;
   DWORD BytesRECV;
   SOCKET SendSocket;
   SOCKET RecvSocket;
} PER_IO_OPERATION_DATA;

typedef struct 
{
   SOCKET Socket;
} PER_HANDLE_DATA;

typedef struct 
{
   int nextServer;
   SOCKET ClientSocket;
   SOCKET Server1Socket;
   SOCKET Server2Socket;
} SOCKET_TBL;

typedef struct
{
    SOCKET      sServer;
	char		ipAdr[4];	        // Server to connect to
	int			iPort;				// Port on server to connect to
    struct		sockaddr_in server;
	PER_HANDLE_DATA *pPerHandleData;
	HANDLE		pCompletionPort;
	WSABUF		CalleeData;

}
SERVER_CB;

List2Parm(IPadr, Port, iport, IPortAdrTbl);


IPortAdrTbl *pClientIPortAdrTbl, *pServerIPortAdrTbl;
char OutputFile[64]="C:/OutFile.txt", *pOutputFile=&OutputFile[0];
char RawFile[64]="C:/RawOutFile.txt", *pRawFile=&RawFile[0];

#include "PrtTCPerr.h"

int 
ConnectServer(SERVER_CB *pSCB);
void
DisConnectServer(SERVER_CB *pSCB);
void
AssociateSocket(SERVER_CB *pSCB);
void
ReceiveSocket(SERVER_CB *pSCB);
void
buildSCB(void *pTbl, int index, SERVER_CB *pSCB, HANDLE pCompletionPortID);
void
ReceiveSocket();
void
GetParms();
SOCKET
SelectSocket(SOCKET receivedSocket);
void 
WriteRawData( unsigned char * precord, int length);

void 
PrtTCPerr (char *pstr, int errcode);

DWORD WINAPI 
ServerWorkerThread(LPVOID pCompletionPortID);


SOCKET_TBL 
Socket_tbl, *pSocket_tbl = &Socket_tbl;


void main(void)
{
   SOCKADDR_IN InternetAddr;
   SOCKET Listen;
   SOCKET Accept;
   HANDLE pCompletionPort;
   SYSTEM_INFO SystemInfo;
   PER_HANDLE_DATA *pPerHandleData;
   PER_IO_OPERATION_DATA *pPerIoData;
   unsigned int i;
   DWORD RecvBytes;
   DWORD Flags;
   DWORD ThreadID;
   WSADATA wsaData;
   DWORD Ret;
   SERVER_CB ServerCB1, ServerCB2, *pServerCB1 = &ServerCB1, *pServerCB2 = &ServerCB2;

   GetParms();	// Read Parameters in from Configuration File


   if ((Ret = WSAStartup(0x0202, &wsaData)) != 0)
   {
      printf("WSAStartup failed with error %d\n", Ret);
      return;
   } /* if */


   // Setup an I/O completion port.

   if ((pCompletionPort = CreateIoCompletionPort(INVALID_HANDLE_VALUE, NULL, 0, 0)) == NULL)
   {
      WSACleanup();
      printf( "CreateIoCompletionPort failed with error: %d\n", GetLastError());
      return;
   } /* if */


   buildSCB(pServerIPortAdrTbl, 0, pServerCB1, pCompletionPort);
   buildSCB(pServerIPortAdrTbl, 1, pServerCB2, pCompletionPort);


   if ((Ret = ConnectServer(pServerCB1)) != 0)
   {
      WSACleanup();
      printf("ConnectServer failed while connecting to Server 1 with error %d\n", Ret);
      return;
   } /* if */

   if ((Ret = ConnectServer(pServerCB2)) != 0)
   {
	  DisConnectServer(&ServerCB1);
      WSACleanup();
      printf("ConnectServer failed while connecting to Server 2 with error %d\n", Ret);
      return;
   } /* if */

	pSocket_tbl->nextServer = 1;
	pSocket_tbl->Server1Socket = pServerCB1->sServer;
	pSocket_tbl->Server2Socket = pServerCB2->sServer;

	AssociateSocket(pServerCB1);
	AssociateSocket(pServerCB2);

	ReceiveSocket(pServerCB1);
	ReceiveSocket(pServerCB2);

   // Determine how many processors are on the system.

   GetSystemInfo(&SystemInfo);

   // Create worker threads based on the number of processors available on the
   // system. Create six worker threads for each processor.

   for(i = 0; i < SystemInfo.dwNumberOfProcessors * 6; i++)
   {
      HANDLE ThreadHandle;

      // Create a server worker thread and pass the completion port to the thread.

      if ((ThreadHandle = CreateThread(NULL, 0, ServerWorkerThread, pCompletionPort,
         0, &ThreadID)) == NULL)
      {
		 DisConnectServer(&ServerCB1);
		 DisConnectServer(&ServerCB2);
		 WSACleanup();
         printf("CreateThread() failed with error %d\n", GetLastError());
         return;
      } /* if */

      // Close the thread handle
      CloseHandle(ThreadHandle);
   } /* for */

   // Create a listening socket

   if ((Listen = WSASocket(AF_INET, SOCK_STREAM, 0, NULL, 0,
      WSA_FLAG_OVERLAPPED)) == INVALID_SOCKET)
   {
//      printf("WSASocket() failed with error %d\n", WSAGetLastError());
   		PrtTCPerr ("WSASocket", WSAGetLastError());

      return;
   }  /* if */

   InternetAddr.sin_family = AF_INET;
   InternetAddr.sin_addr.s_addr = htonl(INADDR_ANY);
   InternetAddr.sin_port = htons(PORT);

   if (bind(Listen, (PSOCKADDR) &InternetAddr, sizeof(InternetAddr)) == SOCKET_ERROR)
   {
//      printf("bind() failed with error %d\n", WSAGetLastError());
   		PrtTCPerr ("WSASocket", WSAGetLastError());

      return;
   } /* if */

   // Prepare socket for listening

   if (listen(Listen, 5) == SOCKET_ERROR)
   {
//      printf("listen() failed with error %d\n", WSAGetLastError());
   		PrtTCPerr ("Listen", WSAGetLastError());
      return;
   } /* if */

   // Accept connections and assign to the completion port.

   while(TRUE)
   {
      if ((Accept = WSAAccept(Listen, NULL, NULL, NULL, 0)) == SOCKET_ERROR)
      {
//         printf("WSAAccept() failed with error %d\n", WSAGetLastError());
   		PrtTCPerr ("WSAAccept", WSAGetLastError());
         return;
      } /* if */

      // Create a socket information structure to associate with the socket
      if ((pPerHandleData = (PER_HANDLE_DATA *) GlobalAlloc(GPTR, 
         sizeof(PER_HANDLE_DATA))) == NULL)
      {
         printf("GlobalAlloc() failed with error %d\n", GetLastError());
         return;
      } /* if */

      // Associate the accepted socket with the original completion port.

      printf("Socket number %d connected\n", Accept);
      pPerHandleData->Socket = Accept;
	  pSocket_tbl->ClientSocket = Accept;

      if (CreateIoCompletionPort((HANDLE) Accept, pCompletionPort, (DWORD) pPerHandleData,
         0) == NULL)
      {
         printf("CreateIoCompletionPort failed with error %d\n", GetLastError());
         return;
      } /* if */

      // Create per I/O socket information structure to associate with the 
      // WSARecv call below.

      if ((pPerIoData = (PER_IO_OPERATION_DATA *) GlobalAlloc(GPTR,
          sizeof(PER_IO_OPERATION_DATA))) == NULL)
      {
         printf("GlobalAlloc() failed with error %d\n", GetLastError());
         return;
      } /* if */

      ZeroMemory(&(pPerIoData->Overlapped), sizeof(OVERLAPPED));
      pPerIoData->BytesSEND = 0;
      pPerIoData->BytesRECV = 0;
      pPerIoData->DataBuf.len = DATA_BUFSIZE;
      pPerIoData->DataBuf.buf = pPerIoData->Buffer;
	  pPerIoData->SendSocket = NULL;
	  pPerIoData->RecvSocket = NULL;

      Flags = 0;

      if (WSARecv(Accept, &(pPerIoData->DataBuf), 1, &RecvBytes, &Flags,
         &(pPerIoData->Overlapped), NULL) == SOCKET_ERROR)
      {
         if (WSAGetLastError() != ERROR_IO_PENDING)
         {
//            printf("WSARecv() failed with error %d\n", WSAGetLastError());
	   		PrtTCPerr ("WSARecv", WSAGetLastError());

            return;
         } /* if */
      } /* if */
   } /* while */
} /* main */

DWORD WINAPI ServerWorkerThread(LPVOID pCompletionPortID)
{
   HANDLE pCompletionPort = (HANDLE) pCompletionPortID;
   DWORD BytesTransferred;
//   OVERLAPPED *pOverlapped;
   PER_HANDLE_DATA *pPerHandleData;
   PER_IO_OPERATION_DATA *pPerIoData;
   DWORD SendBytes, RecvBytes;
   DWORD Flags;
   SOCKET SendSocket;
   SOCKET RecvSocket;
   bool recFlag = false;

   while(TRUE)
   {
		
      if (GetQueuedCompletionStatus(pCompletionPort, &BytesTransferred,
         (LPDWORD)&pPerHandleData, (OVERLAPPED **) &pPerIoData, INFINITE) == 0)
      {
         printf("GetQueuedCompletionStatus failed with error %d\n", GetLastError());
         return 0;
      } /* if */


      // First check to see if an error has occured on the socket and if so
      // then close the socket and cleanup the SOCKET_INFORMATION structure
      // associated with the socket.

      if (BytesTransferred == 0)
      {
         printf("Closing socket %d\n", pPerHandleData->Socket);

         if (closesocket(pPerHandleData->Socket) == SOCKET_ERROR)
         {
//            printf("closesocket() failed with error %d\n", WSAGetLastError());
	   		PrtTCPerr ("closesocket", WSAGetLastError());

            return 0;
         } /* if */

         GlobalFree(pPerHandleData);
         GlobalFree(pPerIoData);
         continue;
      } /* if */

      // Check to see if the BytesRECV field equals zero. If this is so, then
      // this means a WSARecv call just completed so update the BytesRECV field
      // with the BytesTransferred value from the completed WSARecv() call.

      if (pPerIoData->BytesRECV == 0)
      {
         pPerIoData->BytesRECV = BytesTransferred;
         pPerIoData->BytesSEND = 0;
		 pPerIoData->RecvSocket = RecvSocket = pPerHandleData->Socket;
		 pPerIoData->SendSocket = SendSocket = SelectSocket(pPerHandleData->Socket);
		 recFlag = true;
		 WriteRawData((unsigned char *)&(pPerIoData->Buffer[0]), BytesTransferred);
      } /* if */
      else
      {
         pPerIoData->BytesSEND += BytesTransferred;

      } /* else */

      if (pPerIoData->BytesRECV > pPerIoData->BytesSEND)
      {
		  if (!recFlag)
		  {
			  SendSocket = pPerIoData->SendSocket;
		  } /* if */

         // Post another WSASend() request.
         // Since WSASend() is not gauranteed to send all of the bytes requested,
         // continue posting WSASend() calls until all received bytes are sent.

         ZeroMemory(&(pPerIoData->Overlapped), sizeof(OVERLAPPED));

         pPerIoData->DataBuf.buf = pPerIoData->Buffer + pPerIoData->BytesSEND;
         pPerIoData->DataBuf.len = pPerIoData->BytesRECV - pPerIoData->BytesSEND;

         if (WSASend(SendSocket, &(pPerIoData->DataBuf), 1, &SendBytes, 0,
            &(pPerIoData->Overlapped), NULL) == SOCKET_ERROR)
         {
            if (WSAGetLastError() != ERROR_IO_PENDING)
            {
//               printf("WSASend() failed with error %d\n", WSAGetLastError());
		   		PrtTCPerr ("WSASend", WSAGetLastError());
               return 0;
            } /* if */
         } /* if */
      } /* if */
      else
      {

         pPerIoData->BytesRECV = 0;
		 RecvSocket = pPerIoData->RecvSocket;
         // Now that there are no more bytes to send post another WSARecv() request.

         Flags = 0;
         ZeroMemory(&(pPerIoData->Overlapped), sizeof(OVERLAPPED));

         pPerIoData->DataBuf.len = DATA_BUFSIZE;
         pPerIoData->DataBuf.buf = pPerIoData->Buffer;
		 pPerIoData->SendSocket = NULL;
		 pPerIoData->RecvSocket = NULL;

         if (WSARecv(RecvSocket, &(pPerIoData->DataBuf), 1, &RecvBytes, &Flags,
            &(pPerIoData->Overlapped), NULL) == SOCKET_ERROR)
         {
            if (WSAGetLastError() != ERROR_IO_PENDING)
            {
//               printf("WSARecv() failed with error %d\n", WSAGetLastError());
		   		PrtTCPerr ("WSARecv", WSAGetLastError());
               return 0;
            } /* if */
         } /* if */
      } /* else */
   } /* while */
} /* ServerWorkerThread */


// 
// Function: ConnectServer
//
// Description:
//    ConnectServer thread of execution. Initialize Winsock, parse the 
//    command line arguments, create a socket, connect to the 
//    server, and then send and receive data.
//
int ConnectServer(SERVER_CB *pSCB)
{

    //
    // Create the socket, and attempt to connect to the server
    //
    pSCB->sServer = WSASocket(AF_INET, SOCK_STREAM, IPPROTO_TCP, NULL, 0, WSA_FLAG_OVERLAPPED);
    if (pSCB->sServer == INVALID_SOCKET)
    {
//        printf("socket() failed: %d\n", WSAGetLastError());
   		PrtTCPerr ("WSASocket", WSAGetLastError());
        return 1;
    } /* if */
//    if (WSAConnect(pSCB->sServer, (struct sockaddr *)&(pSCB->server), 
//        sizeof(pSCB->server), NULL, &(pSCB->CalleeData), NULL, NULL) == SOCKET_ERROR)

    if (connect(pSCB->sServer, (struct sockaddr *)&(pSCB->server), 
        sizeof(pSCB->server)) == SOCKET_ERROR)
    {
//        printf("connect() failed: %d\n", WSAGetLastError());
   		PrtTCPerr ("WSAConnect", WSAGetLastError());
        return 1;
    } /* if */
    return 0;
} /* ConnectServer */

void
DisConnectServer(SERVER_CB *pSCB)
{
    closesocket(pSCB->sServer);

} /* DisConnectServer */

void
AssociateSocket(SERVER_CB *pSCB)
{

	// Associate the accepted socket with the original completion port.

	printf("Socket number %d connected\n", pSCB->sServer);
	pSCB->pPerHandleData->Socket = pSCB->sServer;

	if (CreateIoCompletionPort((HANDLE) pSCB->sServer, pSCB->pCompletionPort, (DWORD) pSCB->pPerHandleData,
		0) == NULL)
	{
		printf("CreateIoCompletionPort failed with error %d\n", GetLastError());
		return;
	} /* if */

} /* AssociateSocket */

void
ReceiveSocket(SERVER_CB *pSCB)
{
	int ret = 0;
	DWORD Flags = 0;
	DWORD RecvBytes = 0;
	PER_IO_OPERATION_DATA *pPerIoData = NULL;

    // receive data 
    //
    // Create per I/O socket information structure to associate with the 
    // WSARecv call below.

	if ((pPerIoData = (PER_IO_OPERATION_DATA *) GlobalAlloc(GPTR,
		sizeof(PER_IO_OPERATION_DATA))) == NULL)
	{
		printf("GlobalAlloc() failed with error %d\n", GetLastError());
		return;
	} /* if */

	ZeroMemory(&(pPerIoData->Overlapped), sizeof(OVERLAPPED));
	pPerIoData->BytesSEND = 0;
	pPerIoData->BytesRECV = 0;
	pPerIoData->DataBuf.len = DATA_BUFSIZE;
	pPerIoData->DataBuf.buf = pPerIoData->Buffer;
	pPerIoData->SendSocket = NULL;
	pPerIoData->RecvSocket = NULL;

	Flags = 0;

	if (WSARecv(pSCB->sServer, &(pPerIoData->DataBuf), 1, &RecvBytes, &Flags,
		&(pPerIoData->Overlapped), NULL) == SOCKET_ERROR)
	{
		if (WSAGetLastError() != ERROR_IO_PENDING)
		{
//			printf("WSARecv() failed with error %d\n", WSAGetLastError());
	   		PrtTCPerr ("WSARecv", WSAGetLastError());
			return;
		} /* if */
	} /* if */

    return;
} /* ReceiveSocket */
/*
 * Socket address, internet style.
 *
struct sockaddr_in {
        short   sin_family;
        u_short sin_port;
        struct  in_addr sin_addr; // 4 bytes
        char    sin_zero[8];
};
 */

void
buildSCB(void *pV, int index, SERVER_CB *pSCB, HANDLE pCompletionPortID)
{

	Parm2Tbl *pTbl;
	pTbl = (Parm2Tbl *) pV;

	memcpy(&(pSCB->ipAdr),&(pTbl->parms[index].parm1), sizeof(pSCB->ipAdr));
	pSCB->iPort =pTbl->parms[index].parm2;
	pSCB->pCompletionPort = pCompletionPortID;

    pSCB->server.sin_family = AF_INET;
    pSCB->server.sin_port = htons(pSCB->iPort);
    memcpy(&(pSCB->server.sin_addr.s_addr), &(pSCB->ipAdr), sizeof(pSCB->server.sin_addr.s_addr));
	ZeroMemory(&(pSCB->server.sin_zero), sizeof(pSCB->server.sin_zero));

	// Create a socket information structure to associate with the socket
	if ((pSCB->pPerHandleData = (PER_HANDLE_DATA *) GlobalAlloc(GPTR, 
		sizeof(PER_HANDLE_DATA))) == NULL)
	{
		printf("GlobalAlloc() failed with error %d\n", GetLastError());
		return;
	} /* if */


} /* buildSCB */


SOCKET
SelectSocket(SOCKET receivedSocket)
{
	SOCKET SendSocket;

	if (receivedSocket == pSocket_tbl->Server1Socket  ||
		 receivedSocket == pSocket_tbl->Server2Socket)
	{
		SendSocket = pSocket_tbl->ClientSocket;
	} /* if */
	else if (pSocket_tbl->nextServer = 1)
	{
		SendSocket = pSocket_tbl->Server1Socket;
		pSocket_tbl->nextServer = 2;
	} /* else if */
	else
	{
		SendSocket = pSocket_tbl->Server2Socket;
		pSocket_tbl->nextServer = 1;
	} /* else */

	return(SendSocket);

} /* SelectSocket */