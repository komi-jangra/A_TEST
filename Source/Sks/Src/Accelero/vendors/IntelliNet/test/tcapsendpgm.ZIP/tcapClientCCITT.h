#ifndef _TEST_SUITE_H
#define _TEST_SUITE_H

#include <its.h>

//
// MTP3 callbak function
//
void MTP3StateHandler(ITS_POINTER object, ITS_POINTER userData,
                      ITS_POINTER callData);

//
// Pointer to Any Time Interrogation test procedure  
//
typedef void (*ATI_TestProc)(ITS_HANDLE, ITS_OCTET, ITS_USHORT);

//
// A test suite can consist of up to 20 tests to perform in a row.
//
const int maxSizeOfTestSuite = 20;

//
// The name of the section in the .ini file that will contain the data to load
//
#define suiteSection "Test Suite"

//
// Application Context for any time information enquiry procedures 
// between gsmSCF and HLR (anyTimeInfoEnquiryContext - see GSM 09.02 v7.5.0).
// 
#define anyTimeInfoEnquiry	(29)
#define applicationVersion3	(3)
#define applicationVersion2	(2)

//
// Useful information that will help build Location Information parameter
// Using a byte, each bit will say if param needs to be included or not.
//
enum
{
    cellId_present = 1,     // Bit 0 is set
    lai_present    = 2,     // Bit 2 is set
    locNumb_present = 4,    // Bit 3 is set
    geoInfo_present = 8,    // Bit 4 is set
    vlrNum_present  = 16,   // Bit 5 is set
    ageLoc_present  = 32    // Bit 6 is set
};

//
// Additional Subscriber States that will be represented by a ASN.1 NULL param.
// 
enum
{
	SUB_STATE_ASSUMED_IDLE = 4,
	SUB_STATE_CAMEL_BUSY = 5,
	SUB_STATE_NOT_PROVIDED_FROM_VLR = 6
};


//
// List of tests supported.
//
enum
{
	TestATI1_Full =1,                   //1
    TestATI2_FullNoAge,
    TestATI4_FullNoAgeVlr,
    TestATI5_FullCellOnly,
    TestATI6_FullLaiOnly,               //5
	TestRes1_SubStateOnly_Idle,
	TestRes2_SubStateOnly_Busy,
	TestRes3_SubStateOnly_Purged,
	TestRes4_SubStateOnly_Detached,		
	TestRes5_SubStateOnly_Restricted,   //10
	TestRes6_SubStateOnly_NotReg,
	TestRes7_SubStateOnly_NotProvided,
	TestEr1_ATI_NotAllowed,
	TestEr2_UnknownSubscriber,			
	TestEr3_SystemFailure,              //15
	TestEr4_DataMissing,
	TestEr5_UnexpectedDataValue,
	TestNoResp1,
	TestAbr1_ACNotSupported,			
	TestAbr2_ACNotSupported,            //20
	TestEnd1_NoCpt,
	TestEnd2_ResNoResult,
	TestEnd3_ResNoParameter,
	TestEnd4_ResBadOp,
    TestRej1_UnrecCpt,                  //25
    TestRej2_BadlyStruct,
    TestRej3_UnrecOpCode,
    TestRej4_MistypedParam
}
;


//
// Test #ATI AllParameters 1
// The HLR does support Any Time Interrogation, the gsmSCF requested both the
// subscriber state and Location information. The HLR will return all the info.
// The gsmSCF will receive a TC_End with a TC_Result with ATI result including
// subscriber state and Location Information.
//
void TestATI1_AllParameters(ITS_HANDLE handle, ITS_OCTET invoke_id,
							ITS_USHORT dialogue_id);

//
// Test #ATI AllParameters but No Age of Location 2
// The HLR does support Any Time Interrogation, the gsmSCF requested both the
// subscriber state and Location information. The HLR will return all the info,
// except the age of location information.
// The gsmSCF will receive a TC_End with a TC_Result with ATI result including
// subscriber state and Location Information.
//
void TestATI2_AllNoAge(ITS_HANDLE handle, ITS_OCTET invoke_id,
                       ITS_USHORT dialogue_id);

//
// Test #ATI AllParameters but No Age of Location or vlr number 3
// The HLR does support Any Time Interrogation, the gsmSCF requested both the
// subscriber state and Location information. The HLR will return all the info,
// except the vlr number and age of location.
// The gsmSCF will receive a TC_End with a TC_Result with ATI result including
// subscriber state and Location Information.
//
void TestATI3_AllNoAgeVlr(ITS_HANDLE handle, ITS_OCTET invoke_id,
                          ITS_USHORT dialogue_id);

//
// Test #ATI AllParameters but No Age of Location 4
// The HLR does support Any Time Interrogation, the gsmSCF requested both the
// subscriber state and Location information. The HLR will return all the info,
// Only the Cell Id is present (no able to derived geo info and location num).
// The gsmSCF will receive a TC_End with a TC_Result with ATI result including
// subscriber state and Location Information.
//
void TestATI4_AllCellOnly(ITS_HANDLE handle, ITS_OCTET invoke_id,
                          ITS_USHORT dialogue_id);

//
// Test #ATI AllParameters but No Age of Location 5
// The HLR does support Any Time Interrogation, the gsmSCF requested both the
// subscriber state and Location information. The HLR will return all the info,
// Only the Cell Id is present (no able to derived geo info and location num).
// The gsmSCF will receive a TC_End with a TC_Result with ATI result including
// subscriber state and Location Information.
//
void TestATI5_AllLaiOnly(ITS_HANDLE handle, ITS_OCTET invoke_id,
                         ITS_USHORT dialogue_id);
//
// Test #Result 1
// HLR replies with only the Subsriber State (set to assumedIdle) 
// HLR will return a Return Result with Any Time Interrogation Result
// holding the Subscriber State, set to assumedIdle, only.
//
void 
TestResult1_SubStateOnly_Idle(ITS_HANDLE handle, ITS_OCTET invoke_id, 
								   ITS_USHORT dialogue_id);

//
// Test #Result 2
// HLR replies with only the Subsriber State (set to camelBusy) 
// HLR will return a Return Result with Any Time Interrogation Result
// holding the Subscriber State, set to camelBusy, only.
//
void TestResult2_SubStateOnly_Busy(ITS_HANDLE handle, ITS_OCTET invoke_id, 
								   ITS_USHORT dialogue_id);

//
// Test #Result 3
// HLR replies with only the Subsriber State (set to msPurged) 
// HLR will return a Return Result with Any Time Interrogation Result
// holding the Subscriber State, set to msPurged, only.
//
void TestResult3_SubStateOnly_Purged(ITS_HANDLE handle, ITS_OCTET invoke_id,
									 ITS_USHORT dialogue_id);

//
// Test #Result 4
// HLR replies with only the Subsriber State (set to imsiDetached) 
// HLR will return a Return Result with Any Time Interrogation Result
// holding the Subscriber State, set to imsiDetached, only.
//
void TestResult4_SubStateOnly_Detached(ITS_HANDLE handle, ITS_OCTET invoke_id,
									   ITS_USHORT dialogue_id);

//
// Test #Result 5
// HLR replies with only the Subsriber State (set to restrictedArea) 
// HLR will return a Return Result with Any Time Interrogation Result
// holding the Subscriber State, set to restrictedArea, only.
//
void TestResult5_SubStateOnly_Restricted(ITS_HANDLE handle,
										 ITS_OCTET invoke_id,
									     ITS_USHORT dialogue_id);

//
// Test #Result 6
// HLR replies with only the Subsriber State (set to notRegistered) 
// HLR will return a Return Result with Any Time Interrogation Result
// holding the Subscriber State, set to notRegistered, only.
//
void TestResult6_SubStateOnly_NotReg(ITS_HANDLE handle, ITS_OCTET invoke_id,
									 ITS_USHORT dialogue_id);

//
// Test #Result 7
// HLR replies with only the Subsriber State (set to notProvidedFromVLR) 
// HLR will return a Return Result with Any Time Interrogation Result
// holding the Subscriber State, set to notProvidedFromVLR, only.
//
void TestResult7_SubStateOnly_NotProvided(ITS_HANDLE handle,
										  ITS_OCTET invoke_id, 
										  ITS_USHORT dialogue_id);

//
// Test #Error 1
// Any Time Interrogation is not supported by the CAMEL server. 
// HLR will return a Return Error with Error Code set to ATI-NotAllowed.
//
void TestError1_ATI_NotAllowed(ITS_HANDLE handle, ITS_OCTET invoke_id,
							   ITS_USHORT dialogue_id);

//
// Test #Error 2
// Any Time Interrogation is supported, But the subscriber is unknown.
// HLR will return a Return Error with Error Code set to UnknownSubscriber.
//
void TestError2_UnknownSubscriber(ITS_HANDLE handle, ITS_OCTET invoke_id, 
								  ITS_USHORT dialogue_id);

//
// Test #Error 3
// Any Time Interrogation is supported but cannot be peformed because of a
// problem in another entity.
// HLR will return a Return Error with Error Code set to SystemFailure. 
//
void TestError3_SystemFailure(ITS_HANDLE handle, ITS_OCTET invoke_id,
							  ITS_USHORT dialogue_id);

//
// Test #Error 4
// Any TimeInterrogation is supported but an optional parameter required by
// the context is missing (both). 
// HLR will return a Return Error with Error Code set to DataMissing.
//
void TestError4_DataMissing(ITS_HANDLE handle, ITS_OCTET invoke_id,
							ITS_USHORT dialogue_id);

//
// Test #Error 5
// Any TimeInterrogation is supported but the value or the presence of a data
// type, even though correct, is unexpected in the current context.
// HLR will return a Return Error with Error Code set to UnexpectedDataValue.
//
void TestError5_UnexpectedDataValue(ITS_HANDLE handle, ITS_OCTET invoke_id,
									ITS_USHORT dialogue_id);

//
// Test #NoResponse 1
// The HLR does not reply to the Any TimeInterrogation operation within
// the time expected.
// The gsmSCF will receive a TC_Cancel (generated by TCAP stack).
//
void TestNoResponse1(ITS_HANDLE handle, ITS_OCTET invoke_id,
					 ITS_USHORT dialogue_id);

//
// Test #AbortACNotSupported 1
// The HLR does not support AnyTimeEnquiryContext version 3, he will abort the
// MAP dialogue.
// The gsmSCF will receive a TC_U_ABort with reason set to AC name not
// supported with the same ac name.
//
void TestAbort1_ACNotSupported(ITS_HANDLE handle, ITS_OCTET invoke_id,
							   ITS_USHORT dialogue_id);

//
// Test #AbortACNotSupported 1
// The HLR does AnyTimeEnquiryContext, but it does support a lower version.
// Thus he will propose a lower version to use if the gsmSCF wants to.
// The gsmSCF will receive a TC_U_ABort with reason set to AC name not
// supported with the same ac name but with a lower version.
//
// Note: The only supported AnyTimeEnquiryContext version is 3. As of now
//       there is no other version, this is for testing purposed only.
//
void TestAbort2_ACNotSupported(ITS_HANDLE handle, ITS_OCTET invoke_id,
							   ITS_USHORT dialogue_id);

//
// Test #EndNocpt 1
// The HLR does support Any Time Interrogation but will send back a TC_End
// with no associated TC_Result (missing ATI result).
// The gsmSCF will receive a TC_End with no component.
//
void TestEnd1_NoComponent(ITS_HANDLE handle, ITS_OCTET invoke_id,
						  ITS_USHORT dialogue_id);

//
// Test #EndResNoRes 2
// The HLR does support Any Time Interrogation but will send back a TC_End
// with TC_Result component with missing result (missing ATI result arg).
// The gsmSCF will receive a TC_End with a TC_Result component missing
// the operation and parameters.
//
void TestEnd2_ResNoRes(ITS_HANDLE handle, ITS_OCTET invoke_id,
					   ITS_USHORT dialogue_id);

//
// Test #EndResNoParam 3
// The HLR does support Any Time Interrogation but will send back a TC_End
// with TC_Result component with missing parameter (missing ATI result arg).
// The gsmSCF will receive a TC_End with a TC_Result component with operation
// and missing parameters.
//
void TestEnd3_ResNoParam(ITS_HANDLE handle, ITS_OCTET invoke_id,
						 ITS_USHORT dialogue_id);

//
// Test #EndResBadOperation 4
// The HLR does support Any Time Interrogation but will send back a TC_End
// with TC_Result component but with incorrect operation (not ATI operation)
// The gsmSCF will receive a TC_End with a TC_Result with operation different
// that ATI operation code.
//
void TestEnd4_ResBadOperation(ITS_HANDLE handle, ITS_OCTET invoke_id,
						      ITS_USHORT dialogue_id);


//
// Test #RejectUnregognizedCpt 1
// The HLR does support Any Time Interrogation but will due to some problems,
// the remote TCAP does not regnognized it is a TC_Invoke.
// The gsmSCF will receive a TC_End with a TC_Reject.
//
void TestRej1_UnrecognizedCpt(ITS_HANDLE handle, ITS_OCTET invoke_id,
						      ITS_USHORT dialogue_id);

//
// Test #RejectBadlyStructured 2
// The HLR does support Any Time Interrogation but will due to some problems,
// the remote TCAP think the component is badly encoded.
// The gsmSCF will receive a TC_End with a TC_Reject.
//
void TestRej2_BadlyStructured(ITS_HANDLE handle, ITS_OCTET invoke_id,
						      ITS_USHORT dialogue_id);

//
// Test #RejectUnrecOperation 3
// The HLR does support Any Time Interrogation but will due to some problems,
// the HLR does not regognized the operation code (does not belong to ac name).
// The gsmSCF will receive a TC_End with a TC_Reject.
//
void TestRej3_UnrecOperation(ITS_HANDLE handle, ITS_OCTET invoke_id,
						     ITS_USHORT dialogue_id);

//
// Test #RejectBadParams 4
// The HLR does support Any Time Interrogation but will due to some problems,
// the HLR cannot decode the parameters (ATI operation).
// The gsmSCF will receive a TC_End with a TC_Reject.
//
void TestRej4_BadParams(ITS_HANDLE handle, ITS_OCTET invoke_id,
                        ITS_USHORT dialogue_id);

#endif



