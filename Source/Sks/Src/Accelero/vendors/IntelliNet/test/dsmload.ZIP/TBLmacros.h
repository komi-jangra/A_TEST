/* TBL macros.h */
#ifndef _TBLmacros_
#define _TBLmacros_

/* Key Word Parameter Table */

#define KWString B0b00000001
#define KWInt B0b00000010
#define KWDword B0b00000100
#define KWBool B0b00001000
#define KWipadr B0b00010000
#define KWiport B0b00100000
#define KWTable B0b10000000
#define KWinvert B1b00000001



#define KeyWordTbl(N, C) struct KW##N {char * pS; int T; int * pV; }; struct KW##N N[C+1] = {
#define KeyWordElm(S, T, V) &S[0], T, (int *) &V,
#define KeyWordEnd (char *) -1, -1, (int *) -1,}

#define List1Parm(N1,N2,N3) typedef struct {int cnt; struct { unsigned int N1; } N2[1]; } N3;


typedef struct {
	int	cnt;
	struct { unsigned int parm1; } parms[1];
} Parm1Tbl;


#define List2Parm(N1,N2,N3,N4) typedef struct { int cnt; struct { unsigned int N1; unsigned int N2; } N3[1]; } N4;


typedef struct {
	int	cnt;
	struct { unsigned int parm1; unsigned int parm2; } parms[1];
} Parm2Tbl;


typedef	struct {
	long recordmarker;
	long length;
	char tmpbuf1[9];
	char tmpbuf2[9];
	char data[16000];
} RAWRECORD;

#define ASK(Y, N, M) \
	for (char selection = ' '; ;) \
	{ \
		cout << M; \
		cin >> selection; \
		selection = tolower(selection); \
		if (selection == 'y') \
		{ \
			Y; \
		}  \
		if (selection == 'n')  \
	{  \
			N;  \
		}  \
		cout << "Invalid Answer " << endl; \
	}


#define CMDdef(n, c) struct { char sel; char *pdescription; void *pfn; } n##tbl[c+1] = {
#define CMDent(S, D, F) S, D, &F,
#define CMDend (unsigned char) 0xFF, (char *) 0xFFFFFFFF }


#define MSGdef(n, c) struct { unsigned char msgid; char *pdesc; unsigned int ie_bits; void *pfn; } n##tbl[c+1] = {
#define MSGent(M, D, B, F) (unsigned int) M, D, B, &F, 
#define MSGend (unsigned char) 0x00, (char *) NULL, (unsigned int) 0x00000000, (char *) 0xFFFFFFFF }

#define SETON(f, b) f = f | b
#define SETOFF(f, b) f = f & ~b

#define TESTON(f, b) b == (f & b)
#define TESTOFF(f, b) !(b ==  (f & b))

#define TESTODD(v) v%2 != 0
#define TESTEVEN(v) v%2 == 0

#endif /* _TBLmacros_ */

